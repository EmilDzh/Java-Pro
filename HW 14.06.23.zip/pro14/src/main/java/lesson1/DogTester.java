package lesson1;

public class DogTester {
    public static void main(String[] args) {
        // оператор New используется для создания  экземпляра класса
        Dog trezor = new Dog();
        // trezor.name = "Trezor";
        // trezor.age = 5;
        // trezor.breed = "овчарка";

        trezor.setName("Trezor");
        trezor.setBreed("овчaрка");
        trezor.setAge(5);


        Dog eleonora = new Dog();
        //  eleonora.name = "Eleonora";
        //   eleonora.breed = "болонка";
        //   eleonora.age = 7;

        eleonora.setName("Eleonora");
        eleonora.setBreed("болонка");
        eleonora.setAge(7);

        System.out.println("Eleonora breed is " + eleonora.getBreed());

        Dog max = new Dog("Pitbul", "Max" , 5, "Черный");

        max.bark();
        eleonora.bark();
        trezor.bark();


        printDog(trezor);
        printDog(eleonora);
        printDog(max);



    } // конец мейна

    public static void printDog(Dog d) {
        System.out.println("Собака "
                + d.getName() + " породы "
                + d.getBreed() + " возраста "
                + d.getAge()
        );

    }


}
