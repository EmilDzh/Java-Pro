package HW140623;

import java.util.Arrays;

//

public class PhoneTester {
    public static void main(String[] args) {

        Phone nokia = new Phone();
        nokia.model = "Nokia 3310";
        nokia.number = 998778201043L;
        nokia.weight = 133.5;

        Phone samsung = new Phone();
        samsung.model = "Galaxy Edge";
        samsung.number = 998772727899L;
        samsung.weight = 245.3;

        Phone Sony = new Phone();
        Sony.model = "Xperia 1";
        Sony.number = 998455562L;
        Sony.weight = 230.1;

        System.out.println("Model: " + nokia.model);
        System.out.println("number: " + nokia.number);
        System.out.println("weight: " + nokia.weight);

        System.out.println();

        System.out.println("Model: " + samsung.model);
        System.out.println("number: " + samsung.number);
        System.out.println("weight: " + samsung.weight);

        System.out.println();

        System.out.println("Model: " + Sony.model);
        System.out.println("number: " + Sony.number);
        System.out.println("weight: " + Sony.weight);

        System.out.println();


        nokia.receiveCall("Nokia");
        nokia.getNumber();

        System.out.println();

        samsung.receiveCall("Samsung");
        samsung.getNumber();

        System.out.println();

        Sony.receiveCall("Sony");
        Sony.getNumber();



    }
}
