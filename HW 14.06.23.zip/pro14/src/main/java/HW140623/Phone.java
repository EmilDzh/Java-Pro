package HW140623;

public class Phone {
    long number ;
    String model;
    double weight;

    public  void receiveCall(String name){
        System.out.println("Звонит " + name);
    }

    public long getNumber(){
        System.out.println(number);
        return number;
    }


}


