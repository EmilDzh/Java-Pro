package HW140623;

public class hwTester {

    public static void main(String[] args) {

        Person Ed = new Person();
        //  Ed.fullname = "Ed";
        //Ed.age = 32;

        Ed.setFullname("Ed Sheeran");
        Ed.setAge(32);

        Person Elvis = new Person("Elvis Presley",35);

        Ed.move();
        Ed.talk();
        Elvis.talk();
        Elvis.move();

    }
}
