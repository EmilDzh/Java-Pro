package com.example.shop14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Shop14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
