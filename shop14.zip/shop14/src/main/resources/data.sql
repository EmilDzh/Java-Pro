-- data.sql

insert into book (id, name) values(1, 'The Tartar Steppe');
insert into book (id, name) values(2, 'Poem Strip');
insert into book (id, name) values(3, 'Restless Nights: Selected Stories of Dino Buzzati');

INSERT INTO countries (id, name) VALUES (1, 'USA');
INSERT INTO countries (id, name) VALUES (2, 'France');
INSERT INTO countries (id, name) VALUES (3, 'Brazil');
INSERT INTO countries (id, name) VALUES (4, 'Italy');
INSERT INTO countries (id, name) VALUES (5, 'Canada');

