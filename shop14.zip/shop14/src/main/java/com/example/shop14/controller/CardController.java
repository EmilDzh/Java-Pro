package com.example.shop14.controller;

import com.example.shop14.entity.Card;
import com.example.shop14.entity.Product;
import com.example.shop14.repo.CardRepository;
import com.example.shop14.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
public class CardController {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CardRepository cardRepository;

    @GetMapping("/cards/{id}")
    public Optional<Card> getCardById(
            @PathVariable Long id
    ) {
        return cardRepository.findById(id);
    }

    @DeleteMapping("/cards/{id}")
    public ResponseEntity<HttpStatus> deleteCardById(
            @PathVariable Long id
    ) {
        List<Product> products = new ArrayList<>();

        // нужно найти все продукты для карты
        productRepository.findProductsByCardsId(id).forEach(products::add);
        // из них карту удалить и сохранить их
        products.forEach(
                p -> p.removeCard(id)
        );
        System.out.println(products);
        productRepository.saveAll(products);

        // только потом удалить карту из репозитори
        cardRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

      /* Добавьте и реализуйте в контроллере карт методы
     // DELETE http://localhost:8080/products/%7BproductId%7D/cards/%7BcardId%7D - удаление продукта из карты
        public ResponseEntity<HttpStatus> deleteCardFromProduct(
        Long productId,
        Long cardId

      )

     */

    @DeleteMapping("/products/{productId}/cards/{cardId}")
    public ResponseEntity<HttpStatus> deleteCardFromProduct(
            @PathVariable(name = "productId") long productId,
            @PathVariable(name = "cardId") long cardId
    ) {
        Card card = cardRepository.findById(cardId).get();

        card.deleteProduct(productId);

        cardRepository.save(card);

        return ResponseEntity.ok(HttpStatus.OK);

        /* не понимаю(((

          @DeleteMapping("/products/{productId}/cards/{cardId}")
    public ResponseEntity<HttpStatus> deleteCardFromProduct(
          @PathVariable(name = "productId") long productId,
          @PathVariable(name = "cardId") long cardId
    )
    {
        List<Card> cards = new ArrayList<>();

        cardRepository.findCardsProductsById(productId).forEach(cards::add);

        cards.forEach(
                c -> c.deleteProduct(productId)
        );

        cardRepository.saveAll(cards);

        productRepository.deleteById(productId);
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
       }
         */
    }

    /*
    // POST http://localhost:8080/products/%7BproductId%7D/cards - создание карты для продукта
    public ResponseEntity<Card> addCard(
    Long productId,
    Card cardRequest
    )
    */

    @PostMapping("/products/{productId}/card")
    public ResponseEntity<Card> addCard(
            @PathVariable(name = "productId") long productId,
            @RequestBody Card cardRequest
    ) {
        Product product = productRepository.findById(productId).orElse(null);

        Card newCard = new Card();
        newCard.setName(cardRequest.getName());

        if (product != null) {
            product.addCard(newCard);

            cardRepository.save(newCard);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /*
         GET http://localhost:8080/cards/%7BcardId%7D/products - все продукты для карты
         public ResponseEntity<Iterable<Product>> getAllProductsByCardId(
         Long cardId
         )
         */

    @GetMapping("/cards/{cardId}/products")
    public ResponseEntity<Iterable<Product>> getAllProductsByCardId(
            @PathVariable(name = "cardId") Long cardId
    )
    {
         List<Product> products = new ArrayList<>();
         productRepository.findProductsByCardsId(cardId).forEach(products::add);

         return ResponseEntity.ok(productRepository.saveAll(products));
    }
}
