package com.example.shop14.controller;

import com.example.shop14.entity.Comment;
import com.example.shop14.entity.Product;
import com.example.shop14.repo.CommentRepository;
import com.example.shop14.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class CommentController {
    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private ProductRepository productRepository;


    @DeleteMapping("/comments/{id}")
    public ResponseEntity<HttpStatus> deleteComment(
            @PathVariable Long id
    )
    {
        commentRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/comments/{id}")
    public Optional<Comment> getCommentById(
            @PathVariable Long id
    )
    {
        return commentRepository.findById(id);
    }

    /* Добавьте и реализуйте в контроллере комментариев метод
       // POST http://localhost:8080/products/%7BproductId%7D/comments - добавление коммента к продукту
         public ResponseEntity<Comment> createComment(
         Long productId,
         Comment comment
         )
    */

    @PostMapping("/products/{productId}/comments")
    public ResponseEntity<Comment> createComment(
            @PathVariable(name = "productId") Long productId,
            @RequestBody Comment comment
    )
    {
        Product product = productRepository.findById(productId).orElse(null);

        Comment newComment = new Comment();
        newComment.setContent(comment.getContent());
        newComment.setProduct(product);

        commentRepository.save(newComment);
        return new ResponseEntity<>(newComment, HttpStatus.CREATED);
    }
}
