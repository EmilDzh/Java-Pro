package com.example.shop14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/*
Создайте контроллер (@RestController) ProductController с методами
public Product createProduct(Product) // POST /products
public void deleteProduct(Long id) // DELETE /products/{id}
public Product getProductByProductId(Long id) // GET /products/{id}
public Product updateComment(Long id, Product product) // PUT /products/{id}

*/

@RestController
public class ProductController {

    private List<Product> products = new ArrayList<>();

    public ProductController() {
        products.addAll(
                Arrays.asList(
                        new Product("Rennrad", new BigDecimal("300.50"), true),
                        new Product("Mountain-Bike", new BigDecimal("250.24"), true),
                        new Product("Kama", new BigDecimal("200.99"), true),
                        new Product("Flatrad", new BigDecimal("150.77"), false),
                        new Product("Elektro-Bike", new BigDecimal("1000"), false)
                )
        );

    }

    @Autowired
    private ProductRepository productRepository;

    @GetMapping({"/products", "/products/"})
    public Iterable<Product> getCoffees() {

        return productRepository.findAll();
    }

    //public Product createProduct(Product) // POST /products

    //POST http://localhost:8080/coffees/{id}
    @PutMapping("products")
    public Product createProduct(@RequestBody Product product) {

        return productRepository.save(product);

    }

    // public void deleteProduct(Long id) // DELETE /products/{id}

    @DeleteMapping("products/{id}")
    public ResponseEntity<Product> deleteProduct(@PathVariable Long id) {

        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    //public Product getProductByProductId(Long id) // GET /products/{id}

    @GetMapping("products/{id}")
    public Optional<Product> getProductByProductId(@PathVariable("id") Long id) {

        return productRepository.findById(id);
    }

    // public Product updateComment(Long id, Product product) // PUT /products/{id}

    @PostMapping("products/{id}")
    public ResponseEntity<Product> updateComment(
            @PathVariable("id") Long id,
            @RequestBody Product product) {

        if (productRepository.existsById(id)) {

            productRepository.save(product);

            return ResponseEntity.ok().build();
        } else {

            return ResponseEntity.notFound().build();
        }

    }

}
