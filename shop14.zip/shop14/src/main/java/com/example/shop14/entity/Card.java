package com.example.shop14.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "cards")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Card {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToMany(mappedBy = "cards", cascade = {CascadeType.ALL, CascadeType.MERGE})
    @JsonIgnore
    private Set<Product> products = new HashSet<>();

    public void deleteProduct(long productId){

         Product product = products.stream()
                .filter(p -> p.getId().equals(productId))
                .findFirst()
                .orElse(null);
        if (product != null){
            products.remove(product);
            product.getCards().remove(this);
        }
    }




}
