package com.example.shop14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Shop14Application {

	public static void main(String[] args) {
		SpringApplication.run(Shop14Application.class, args);
	}

}
