package com.example.shop14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/*
 Создайте через initializr (https://start.spring.io/) maven проект shop14

 Добавьте зависимости web, h2, lombok, jpa, validation
*/

@SpringBootApplication
@EnableScheduling
public class Shop14Application {

	public static void main(String[] args) {
		SpringApplication.run(Shop14Application.class, args);
	}

}
