package com.example.shop14;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;

@Service
public class ProductDatabaseInitializer implements CommandLineRunner {

    @Autowired
    private ProductRepository productRepository;
    private static final Logger logger = LoggerFactory.getLogger(ProductDatabaseInitializer.class);


    @Override
    public void run(String... args) throws Exception {

        productRepository.saveAll(
                Arrays.asList(
                        new Product("Rennrad", new BigDecimal("300.50"), true),
                        new Product("Mountain-Bike", new BigDecimal("250.24"), true),
                        new Product("Kama", new BigDecimal("200.99"), true),
                        new Product("Flatrad", new BigDecimal("150.77"), false),
                        new Product("Elektro-Bike", new BigDecimal("1000"), false)
                )
        );

        // trace
        // debug
        // info
        // warn
        // error
        logger.info("Products added to repository");
    }
}
