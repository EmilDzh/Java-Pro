package com.example.shop14;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.UUID;

/*
Добавьте в проект сущность (@Entity) Product с полями
Long id (@Id)
String name
BigDecimal price
boolean isActive
  */

@Entity
@Getter
@Setter
@ToString
public class Product {

    @Id
    Long id;
    String name;
    BigDecimal price;
    boolean isAstive;

    public Product() {
        id = UUID.randomUUID().getLeastSignificantBits();
    }

    public Product(String name, BigDecimal price, boolean isAstive){
        this();
        this.name = name;
        this.price = price;
        this.isAstive = isAstive;
    }
}
