package com.example.BankProject;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.repository.AccountRepo;
import jakarta.transaction.Transactional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.http.HttpStatus.CREATED;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IntegrationTest {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private AccountRepo accountRepo;

    @Autowired
    private TestRestTemplate restTemplate;



    @Test
    public void createAccount(){

        Long clientId = 396L;

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type","application/json");

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"newTestAcc\", \"type\" : \"CHECKING\", \"status\" : \"ACTIVE\", " +
                        "\"balance\" : \"1000.00\", \"currency_code\" : \"EUR\"}",
                headers
        );
        System.out.println("Before: " + accountRepo.count());

        assertEquals(accountRepo.count(), 2);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/accounts",
                        request,
                        String.class,
                        clientId
                );


        String result = response.getBody();

        System.out.println(result);


        System.out.println("After: " + accountRepo.count());
        System.out.println("Result from server: " + result);

        assertEquals(accountRepo.count(), 3);
        assertEquals(response.getStatusCode(), CREATED);





    }


}
