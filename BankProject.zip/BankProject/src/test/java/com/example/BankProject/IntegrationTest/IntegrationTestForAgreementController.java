package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.entity.Enum.AgreementStatus;
import com.example.BankProject.repository.AgreementRepo;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;
//@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IntegrationTestForAgreementController {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private AgreementRepo agreementRepo;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void shouldReturnAllAgreements(){

        ResponseEntity<AgreementDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/agreements",
                        AgreementDto[].class
                );

        int expectedAgreements = 3;

        assertEquals(HttpStatus.OK, response.getStatusCode());

        AgreementDto[] agreementDtos = response.getBody();
        assertNotNull(agreementDtos);
        assertEquals(expectedAgreements, agreementDtos.length);
    }

    @Test
    public void shouldReturnAgreementById(){

        Long agreementId = 1L;

        ResponseEntity<AgreementDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/agreements/" + agreementId,
                        AgreementDto.class,
                        agreementId
                );

        assertEquals(HttpStatus.OK, response.getStatusCode());

        AgreementDto agreementDto = response.getBody();
        assertNotNull(agreementDto);
    }

    @Test
    public void shouldReturnNotFoundForNotExistingAgreement(){

        Long agreementId = 999L;

        ResponseEntity<AgreementDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/agreements/" + agreementId,
                        AgreementDto.class,
                        agreementId
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldReturnCreatedAgreement(){

        Long accountId = 1L;
        Long productId = 1L;

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        HttpEntity<String> request = new HttpEntity<>(
                "{\"interest_rate\" : \"5.50\", \"status\" : \"PENDING\", \"sum\" : \"700.00\"}",
                headers
        );

        assertEquals(agreementRepo.count(), 3);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/agreements/" + productId + "/" + accountId,
                        request,
                        String.class,
                        productId,
                        accountId
                );
        System.out.println(response.getBody());

        assertEquals(agreementRepo.count(), 4);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());


    }

    @Test
    public void checkFieldsOfCreatedAgreement() throws JSONException {

        Long accountId = 1L;
        Long productId = 1L;

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        HttpEntity<String> request = new HttpEntity<>(
                "{\"interest_rate\" : \"5.50\", \"status\" : \"PENDING\", \"sum\" : \"700.00\"}",
                headers
        );

        assertEquals(agreementRepo.count(), 3);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/agreements/" + productId + "/" + accountId,
                        request,
                        String.class,
                        productId,
                        accountId
                );

        JSONObject jsonObject = new JSONObject(response.getBody());
        assertTrue(jsonObject.has("id"));
        assertTrue(jsonObject.has("interest_rate"));
        assertTrue(jsonObject.has("status"));
        assertTrue(jsonObject.has("sum"));

        assertEquals(agreementRepo.count(), 4);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());


    }

    @Test
    public void shouldUpdateAgreement(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long productId = 1L;
        Long accountId = 1L;

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"interest_rate\" : \"5.50\", \"status\" : \"ACTIVE\", \"sum\" : \"750.00\"}",
                headers
        );

        ResponseEntity<AgreementDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/agreements/" + productId + "/" + accountId,
                        createRequest,
                        AgreementDto.class,
                        productId,
                        accountId
                );

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());

        AgreementDto createdAgreement = createResponse.getBody();
        assertNotNull(createdAgreement);

        Long agreementId = createdAgreement.getId();


        createdAgreement.setInterest_rate(new BigDecimal("2.00"));
        createdAgreement.setStatus(AgreementStatus.PENDING);

        HttpEntity<AgreementDto> updateRequest = new HttpEntity<>(createdAgreement, headers);

        ResponseEntity<AgreementDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/agreements/"+ agreementId + "/" + productId + "/" + accountId,
                        HttpMethod.PUT,
                        updateRequest,
                        AgreementDto.class
                );

        assertEquals(HttpStatus.OK, updateResponse.getStatusCode());

        AgreementDto updatedAgreement = updateRequest.getBody();
        assertNotNull(updatedAgreement);

        assertEquals(new BigDecimal("2.00"), updatedAgreement.getInterest_rate());
        assertEquals(AgreementStatus.PENDING, updatedAgreement.getStatus());
    }

    @Test
    public void shouldDeleteAgreement(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long productId = 1L;
        Long accountId = 1L;

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"interest_rate\" : \"5.50\", \"status\" : \"ACTIVE\", \"sum\" : \"750.00\"}",
                headers
        );

        ResponseEntity<AgreementDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/agreements/" + productId + "/" + accountId,
                        createRequest,
                        AgreementDto.class,
                        productId,
                        accountId
                );

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());
        assertNotNull(createResponse.getBody());

        AgreementDto agreementDto = createResponse.getBody();
        Long agreementId = agreementDto.getId();

        ResponseEntity<String> deleteResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/agreements/" + agreementId,
                        HttpMethod.DELETE,
                        null,
                        String.class,
                        agreementId
                );
        assertEquals(HttpStatus.OK, deleteResponse.getStatusCode());

        ResponseEntity<AgreementDto> checkResponse = restTemplate
                .withBasicAuth("bastian", "password")
                        .getForEntity(
                                "http://localhost:" + port + "/agreements/" + agreementId,
                                AgreementDto.class,
                                agreementId
                        );

        assertEquals(HttpStatus.NOT_FOUND, checkResponse.getStatusCode());
    }
}
