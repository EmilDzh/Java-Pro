package com.example.BankProject;

import com.example.BankProject.controllers.AccountController;
import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.mapper.AccountMapper;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.repository.AccountRepo;
import com.example.BankProject.repository.TransactionRepo;
import com.example.BankProject.services.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


//@WebMvcTest
//@AutoConfigureMockMvc
//@RunWith(SpringRunner.class)
@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest
@AutoConfigureMockMvc
public class AccountControllerTest {

    @MockBean
    public AccountService accountService;

    @MockBean
    public ClientService clientService;

    @MockBean
    public AgreementService agreementService;

    @MockBean
    public ProductService productService;

    @MockBean
    public ManagerService managerService;

    @MockBean
    public TransactionService transactionService;


//    @InjectMocks
//    private AccountService accountService;
//    @Mock
//    public AccountRepo accountRepo;
//
//    @Mock
//    public TransactionRepo transactionRepo;
//
//    @Mock
//    public AccountMapper accountMapper;
//


    @Mock
    AccountRepo accountRepo;
    @Autowired
    MockMvc mockMvc;
//
//    @Autowired
//    private ObjectMapper objectMapper;

    @Test
    public void getAllAccounts() throws Exception {

        AccountService accountService = Mockito.mock(AccountService.class);

        when(accountService.getAllAccounts()).thenReturn(Arrays.asList(
                new AccountDto("Acc1", AccountType.LOAN, AccountStatus.ACTIVE,new BigDecimal("100"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now())),
                new AccountDto("Acc2", AccountType.CHECKING, AccountStatus.ACTIVE,new BigDecimal("200"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now())),
                new AccountDto("Acc3", AccountType.SAVINGS, AccountStatus.ACTIVE,new BigDecimal("300"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now())),
                new AccountDto("Acc4", AccountType.CHECKING, AccountStatus.BLOCKED,new BigDecimal("400"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now())),
                new AccountDto("Acc5", AccountType.LOAN, AccountStatus.INACTIVE,new BigDecimal("500"), CurrencyCode.USD, Timestamp.valueOf(LocalDateTime.now()))
        ));

        // mockMvc.perform(get("/accounts"))

        mockMvc.perform(get("/accounts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value(5))
                .andExpect(jsonPath("$[0].client").doesNotExist());


        verify(accountService, times(1)).getAllAccounts();
    }




}
