package com.example.BankProject.ServiceTest;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.mapper.AccountMapper;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.repository.AccountRepo;
import com.example.BankProject.repository.TransactionRepo;
import com.example.BankProject.services.AccountService;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AccountServiceTest {

    @InjectMocks
    private AccountService accountService;

    @Mock
    private AccountRepo accountRepo;



    @Test
    public void testGetAllAccounts() {
        // Создаем тестовые данные
        AccountDto accountDto = new AccountDto("Acc1", AccountType.LOAN, AccountStatus.ACTIVE, new BigDecimal("100"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now()));
        AccountDto accountDto2 = new AccountDto("Acc2", AccountType.CHECKING, AccountStatus.ACTIVE, new BigDecimal("200"), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now()));
        Account account = accountService.accountMapper.fromDtoToAccount(accountDto);
        Account account2 = accountService.accountMapper.fromDtoToAccount(accountDto2);

        List<Account> accounts = new ArrayList<>(Arrays.asList(account, account2));

        Mockito.when(accountRepo.findAll()).thenReturn(accounts);
    }
}
