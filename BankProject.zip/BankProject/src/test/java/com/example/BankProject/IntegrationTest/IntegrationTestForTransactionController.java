package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.repository.TransactionRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IntegrationTestForTransactionController {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void shouldReturnAllTransactions(){

        ResponseEntity<TransactionDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/transactions",
                        TransactionDto[].class
                );

        int expectedTransactions = 1;

        assertNotNull(response.getBody());

        TransactionDto[] transactionDtos = response.getBody();
        assertEquals(expectedTransactions, transactionDtos.length);
    }

    @Test
    public void shouldReturnTransactionById(){
        Long transactionId = 1L;

        ResponseEntity<TransactionDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/transaction/" + transactionId,
                        TransactionDto.class,
                        transactionId
                );

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void shouldReturnNotFoundByNotExistingTransaction(){
        Long transactionId = 999L;

        ResponseEntity<TransactionDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/transaction/" + transactionId,
                        TransactionDto.class,
                        transactionId
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testingTransfer(){
        Long fromAccountId = 1L;
        Long toAccountId = 2L;
        BigDecimal amount = new BigDecimal("600.00");

        ResponseEntity<TransactionDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/transfer/" + fromAccountId + "/" + toAccountId,
                        amount,
                        TransactionDto.class
                );

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());


    }

    @Test
    public void shouldReturnBadRequestTestingWhisoutAmount(){
        Long fromAccountId = 1L;
        Long toAccountId = 2L;

        ResponseEntity<TransactionDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/transfer/" + fromAccountId + "/" + toAccountId,
                        null,
                        TransactionDto.class
                );

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());


    }

}
