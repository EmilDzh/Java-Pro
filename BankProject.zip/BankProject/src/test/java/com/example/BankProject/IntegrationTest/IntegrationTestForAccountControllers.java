package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.AccountRepo;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.http.HttpStatus.CREATED;

//@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IntegrationTestForAccountControllers {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private AccountRepo accountRepo;

    @Autowired
    private TestRestTemplate restTemplate;



    @Test
    public void shouldReturnAllAccounts() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        ResponseEntity<AccountDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/accounts",
                        AccountDto[].class
                );

        int expectedNumberOfAccounts = 2;

        assertEquals(HttpStatus.OK, response.getStatusCode());

        // Проверьте, что в ответе содержится ожидаемое количество аккаунтов
        AccountDto[] accounts = response.getBody();
        assertNotNull(accounts);
        assertEquals(expectedNumberOfAccounts, accounts.length);


    }


    @Test
    public void shouldReturnAccountById() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        long accountId = 1L;

        ResponseEntity<AccountDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/accounts/" + accountId,
                        AccountDto.class
                );


        assertEquals(HttpStatus.OK, response.getStatusCode());

        AccountDto accountDto = response.getBody();
        System.out.println(accountDto);
        assertNotNull(accountDto);

    }

    @Test
    public void shouldReturnNotFoundForNotExistingAccount() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long accountId = 999L;

        ResponseEntity<AccountDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/accounts/" + accountId,
                        AccountDto.class
                );


        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }



    @Test
    public void createAccount() {

        Long clientId = 1L;

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"newTestAcc\", \"type\" : \"CHECKING\", \"status\" : \"ACTIVE\", " +
                        "\"balance\" : \"1000.00\", \"currency_code\" : \"EUR\"}",
                headers
        );
        System.out.println("Before: " + accountRepo.count());

        assertEquals(accountRepo.count(), 2);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/accounts",
                        request,
                        String.class,
                        clientId
                );

        String result = response.getBody();

        System.out.println("After: " + accountRepo.count());
        System.out.println("Result from server: " + result);

        assertEquals(accountRepo.count(), 3);
        assertEquals(response.getStatusCode(), CREATED);


    }

    @Test
    public void checkFieldsOfCreatedAccount() throws JSONException {

        Long clientId = 1L;

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"\", \"type\" : \"CHECKING\", \"status\" : \"ACTIVE\", " +
                        "\"balance\" : \"1000.00\", \"currency_code\" : \"EUR\"}",
                headers
        );
        System.out.println("Before: " + accountRepo.count());

        assertEquals(accountRepo.count(), 2);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/accounts",
                        request,
                        String.class,
                        clientId
                );

        String result = response.getBody();

        System.out.println("After: " + accountRepo.count());
        System.out.println("Result from server: " + result);

        JSONObject jsonObject = new JSONObject(result);
        System.out.println(jsonObject);
        assertTrue(jsonObject.has("name"));

        assertEquals(accountRepo.count(), 3);
        assertEquals(response.getStatusCode(), CREATED);


    }

    @Test
    public void shouldUpdateAccount() {

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long clientId = 1L;

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"name\" : \"newTestAcc\", \"type\" : \"CHECKING\", \"status\" : \"ACTIVE\", " +
                        "\"balance\" : \"1000.00\", \"currency_code\" : \"EUR\"}",
                headers
        );

        ResponseEntity<AccountDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/accounts",
                        createRequest,
                        AccountDto.class,
                        clientId
                );

        assertEquals(CREATED, createResponse.getStatusCode());

        AccountDto createdAccount = createResponse.getBody();
        assertNotNull(createdAccount);

        Long accountID = createdAccount.getId();

//      обновляем АккаунтДто
        createdAccount.setName("updatedTestAcc");
        createdAccount.setBalance(new BigDecimal("2000.00"));

        HttpEntity<AccountDto> updateRequest = new HttpEntity<>(createdAccount, headers);

        ResponseEntity<AccountDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/accounts/" + accountID + "/" + clientId,
                        HttpMethod.PUT,
                        updateRequest,
                        AccountDto.class
                );

        assertEquals(HttpStatus.OK, updateResponse.getStatusCode());

        AccountDto updatedAccount = updateResponse.getBody();
        assertNotNull(updatedAccount);

        assertEquals("updatedTestAcc", updatedAccount.getName());
        assertEquals(new BigDecimal("2000.00"), createdAccount.getBalance());

    }

    @Test
    public void shouldDeleteAccount() {

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long clientId = 1L;

        HttpEntity<String> createAccountRequest = new HttpEntity<>(
                "{\"name\" : \"newTestAcc\", \"type\" : \"CHECKING\", \"status\" : \"ACTIVE\", " +
                        "\"balance\" : \"1000.00\", \"currency_code\" : \"EUR\"}",
                headers
        );

        ResponseEntity<AccountDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/accounts",
                        createAccountRequest,
                        AccountDto.class,
                        clientId
                );

        assertEquals(CREATED, createResponse.getStatusCode());
        assertNotNull(createResponse.getBody());

        AccountDto accountDto = createResponse.getBody();
        Long createdAccId = accountDto.getId();

        // удаляем аккаунт
        ResponseEntity<String> deleteResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/accounts/" + createdAccId,
                        HttpMethod.DELETE,
                        null,
                        String.class,
                        createdAccId
                );

        assertEquals(HttpStatus.NO_CONTENT, deleteResponse.getStatusCode());

        ResponseEntity<AccountDto> check = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/accounts/" + createdAccId,
                        AccountDto.class,
                        createdAccId
                );

        assertEquals(HttpStatus.NOT_FOUND, check.getStatusCode());
    }


    @Test
    public void shouldReturnBalance() {


        Long accountId = 1L;

        ResponseEntity<BigDecimal> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/balance/" + accountId,
                        BigDecimal.class,
                        accountId
                );
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(new BigDecimal("5000.00"), response.getBody());

    }

    @Test
    public void shouldReturnNotFoundForNotExistingAccountBalance() {


        Long accountId = 999L;

        ResponseEntity<BigDecimal> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/balance/" + accountId,
                        BigDecimal.class,
                        accountId
                );
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldReturnTransactionHistoryById() {

        Long accountId = 1L;

        ResponseEntity<List<Transaction>> response = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/transactions/" + accountId,
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<Transaction>>() {
                        }
                );

        assertEquals(HttpStatus.OK, response.getStatusCode());
        List<Transaction> transactions = response.getBody();

        for (Transaction transaction : transactions) {
            assertNotNull(transaction.getAmount());
        }
    }

    @Test
    public void shouldReturnNotFoundForNonExistingAccount() {

        Long accountId = 999L;

        ResponseEntity<List<Transaction>> response = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/transactions/" + accountId,
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<Transaction>>() {
                        }
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }


}
