INSERT INTO managers (first_name, last_name, Status, Description, Create_at)
VALUES ('Иван', 'Петров', 'ACTIVE', 'Опытный менеджер', NOW()),
       ('Мария', 'Иванова', 'INACTIVE', 'Новый менеджер', NOW());

INSERT INTO clients (CLIENT_STATUS, Client_TAX_CODE, First_name, Last_name, Email, Address, Phone, Created_at, Updated_at, manager_id)
VALUES ('ACTIVE', '123456789', 'Иван', 'Иванов', 'ivan@example.com', 'ул. Примерная, 123', '+123456789', NOW(), NOW(), 1),
       ('ACTIVE', '987654321', 'Мария', 'Петрова', 'maria@example.com', 'ул. Тестовая, 456', '+987654321', NOW(), NOW(), 2),
       ('INACTIVE', '555555555', 'Александр', 'Смирнов', 'alex@example.com', 'ул. Тестовая, 789', '+555555555', NOW(), NOW(), 1),
       ('ACTIVE', '111111111', 'Елена', 'Козлова', 'elena@example.com', 'ул. Тестовая, 987', '+111111111', NOW(), NOW(), 2);