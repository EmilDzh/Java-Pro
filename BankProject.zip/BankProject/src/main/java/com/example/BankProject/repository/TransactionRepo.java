package com.example.BankProject.repository;

import com.example.BankProject.entity.Transaction;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepo extends CrudRepository<Transaction, Long> {
    @Query("SELECT t FROM Transaction t WHERE t.debit_account_id.id = :accountId")
    List<Transaction> findByDebit_account_id(Long accountId);

    @Query("SELECT t FROM Transaction t WHERE t.credit_account_id.id = :accountId")
    List<Transaction> findByCredit_account_id(Long accountId);
}

