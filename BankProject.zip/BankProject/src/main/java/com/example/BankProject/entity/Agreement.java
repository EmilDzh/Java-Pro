package com.example.BankProject.entity;

/*   Agreement
    - id: Unique identifier for the agreement.
	- account_id: Identifier of client's account.
	- product_id: Identifier of associated product.
	- interest_rate: Current interest rate of agreement.
	- status: Agreement status (active, closed, etc.).
	- sum: Agreement amount.
	- created_at: Date and time of record creation.
	- updated_at: Date and time of last update.
	*/


import com.example.BankProject.entity.Enum.AgreementStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "Agreements")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Agreement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Interest_rate", nullable = false)
    private BigDecimal interest_rate;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status",nullable = false)
    private AgreementStatus status;

    @Column(name = "Sum", nullable = false)
    private BigDecimal sum;

    @Column(name = "Created_at",nullable = false)
    private Timestamp created_at;

    @Column(name = "Updated_at",nullable = false)
    private Timestamp updated_at;

    @PrePersist
    private void onCreate(){
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @PreUpdate
    private void onUpdate(){
        updated_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @ManyToOne
    @JoinColumn(name = "product_id",nullable = false)
    @JsonIgnore
    private Product product;


    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    @JsonIgnore
    private Account account;


}
