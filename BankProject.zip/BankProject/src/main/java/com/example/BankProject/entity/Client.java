package com.example.BankProject.entity;

import com.example.BankProject.entity.Enum.ClientStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Set;

/*
 Entity	Fields and their Descriptions
    Client
    - id: Unique identifier for the client.
	- manager_id: Identifier of associated manager.
	- status: Client's status (active, inactive, etc.).
	- tax_code: Client's tax code (external ID).
	- first_name: Client's first name.
	- last_name: Client's last name.
	- email: Client's email.
	- address: Client's address.
	- phone: Client's phone number.
	- created_at: Date and time of record creation.
	- updated_at: Date and time of last update.

  */

@Entity
@Table(name = "Clients")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "CLIENT_STATUS", nullable = false)
    private ClientStatus status;

    @Column(name = "Client_TAX_CODE", nullable = false)
    private String tax_code;

    @Column(name = "First_name", length = 50, nullable = false, unique = false)
    private String first_name;

    @Column(name = "Last_name", length = 50, nullable = false, unique = false)
    private String last_name;

    @Column(name = "Email", nullable = false, unique = true)
    @Email
    private String email;

    @Column(name = "Address", length = 50, nullable = false, unique = false)
    private String address;

    @Column(name = "Phone", nullable = false)
    @Pattern(regexp = "\\+[0-9]+")
    private String phone;

    @Column(name = "Created_at", nullable = false)
    private Timestamp created_at;

    @Column(name = "Updated_at", nullable = false)
    private Timestamp updated_at;

    @Column(name = "Username", length = 50, unique = true, nullable = false)
    private String username;

    @Column(name = "Password", nullable = false)
    private String password;

    @Column(name = "Role", length = 50, nullable = false)
    private String role;

    @PrePersist
    public void onCreate() {
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @PreUpdate
    public void onUpdate() {
        updated_at = Timestamp.valueOf(LocalDateTime.now());
    }

    public Client(ClientStatus status, String tax_code, String first_name, String last_name, String email,String address, String phone, Timestamp updated_at, String username, String password, String role){
        this.status = status;
        this.tax_code = tax_code;
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.updated_at = updated_at;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    @OneToMany(
            mappedBy = "client",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST,CascadeType.MERGE}
    )
    private Set<Account> accounts;

    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false)
    @JsonIgnore
    private Manager manager;

}
