package com.example.BankProject.repository;

import com.example.BankProject.entity.Agreement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgreementRepo extends CrudRepository<Agreement, Long> {
}
