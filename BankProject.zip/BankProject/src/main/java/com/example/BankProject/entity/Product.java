package com.example.BankProject.entity;

import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.entity.Enum.ProductStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.persistence.Entity;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/*   Product
    - id: Unique identifier for the product.
	- manager_id: Identifier of associated manager.
	- name: Product name.
	- status: Product status (active, inactive, etc.).
	- currency_code: Product's currency.
	- interest_rate: Product's interest rate.
	- limit: Credit limit for the product.
	- created_at: Date and time of record creation.
	- updated_at: Date and time of last update.
	*/
@Entity
@Table(name = "Products")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Name", length = 50, nullable = false, unique = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status")
    private ProductStatus status;

    @Enumerated(EnumType.STRING)
    @Column(name = "Currency_code",length = 3,nullable = false, unique = false)
    private CurrencyCode currency_code;

    @Column(name = "Interest_rate", columnDefinition = "Decimal(10, 2) default '0.0'",nullable = false)
    private BigDecimal interest_rate;

    @Column(name = "limit_amount", nullable = false)
    private Integer limit;

    @Column(name = "Created_at", nullable = false)
    private Timestamp created_at;

    @Column(name = "Updated_at", nullable = false)
    private Timestamp updated_at;

    @PrePersist
    private void onCreate(){
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @PreUpdate
    private void onUpdate(){
        updated_at = Timestamp.valueOf(LocalDateTime.now());
    }

    public Product(String name, ProductStatus status, CurrencyCode currency_code, BigDecimal interest_rate, Integer limit, Timestamp updated_at){

        this.name = name;
        this.status = status;
        this.currency_code = currency_code;
        this.interest_rate = interest_rate;
        this.limit = limit;
        this.updated_at = updated_at;
    }





    @OneToMany(
            mappedBy = "product",
            cascade = {CascadeType.PERSIST,CascadeType.MERGE}
    )
    private Set<Agreement> agreements;

    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false)
    @JsonIgnore
    private Manager manager;



}
