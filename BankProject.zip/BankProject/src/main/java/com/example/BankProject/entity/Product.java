package com.example.BankProject.entity;

import com.example.BankProject.entity.Enum.ProductStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/*   Product
    - id: Unique identifier for the product.
	- manager_id: Identifier of associated manager.
	- name: Product name.
	- status: Product status (active, inactive, etc.).
	- currency_code: Product's currency.
	- interest_rate: Product's interest rate.
	- limit: Credit limit for the product.
	- created_at: Date and time of record creation.
	- updated_at: Date and time of last update.
	*/
@Entity
@Table(name = "Products")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Name", length = 50, nullable = false, unique = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status")
    private ProductStatus status;

    @Enumerated(EnumType.STRING)
    @Column(name = "Currency_code",length = 3,nullable = false, unique = true)
    private String currency_code;

    @Column(name = "Interest_rate", columnDefinition = "Decimal(10, 2) default '0.0'",nullable = false)
    private BigDecimal interest_rate;

    @Column(name = "Limit", nullable = false)
    private Integer limit;

    @Column(name = "Created_at", nullable = false)
    private Timestamp created_at;

    @Column(name = "Updated_at", nullable = false)
    private Timestamp updated_at;

    @PrePersist
    private void onCreate(){
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @PreUpdate
    private void onUpdate(){
        updated_at = Timestamp.valueOf(LocalDateTime.now());
    }


    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false)
    @JsonIgnore
    private Manager manager;


    @OneToMany(
            mappedBy = "product",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST,CascadeType.MERGE}
    )
    private Set<Agreement> agreements;



}
