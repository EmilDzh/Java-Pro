package com.example.BankProject.dto;

import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Enum.ClientStatus;
import com.example.BankProject.entity.Manager;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClientDto {

    private Long id;

    private ClientStatus status;

    private String tax_code;

    private String first_name;

    private String last_name;

    private String email;

    private String address;

    private String phone;

    private Timestamp created_at;

    private Timestamp updated_at;

    private String username;

    private String password;

    private String role;

    private Set<AccountDto> accountDtosSet = new HashSet<>();

    @JsonIgnore
    private ManagerDto managerDto;

    public ClientDto(Long id, ClientStatus status, String taxCode, String firstName, String lastName, String email, String address, String phone, Timestamp updatedAt, String username, String password, String role){

        this.id = id;
        this.status = status;
        this.tax_code = taxCode;
        this.first_name = firstName;
        this.last_name = lastName;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.updated_at = updatedAt;
        this.username = username;
        this.password = password;
        this.role = role;
    }
}
