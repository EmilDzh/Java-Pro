package com.example.BankProject.periodicTask;

import org.springframework.boot.CommandLineRunner;


public class PeriodicTask implements CommandLineRunner {


    @Override
    public void run(String... args) throws Exception {
        System.out.println("in Progress");
    }
}
