package com.example.BankProject.entity.Enum;

public enum AgreementStatus {
    ACTIVE("Active"),
    CLOSED("Closed"),
    PENDING("Pending"),
    EXPIRED("Expired");

    private final String label;

    AgreementStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
