package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.entity.Client;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring", uses = ClientMapper.class)
public interface ClientMapper {

    ClientMapper clientMapper = Mappers.getMapper(ClientMapper.class);

    @Mapping(source = "accounts", target = "accountDtosSet")
    @Mapping(source = "manager", target = "managerDto")

    ClientDto fromClientToDto(Client client);

    List<ClientDto> toDtoList(Iterable<Client> clients);

    @Mapping(source = "accountDtosSet", target = "accounts")
    @Mapping(source = "managerDto", target = "manager")
    @Mapping(source = "updated_at", target = "updated_at")
    Client fromDtoToClient(ClientDto clientDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }

    @Mapping(target = "id", ignore = true)
    void updateClientFromDto(ClientDto clientDto, @MappingTarget Client client);


}
