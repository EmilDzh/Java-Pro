package com.example.BankProject.locker;

import com.example.BankProject.entity.Client;
import com.example.BankProject.repository.ClientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class ClientDetailSource implements UserDetailsService {

    @Autowired
    private ClientRepo clientRepo;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Client client = clientRepo.getClientByUsername(username);
        if (client == null){
            throw new UsernameNotFoundException("user with username " + username + " not found");
        }

        return new ClientUserData(client);
    }
}
