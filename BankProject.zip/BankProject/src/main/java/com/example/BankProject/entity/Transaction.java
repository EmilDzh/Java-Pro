package com.example.BankProject.entity;

/*
User
Transaction
	- id: Unique identifier for the transaction.
	- debit_account_id: Identifier of debit account.
	- credit_account_id: Identifier of credit account.
	- type: Transaction type (transfer, deposit, etc.).
	- amount: Transaction amount in account currency.
	- description: Transaction description.
	- created_at: Date and time of record creation.
  */

import com.example.BankProject.entity.Enum.TransactionType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "Transactions")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;


    @ManyToOne
    @JoinColumn(name = "DEBIT_ACCOUNT_ID", nullable = false)
    @JsonIgnore
    Account debit_account_id;

    @ManyToOne
    @JoinColumn(name = "CREDIT_ACCOUNT_ID", nullable = false)
    @JsonIgnore
    Account credit_account_id;

    @Enumerated(EnumType.STRING)
    @Column(name = "Transaction_TYPE", nullable = false)
    TransactionType type;

    @Column(name = "Transaction_AMOUNT", columnDefinition = "Decimal(10, 2) default '0.0'", nullable = false)
    BigDecimal amount;

    @Column(name = "Transaction_description" , nullable = false)
    String description;

    @Column(name = "Transaction_CREATED_AT" , nullable = false)
    Timestamp created_at;

    @PrePersist
    private void onCreated(){
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

}
