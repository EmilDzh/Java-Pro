package com.example.BankProject.entity;

import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import com.example.BankProject.entity.Enum.CurrencyCode;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;


/*    Account
    - id: Unique identifier for the account.
	- client_id: Identifier of account's owner.
	- name: Account name.
	- type: Account type (e.g., savings, current).
	- status: Account status (active, blocked, etc.).
	- balance: Account balance in specified currency.
	- currency_code: Account's currency code.
	- created_at: Date and time of record creation.
	- updated_at: Date and time of last update. */
@Entity
@Table(name = "Accounts")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    Long client_id;

    @Column(name = "ACCOUNT_NAME", length = 50, nullable = false, unique = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "ACCOUNT_TYPE", nullable = false)
    private AccountType type;

    @Enumerated(EnumType.STRING)
    @Column(name = "ACCOUNT_STATUS", nullable = false)
    private AccountStatus status;

    @Column(name = "ACCOUNT_BALANCE", columnDefinition = "Decimal(10, 2) default '0.0'", nullable = false)
    private BigDecimal balance;

    @Enumerated(EnumType.STRING)
    @Column(name = "CURRENCY_CODE", length = 3,nullable = false)
    private CurrencyCode currency_code;

    @Column(name = "CREATED_AT", nullable = false)
    private Timestamp created_at;

    @Column(name = "UPDATED_AT", nullable = false)
    private Timestamp updated_at;

    @PrePersist
    private void onCreate() {
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @PreUpdate
    private void onUpdate() {
        updated_at = Timestamp.valueOf(LocalDateTime.now());
    }

    // DebitTransaction
    @OneToMany(
            mappedBy = "debit_account_id",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}

    )
    private Set<Transaction> debitTransactions;

    // CreditTransaction

    @OneToMany(
            mappedBy = "credit_account_id",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private Set<Transaction> creditTransactions;

    // Client

    @ManyToOne
    @JoinColumn(name = "Client_id", nullable = false)
    @JsonIgnore
    private Client client;

    // Credit

    @ManyToMany(
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    @JoinTable(
            name = "Account_Credit",
            joinColumns = @JoinColumn(name = "account_id"),
            inverseJoinColumns = @JoinColumn(name = "credit_id")
    )
    private Set<Credit> credits = new HashSet<>();


    @OneToMany(
            mappedBy = "account",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private Set<Agreement> agreements;


}
