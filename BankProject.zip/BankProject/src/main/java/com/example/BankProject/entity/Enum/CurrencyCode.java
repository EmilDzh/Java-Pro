package com.example.BankProject.entity.Enum;

public enum CurrencyCode {
    USD("US Dollar"),
    EUR("Euro"),
    GBP("British Pound"),
    JPY("Japanese Yen");


    private final String label;

    CurrencyCode(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
