package com.example.BankProject.services;

import com.example.BankProject.entity.Manager;
import com.example.BankProject.repository.ManagerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ManagerService {

    @Autowired
    public ManagerRepo managerRepo;

    public Iterable<Manager> getAllManagers() {
        return managerRepo.findAll();
    }

    public Optional<Manager> getManagerById(Long id) {
        return managerRepo.findById(id);
    }

    public Manager createManager(Manager manager) {

        return managerRepo.save(manager);
    }

    public Manager updateManager(Long id, Manager manager) {
        if (managerRepo.existsById(id)) {
            manager.setId(id);
            return managerRepo.save(manager);
        }
        return null;
    }

    public void deleteManagerById(
            Long id
    ) {
        managerRepo.deleteById(id);
    }


}
