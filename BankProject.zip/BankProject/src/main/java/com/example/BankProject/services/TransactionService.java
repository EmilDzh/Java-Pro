package com.example.BankProject.services;

import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Enum.TransactionType;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.TransactionRepo;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.util.Optional;



@Service
public class TransactionService {

    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    private AccountService accountService;

    private static final Logger logger = LoggerFactory.getLogger(TransactionService.class);




    public Iterable<Transaction> getAllTransactions() {
        return transactionRepo.findAll();
    }

    public Optional<Transaction> getTransactionById(
            Long id
    ) {
        if (transactionRepo.existsById(id)) {
            return transactionRepo.findById(id);
        }

        return Optional.empty();
    }

    @Transactional
    public Transaction transfer(
            Long fromAccountId,
            Long toAccountId,
            BigDecimal amount
    ) {
        logger.info("transfer started");

        // Проверка наличия денег на счете
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            logger.error("Invalid transfer amount");
            return null;
        }

        // Использование Optional
        Optional<Account> fromAccountOptional = accountService.getAccountById(fromAccountId);
        Optional<Account> toAccountOptional = accountService.getAccountById(toAccountId);

        if (fromAccountOptional.isEmpty() || toAccountOptional.isEmpty()) {
            logger.error("One or both accounts not found");
            return null;
        }

        Account fromAccount = fromAccountOptional.get();
        Account toAccount = toAccountOptional.get();
        logger.info("accounts found");

        // Проверка наличия достаточного баланса
        if (fromAccount.getBalance().compareTo(amount) < 0) {
            logger.error("Insufficient funds");
            return null;
        }
        logger.info("enough money");

        // Обновление баланса
        fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
        toAccount.setBalance(toAccount.getBalance().add(amount));
        logger.info("setBalance accepted");

        // Использование @Modifying запроса (предполагается, что в вашем репозитории есть метод для обновления баланса)
        accountService.updateBalance(fromAccountId, fromAccount.getBalance());
        accountService.updateBalance(toAccountId, toAccount.getBalance());
        logger.info("updateBalance ok");

        // Создание и сохранение транзакции
        Transaction transaction = new Transaction();
        transaction.setType(TransactionType.TRANSFER);
        transaction.setAmount(amount);
        transaction.setDescription("Verwendungszweck ist Unterstützung");
        transaction.setDebit_account_id(fromAccount);
        transaction.setCredit_account_id(toAccount);

        try {
            transactionRepo.save(transaction);
            logger.info("transaction saved");
            return transaction;
        } catch (Exception e) {
            logger.error("Failed to save transaction", e);
            // Обработка ошибки при сохранении транзакции
            return null;
        }
    }
}
