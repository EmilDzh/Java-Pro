package com.example.BankProject.dto;

import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.entity.Enum.ProductStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto {

    private Long id;

    private String name;

    private ProductStatus status;

    private CurrencyCode currency_code;

    private BigDecimal interest_rate;

    private Integer limit;

    private Timestamp created_at;

    private Timestamp updated_at;

    private Set<AgreementDto> agreementDtos;

    @JsonIgnore
    private ManagerDto managerDto;

    public ProductDto(Long id, String name, ProductStatus status, CurrencyCode currencyCode, BigDecimal interestRate, Integer limit, Timestamp updatedAt) {

        this.id = id;
        this.name = name;
        this.status = status;
        this.currency_code = currencyCode;
        this.interest_rate = interestRate;
        this.limit = limit;
        this.updated_at = updatedAt;
    }


}
