package com.example.BankProject.dto;

import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Enum.ManagerStatus;
import com.example.BankProject.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ManagerDto {

    private Long id;

    private String first_name;

    private String last_name;

    private ManagerStatus status;

    private String description;

    private Timestamp created_at;

    private String username;

    private String password;

    private String role;

    private Set<ClientDto> clientDtos = new HashSet<>();

    private List<ProductDto> productDtos = new ArrayList<>();

    public ManagerDto(Long id, String first_name,String last_name, ManagerStatus status, String description, Timestamp created_at, String username, String password, String role){

        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.status = status;
        this.description = description;
        this.created_at = created_at;
        this.username = username;
        this.password = password;
        this.role = role;
    }
}
