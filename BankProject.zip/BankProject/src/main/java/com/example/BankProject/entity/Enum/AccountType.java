package com.example.BankProject.entity.Enum;

public enum AccountType {
    SAVINGS("Savings"),
    CHECKING("Checking"),
    LOAN("Loan");

    private final String label;

    AccountType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
    }
