package com.example.BankProject.dto;

import com.example.BankProject.entity.Enum.TransactionType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDto {

    private Long id;

    @JsonIgnore
    private AccountDto debit_accountDto_id;

    @JsonIgnore
    private AccountDto credit_accountDto_id;

    private TransactionType type;

    private BigDecimal amount;

    private String description;

    private Timestamp created_at;



    public TransactionDto(Long id, TransactionType type, BigDecimal amount, String description, Timestamp created_at){

        this.id = id;
        this.type = type;
        this.amount = amount;
        this.description = description;
        this.created_at = created_at;
    }


}
