package com.example.BankProject.locker;

import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.repository.ClientRepo;
import com.example.BankProject.repository.ManagerRepo;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Service
public class BankUserDetailsService implements UserDetailsService {

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    private ManagerRepo managerRepo;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Client client = clientRepo.getClientByUsername(username);
        if (client == null){
            Manager manager = managerRepo.getManagerByUsername(username);
            if (manager == null){
                throw new UsernameNotFoundException("Manager with" + username + " manager name not found");
            }
            return new ManagerUserData(manager);
        }
        return new ClientUserData(client);
    }
}
