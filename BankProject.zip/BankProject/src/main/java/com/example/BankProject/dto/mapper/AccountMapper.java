package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.entity.Account;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AccountMapper {

    @Mapping(source = "client.id", target = "clientId")
    AccountDto accountToAccountDTO(Account account);

    @Mapping(target = "client", ignore = true)
    Account accountDTOToAccount(AccountDto accountDto);


}
