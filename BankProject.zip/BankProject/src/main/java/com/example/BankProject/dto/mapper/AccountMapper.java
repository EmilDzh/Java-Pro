package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.entity.Account;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring", uses = AccountMapper.class)
public interface AccountMapper {
    AccountMapper accountMapper = Mappers.getMapper(AccountMapper.class);


    @Mapping(source = "debitTransactions", target = "debitTransactionsDto")
    @Mapping(source = "creditTransactions", target = "creditTransactionsDto")
    @Mapping(source = "client", target = "clientDto")
    @Mapping(source = "agreements", target = "agreementDtos")
    AccountDto fromAccountToDto(Account account);

    List<AccountDto> toDtoList(Iterable<Account> accounts);


    @Mapping(source = "debitTransactionsDto", target = "debitTransactions")
    @Mapping(source = "creditTransactionsDto", target = "creditTransactions")
    @Mapping(source = "clientDto", target = "client")
    @Mapping(source = "agreementDtos", target = "agreements")
    @Mapping(source = "updated_at", target = "updated_at")
    Account fromDtoToAccount(AccountDto accountDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }

    @Mapping(target = "id", ignore = true)
    void updateAccountFromDto(AccountDto accountDto, @MappingTarget Account account);
}
