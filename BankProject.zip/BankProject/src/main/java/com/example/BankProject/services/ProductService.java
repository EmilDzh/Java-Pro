package com.example.BankProject.services;

import com.example.BankProject.entity.Product;
import com.example.BankProject.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    public ProductRepo productRepo;

    public Iterable<Product> getAllProducts() {
        return productRepo.findAll();
    }


    public Optional<Product> getProductById(
            @PathVariable Long id
    ) {
        return productRepo.findById(id);

    }

    public Product createProduct(Product product) {

        return productRepo.save(product);
    }

    public Product updateProductById(
            Long id,
            Product product
    ) {
        if (productRepo.existsById(id)) {
            product.setId(id);
            return productRepo.save(product);
        }
        return null;
    }

    public void deleteProductById(Long id) {

        productRepo.deleteById(id);
    }
}
