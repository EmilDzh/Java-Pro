package com.example.BankProject.services;

import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.dto.mapper.ProductMapper;
import com.example.BankProject.entity.Product;
import com.example.BankProject.repository.ProductRepo;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    public ProductRepo productRepo;

    @Autowired
    public ProductMapper productMapper;

    public Iterable<ProductDto> getAllProducts() {
        Iterable<Product> products = productRepo.findAll();
        return productMapper.toDtoList(products);
    }


    public Optional<ProductDto> getProductById(
            @PathVariable Long id
    ) {
        return productRepo.findById(id)
                .map(p -> productMapper.fromProductToDto(p));
    }

    public ProductDto createProduct(ProductDto productDto) {
        Product product = productMapper.fromDtoToProduct(productDto);
        Product savedProduct = productRepo.save(product);
        return productMapper.fromProductToDto(savedProduct);
    }

    public ProductDto updateProductById(
            Long id,
            ProductDto productDto
    ) {
        Optional<Product> product = productRepo.findById(id);

        if (product.isPresent()){
            Product product1 = product.get();

            productMapper.updateProductFromDto(productDto, product1);

            Product updatedProduct = productRepo.save(product1);

            return productMapper.fromProductToDto(updatedProduct);
        }

        throw new EntityNotFoundException("Product with id + " + id + " not found");

    }

    public void deleteProductById(Long id) {
        Optional<Product> product = productRepo.findById(id);

        if (product.isPresent()){
            Product product1 = product.get();
            productRepo.delete(product1);
        } else {
            throw new EntityNotFoundException("Product with id + " + id + " not found");
        }
    }
}
