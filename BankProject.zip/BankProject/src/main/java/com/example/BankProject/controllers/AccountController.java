package com.example.BankProject.controllers;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.services.AccountService;
import com.example.BankProject.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;


@RestController
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private ClientService clientService;

    @GetMapping("/accounts")
    public Iterable<AccountDto> getAllAccounts() {

        return accountService.getAllAccounts();
    }

    //http://localhost:8080/accounts
    @GetMapping("/accounts/{id}")
    public ResponseEntity<AccountDto> getAccountById(
            @PathVariable Long id
    ) {
        Optional<AccountDto> account = accountService.getAccountById(id);
        return account.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/admin/clients/{clientId}/accounts")
    public ResponseEntity<AccountDto> createAccount(
            @PathVariable Long clientId,
            @RequestBody AccountDto accountDto
    ) {
        Optional<ClientDto> clientDto = clientService.getClientById(clientId);

        if (clientDto.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        accountDto.setClientDto(clientDto.get());

        AccountDto createdAccountDto = accountService.createAccount(accountDto);
        return new ResponseEntity<>(createdAccountDto, HttpStatus.CREATED);
    }

    @PutMapping("/admin/accounts/{id}/{clientId}")
    public ResponseEntity<AccountDto> updateAccount(
            @PathVariable(name = "id") Long id,
            @PathVariable(name = "clientId") Long clientId,
            @RequestBody AccountDto updatedAccountDto
    ) {
        Optional<ClientDto> clientDto = clientService.getClientById(clientId);

        if (clientDto.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        updatedAccountDto.setClientDto(clientDto.get());

        AccountDto accountDto = accountService.updateAccount(id, updatedAccountDto);
        return accountDto != null ?
                new ResponseEntity<>(accountDto, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);

    }

    @DeleteMapping("/admin/accounts/{id}")
    public ResponseEntity<Void> deleteAccount(
            @PathVariable Long id
    ) {
        accountService.deleteAccount(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/balance/{id}")
    public ResponseEntity<BigDecimal> getAccountBalance(
            @PathVariable Long id
    ) {
        AccountDto accountDto = accountService.getAccountById(id).orElse(null);

        if (accountDto == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(accountDto.getBalance(), HttpStatus.OK);
    }

    @GetMapping("/transactions/{accountId}")
    public ResponseEntity<List<Transaction>> getTransactionHistoryById(
            @PathVariable Long accountId
    ) {
        if(accountService.getAccountById(accountId).isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        List<Transaction> transactions = accountService.getTransactionHistoryById(accountId);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }


}
