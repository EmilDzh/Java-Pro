package com.example.BankProject.controllers;

import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.services.AccountService;
import com.example.BankProject.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;


@RestController
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private ClientService clientService;

    @GetMapping("/accounts")
    public Iterable<Account> getAllAccounts() {

        return accountService.getAllAccounts();
    }

    //http://localhost:8080/accounts
    @GetMapping("/accounts/{id}")
    public ResponseEntity<Account> getAccountById(
            @PathVariable Long id
    ) {
        Optional<Account> account = accountService.getAccountById(id);
        return account.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/clients/{clientId}/accounts")
    public ResponseEntity<Account> createAccount(
            @PathVariable Long clientId,
            @RequestBody Account account
    ) {
        Optional<Client> client = clientService.getClientById(clientId);

        if (client.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        account.setClient(client.get());

        Account createdAccount = accountService.createAccount(account);
        return new ResponseEntity<>(createdAccount, HttpStatus.CREATED);
    }

    @PutMapping("/accounts/{id}/{clientId}")
    public ResponseEntity<Account> updateAccount(
            @PathVariable(name = "id") Long id,
            @PathVariable(name = "clientId") Long clientId,
            @RequestBody Account updatedAccount
    ) {
        Optional<Client> client = clientService.getClientById(clientId);

        if (client.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        updatedAccount.setClient(client.get());

        Account account = accountService.updateAccount(id, updatedAccount);
        return account != null ?
                new ResponseEntity<>(account, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);

    }

    @DeleteMapping("/accounts/{id}")
    public ResponseEntity<Void> deleteAccount(
            @PathVariable Long id
    ) {
        accountService.deleteAccount(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/balance/{id}")
    public ResponseEntity<BigDecimal> getAccountBalance(
            @PathVariable Long id
    ) {
        Account account = accountService.getAccountById(id).orElse(null);

        if (account == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(account.getBalance(), HttpStatus.OK);
    }

    @GetMapping("/transactions/{accountId}")
    public ResponseEntity<List<Transaction>> getTransactionHistoryById(
            @PathVariable Long accountId
    ) {
        if(accountService.getAccountById(accountId).isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        List<Transaction> transactions = accountService.getTransactionHistoryById(accountId);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }


}
