package com.example.BankProject.controllers;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ManagerController {

    @Autowired
    public ManagerService managerService;

    @GetMapping("/admin/managers")
    public Iterable<ManagerDto> getAllManagers() {
        return managerService.getAllManagers();
    }

    @GetMapping("/admin/managers/{id}")
    public ManagerDto getManagerById(
            @PathVariable Long id
    ) {
        return managerService.getManagerById(id).get();
    }


    @PostMapping("/admin/managers/")
    public ResponseEntity<ManagerDto> createManager(
            @RequestBody ManagerDto managerDto

    ) {

        ManagerDto manager1 = managerService.createManager(managerDto);
        return new ResponseEntity<>(manager1, HttpStatus.CREATED);

    }


    @PutMapping("/admin/managers/{id}/")
    public ResponseEntity<ManagerDto> updateManagerById(
            @PathVariable Long id,
            @RequestBody ManagerDto managerDto
    ) {

        ManagerDto managerDto1 = managerService.updateManager(id, managerDto);
        return managerDto1 != null ?
                new ResponseEntity<>(managerDto1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/admin/managers/{id}/")
    public ResponseEntity<Void> deleteManagerByID(

            @PathVariable Long id
    ){
        managerService.deleteManagerById(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
