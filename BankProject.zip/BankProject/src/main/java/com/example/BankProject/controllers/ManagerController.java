package com.example.BankProject.controllers;

import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ManagerController {

    @Autowired
    public ManagerService managerService;

    @GetMapping("/admin/managers")
    public Iterable<Manager> getAllManagers() {
        return managerService.getAllManagers();
    }

    @GetMapping("/admin/managers/{id}")
    public Manager getManagerById(
            @PathVariable Long id
    ) {
        return managerService.getManagerById(id).get();
    }


    @PostMapping("/admin/managers/admin")
    public ResponseEntity<Manager> createManager(
            @RequestBody Manager manager

    ) {

        Manager manager1 = managerService.createManager(manager);
        return new ResponseEntity<>(manager1, HttpStatus.CREATED);

    }


    @PutMapping("/admin/managers/{id}/admin")
    public ResponseEntity<Manager> updateManagerById(
            @PathVariable Long id,
            @RequestBody Manager manager
    ) {

        Manager manager1 = managerService.updateManager(id, manager);
        return manager1 != null ?
                new ResponseEntity<>(manager1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/admin/managers/{id}/admin")
    public ResponseEntity<Void> deleteManagerByID(

            @PathVariable Long id
    ){
        managerService.deleteManagerById(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
