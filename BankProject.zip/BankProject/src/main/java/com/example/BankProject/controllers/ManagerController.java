package com.example.BankProject.controllers;

import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ManagerController {

    @Autowired
    public ManagerService managerService;

    @GetMapping("/managers")
    public Iterable<Manager> getAllManagers() {
        return managerService.getAllManagers();
    }

    @GetMapping("/managers/{id}")
    public Manager getManagerById(
            @PathVariable Long id
    ) {
        return managerService.getManagerById(id).get();
    }


    @PostMapping("/managers")
    public ResponseEntity<Manager> createManager(
            @RequestBody Manager manager

    ) {

        Manager manager1 = managerService.createManager(manager);
        return new ResponseEntity<>(manager1, HttpStatus.CREATED);

    }


    @PutMapping("/managers/{id}")
    public ResponseEntity<Manager> updateManagerById(
            @PathVariable Long id,
            @RequestBody Manager manager
    ) {

        Manager manager1 = managerService.updateManager(id, manager);
        return manager1 != null ?
                new ResponseEntity<>(manager1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/managers/{id}")
    public ResponseEntity<Void> deleteManagerByID(

            @PathVariable Long id
    ){
        managerService.deleteManagerById(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
