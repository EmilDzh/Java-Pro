package com.example.BankProject.databaseInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateDatabase {

    public static final Logger logger = LoggerFactory.getLogger(CreateDatabase.class);

    public static void main(String[] args) {

        String jdbcUrl = "jdbc:mysql://localhost:3306/bank_db";
        String username = "root";
        String password = "Mysqlroot";

        try (
                Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                Statement statement = connection.createStatement();
                )
        {

            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS bank_db;");

            logger.info("Database was created!!!!");


            statement.executeUpdate("USE bank_db;");

            logger.info("Connected to the database");

        } catch (Exception e){
            logger.error(e.getMessage());
        }
    }
}
