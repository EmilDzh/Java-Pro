package com.example.BankProject.controllers;

import com.example.BankProject.entity.Manager;
import com.example.BankProject.entity.Product;
import com.example.BankProject.services.ManagerService;
import com.example.BankProject.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@RestController
public class ProductController {

    @Autowired
    public ProductService productService;

    @Autowired
    public ManagerService managerService;

    @GetMapping("/products")
    public Iterable<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public Product getProductById(@PathVariable Long id) {
        Optional<Product> productOptional = productService.getProductById(id);

        if (productOptional.isPresent()) {
            return productOptional.get();
        } else {
            // Возвращайте, например, статус 404 Not Found, если объект не найден
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found");
        }
    }

    @PostMapping("/admin/products/{managerId}")
    public ResponseEntity<Product> createProduct(
            @PathVariable Long managerId,
            @RequestBody Product product
    ) {
        Optional<Manager> manager = managerService.getManagerById(managerId);

        if (manager.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        product.setManager(manager.get());

        Product product1 = productService.createProduct(product);
        return new ResponseEntity<>(product1, HttpStatus.CREATED);

    }


    @PutMapping("/admin/products/{productId}/{managerId}")
    public ResponseEntity<Product> updateProductById(
            @PathVariable(name = "productId") Long productId,
            @PathVariable(name = "managerId") Long managerId,
            @RequestBody Product product
    ){
        Optional<Manager> manager = managerService.getManagerById(managerId);

        if (manager.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        product.setManager(manager.get());

        Product product1 = productService.updateProductById(productId, product);
        return product1 != null ?
                new ResponseEntity<>(product1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/admin/products/{id}")
    public ResponseEntity<Void> deleteProductById(
            @PathVariable Long id
    ){
        productService.deleteProductById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
