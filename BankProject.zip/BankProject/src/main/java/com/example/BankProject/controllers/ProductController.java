package com.example.BankProject.controllers;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.entity.Product;
import com.example.BankProject.services.ManagerService;
import com.example.BankProject.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@RestController
public class ProductController {

    @Autowired
    public ProductService productService;

    @Autowired
    public ManagerService managerService;

    @GetMapping("/products")
    public Iterable<ProductDto> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public ResponseEntity<ProductDto> getProductById(@PathVariable Long id) {
        Optional<ProductDto> productOptional = productService.getProductById(id);
        return productOptional.map(p -> new ResponseEntity<>(p, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/admin/products/{managerId}")
    public ResponseEntity<ProductDto> createProduct(
            @PathVariable Long managerId,
            @RequestBody ProductDto productDto
    ) {
        Optional<ManagerDto> managerDto = managerService.getManagerById(managerId);

        if (managerDto.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        productDto.setManagerDto(managerDto.get());

        ProductDto product1 = productService.createProduct(productDto);
        return new ResponseEntity<>(product1, HttpStatus.CREATED);

    }


    @PutMapping("/admin/products/{productId}/{managerId}")
    public ResponseEntity<ProductDto> updateProductById(
            @PathVariable(name = "productId") Long productId,
            @PathVariable(name = "managerId") Long managerId,
            @RequestBody ProductDto productDto
    ){
        Optional<ManagerDto> manager = managerService.getManagerById(managerId);

        if (manager.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        productDto.setManagerDto(manager.get());

        ProductDto product1 = productService.updateProductById(productId, productDto);
        return product1 != null ?
                new ResponseEntity<>(product1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/admin/products/{id}")
    public ResponseEntity<Void> deleteProductById(
            @PathVariable Long id
    ){
        productService.deleteProductById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
