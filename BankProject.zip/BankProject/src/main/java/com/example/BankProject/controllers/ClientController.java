package com.example.BankProject.controllers;

import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ClientService;
import com.example.BankProject.services.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
public class ClientController {

    @Autowired
    private ClientService clientService;

    @Autowired
    private ManagerService managerService;


    @GetMapping("/clients")
    public Iterable<Client> getAllClients() {
        return clientService.getAllClients();
    }


    @GetMapping("/clients/{id}")
    public Client getClientById(
            @PathVariable Long id
    ) {

        return clientService.getClientById(id).get();

    }

    @PostMapping("/clients/{managerId}")
    public ResponseEntity<Client> createClient(
            @PathVariable(name = "managerId") Long id,
            @RequestBody Client client
    ) {

        Manager manager = managerService.getManagerById(id).get();

        client.setManager(manager);

        Client createdClient = clientService.createClient(client);
        return new ResponseEntity<>(createdClient, HttpStatus.CREATED);
    }

    @PutMapping("/clients/{clientId}/{managerId}")
    public ResponseEntity<Client> updateClient(
            @PathVariable(name = "clientId") Long clientId,
            @PathVariable(name = "managerId") Long managerId,
            @RequestBody Client client
    ) {

        Optional<Manager> manager = managerService.getManagerById(managerId);

        if (manager.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        client.setManager(manager.get());


        Client upgradedClient = clientService.updateClientById(clientId, client);
        return upgradedClient != null ?
                new ResponseEntity<>(upgradedClient, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    @DeleteMapping("/clients/{id}")
    public ResponseEntity<Void> deleteClient(
            @PathVariable Long id
    ) {
        clientService.deleteClientByID(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
