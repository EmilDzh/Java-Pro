package com.example.BankProject.locker;

import com.example.BankProject.entity.Manager;
import com.example.BankProject.repository.ManagerRepo;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class ManagerDetailSource implements UserDetailsService {

    private ManagerRepo managerRepo;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Manager manager = managerRepo.getManagerByUsername(username);
        if (manager == null){
            throw new UsernameNotFoundException("Manager with managerName " + username + " not found");
        }
        return new ManagerUserData(manager);
    }
}
