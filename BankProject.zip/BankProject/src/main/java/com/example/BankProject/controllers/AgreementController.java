package com.example.BankProject.controllers;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Agreement;
import com.example.BankProject.entity.Product;
import com.example.BankProject.services.AccountService;
import com.example.BankProject.services.AgreementService;
import com.example.BankProject.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class AgreementController {

    @Autowired
    private AgreementService agreementService;

    @Autowired
    private ProductService productService;

    @Autowired
    private AccountService accountService;


    @GetMapping("/agreements")
    public Iterable<AgreementDto> getAllAgreements() {
        return agreementService.getAllAgreements();
    }

    @GetMapping("/agreements/{id}")
    public ResponseEntity<AgreementDto> getAgreementById(
            @PathVariable Long id
    ) {
        Optional<AgreementDto> agreement = agreementService.getAgreementById(id);
        return agreement.map(agreement1 -> new ResponseEntity<>(agreement1, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    @PostMapping("/admin/agreements/{productId}/{accountId}")
    public ResponseEntity<AgreementDto> createAgreement(
            @PathVariable(name = "productId") Long productId,
            @PathVariable(name = "accountId") Long accountId,
            @RequestBody AgreementDto agreementDto
    ) {

        Optional<ProductDto> product = productService.getProductById(productId);
        Optional<AccountDto> account = accountService.getAccountById(accountId);

        if (product.isEmpty() && account.isEmpty()) {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        agreementDto.setProductDto(product.get());
        agreementDto.setAccountDto(account.get());

        AgreementDto agreement = agreementService.createAgreement(agreementDto);
        return new ResponseEntity<>(agreement, HttpStatus.CREATED);

    }

    @PutMapping("/admin/agreements/{agreementId}/{productId}/{accountId}")
    public ResponseEntity<AgreementDto> updateAgreement(
            @PathVariable(name = "agreementId") Long agreementId,
            @PathVariable(name = "productId") Long productId,
            @PathVariable(name = "accountId") Long accountId,
            @RequestBody AgreementDto agreementDto
    ) {
        Optional<ProductDto> product = productService.getProductById(productId);
        Optional<AccountDto> account = accountService.getAccountById(accountId);

        if (product.isEmpty() || account.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        agreementDto.setProductDto(product.get());
        agreementDto.setAccountDto(account.get());

        AgreementDto agreement1 = agreementService.updateAgreementById(agreementId, agreementDto);
        return agreement1 != null ?
                new ResponseEntity<>(agreement1, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/admin/agreements/{id}")
    public ResponseEntity<Void> deleteAgreementById(
            @PathVariable Long id
    ) {
        agreementService.deleteAgreementById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
