package com.example.BankProject.services;

import com.example.BankProject.entity.Agreement;
import com.example.BankProject.repository.AgreementRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AgreementService {

    @Autowired
    private AgreementRepo agreementRepo;

    public Iterable<Agreement> getAllAgreements() {
        return agreementRepo.findAll();
    }

    public Optional<Agreement> getAgreementById(
            Long id
    ) {
        return agreementRepo.findById(id);
    }

    public Agreement createAgreement(
            Agreement agreement
    ) {
        return agreementRepo.save(agreement);
    }

    public Agreement updateAgreementById(
            Long id,
            Agreement agreement
    ) {
        if (agreementRepo.existsById(id)){
            agreement.setId(id);
            return agreementRepo.save(agreement);
        }
        return null;
    }

    public void deleteAgreementById(
            Long id
    ){
        agreementRepo.deleteById(id);
    }
}
