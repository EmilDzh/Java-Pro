package com.example.BankProject.services;

import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.dto.mapper.AgreementMapper;
import com.example.BankProject.entity.Agreement;
import com.example.BankProject.repository.AgreementRepo;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AgreementService {

    @Autowired
    private AgreementRepo agreementRepo;

    @Autowired
    private AgreementMapper agreementMapper;

    public Iterable<AgreementDto> getAllAgreements() {
        Iterable<Agreement> agreements = agreementRepo.findAll();
        return agreementMapper.toDtoList(agreements);
    }

    public Optional<AgreementDto> getAgreementById(
            Long id
    ) {
        Optional<Agreement> agreement = agreementRepo.findById(id);
        return agreement.map(a -> agreementMapper.fromAgreementToDto(a));
    }

    public AgreementDto createAgreement(
            AgreementDto agreementDto
    ) {
        Agreement agreement = agreementMapper.fromDtoToAgreement(agreementDto);
        Agreement savedAgreement = agreementRepo.save(agreement);
        return agreementMapper.fromAgreementToDto(savedAgreement);
    }

    public AgreementDto updateAgreementById(
            Long id,
            AgreementDto agreementDto
    ) {
      Optional<Agreement> agreement = agreementRepo.findById(id);

      if (agreement.isPresent()){
          Agreement agreement1 = agreement.get();

          agreementMapper.updateAgreementFromDto(agreementDto, agreement1);

          Agreement updatedAgreement = agreementRepo.save(agreement1);

          return agreementMapper.fromAgreementToDto(updatedAgreement);
      }

      throw new EntityNotFoundException("Agreement with id + " + id + " not found");
    }

    public void deleteAgreementById(
            Long id
    ){
        Optional<Agreement> agreement = agreementRepo.findById(id);

        if (agreement.isPresent()){
            Agreement agreement1 = agreement.get();
            agreementRepo.delete(agreement1);
        }
        throw new EntityNotFoundException("Agreement with id + " + id + " not found");
    }
}
