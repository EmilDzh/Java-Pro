package com.example.BankProject.repository;

import com.example.BankProject.entity.Account;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface AccountRepo extends CrudRepository<Account, Long> {

    @Modifying
    @Query("UPDATE Account SET balance = :balance WHERE id = :accountId")
    void updateBalance(@Param("accountId") Long accountId, @Param("balance") BigDecimal balance);


}
