package com.example.BankProject.services;

import com.example.BankProject.entity.Account;
import com.example.BankProject.repository.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    public AccountRepo accountRepo;

    public Iterable<Account> getAllAccounts(){
        return accountRepo.findAll();
    }

    public Optional<Account> getAccountById(
             Long id
    )
    {
         return accountRepo.findById(id);
    }


    public Account createAccount(Account account){

        return accountRepo.save(account);
    }

    public Account updateAccount(Long id, Account updatedAccount){

        if (accountRepo.existsById(id)){
            updatedAccount.setId(id);
            return accountRepo.save(updatedAccount);
        } else {

            return null;
        }
    }

    public void deleteAccount(Long id){

        accountRepo.deleteById(id);
    }


}
