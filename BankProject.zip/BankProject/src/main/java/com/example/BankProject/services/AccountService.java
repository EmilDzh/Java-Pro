package com.example.BankProject.services;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.mapper.AccountMapper;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.AccountRepo;
import com.example.BankProject.repository.TransactionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    public AccountRepo accountRepo;

    @Autowired
    public TransactionRepo transactionRepo;

    @Autowired
    public AccountMapper accountMapper;


    public Iterable<Account> getAllAccounts() {
        return accountRepo.findAll();
    }

    public Optional<Account> getAccountById(
            Long id
    ) {
        return accountRepo.findById(id);
    }


//    public Account createAccount(Account account) {
//
//        return accountRepo.save(account);
//    }

    public AccountDto createAccount(AccountDto accountDto){
        Account account = accountMapper.accountDTOToAccount(accountDto);
        Account savedAcc = accountRepo.save(account);
        return accountMapper.accountToAccountDTO(savedAcc);
    }

    public Account updateAccount(Long id, Account updatedAccount) {

        if (accountRepo.existsById(id)) {
            updatedAccount.setId(id);
            return accountRepo.save(updatedAccount);
        } else {

            return null;
        }
    }

    public void deleteAccount(Long id) {

        accountRepo.deleteById(id);
    }

    public BigDecimal getAccountBalance(Long id) {

        Account account = accountRepo.findById(id).orElse(null);
        return account != null ? account.getBalance() : BigDecimal.ZERO;
    }

    public List<Transaction> getTransactionHistoryById(Long accountId) {
        List<Transaction> debitTransactions = transactionRepo.findByDebit_account_id(accountId);
        List<Transaction> creditTransactions = transactionRepo.findByCredit_account_id(accountId);

        // Объединить транзакции из обоих списков
        List<Transaction> allTransactions = new ArrayList<>();
        allTransactions.addAll(debitTransactions);
        allTransactions.addAll(creditTransactions);

        return allTransactions;
    }

    public void updateBalance(Long accountId, BigDecimal newBalance) {
        accountRepo.updateBalance(accountId, newBalance);
    }

}
