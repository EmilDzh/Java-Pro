package com.example.BankProject.entity.Enum;

public enum ManagerStatus {
    ACTIVE("Active"),
    INACTIVE("Inactive"),
    ON_VACATION("On Vacation"),
    AWAY("Away");

    private final String label;

    ManagerStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
