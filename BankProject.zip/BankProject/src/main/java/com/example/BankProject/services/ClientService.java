package com.example.BankProject.services;

import com.example.BankProject.entity.Client;
import com.example.BankProject.repository.ClientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ClientService {

    @Autowired
    public ClientRepo clientRepo;

    public Iterable<Client> getAllClients() {

        return clientRepo.findAll();
    }

    public Optional<Client> getClientById(Long id) {

        return clientRepo.findById(id);
    }

    public Client createClient(
            Client client
    ) {
       return clientRepo.save(client);
    }

    public Client updateClientById(
            Long id,
            Client updatedClient
    ){
      if (clientRepo.existsById(id)){
          updatedClient.setId(id);
          return clientRepo.save(updatedClient);
      } else
          return null;
    }

    public void deleteClientByID(
            Long id
    ){
        clientRepo.deleteById(id);
    }


}
