package com.example.BankProject.databaseInitializer;

import com.example.BankProject.entity.*;
import com.example.BankProject.entity.Enum.*;
import com.example.BankProject.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


@Component
public class DatabaseInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseInitializer.class);

    @Autowired
    private AccountRepo accountRepo;

    @Autowired
    private AgreementRepo agreementRepo;

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    private ManagerRepo managerRepo;

    @Autowired
    private ProductRepo productRepo;

    @Autowired
    private TransactionRepo transactionRepo;


    @Override
    public void run(String... args) throws Exception {

        accountRepo.deleteAll();
        agreementRepo.deleteAll();
        clientRepo.deleteAll();
        managerRepo.deleteAll();
        productRepo.deleteAll();
        transactionRepo.deleteAll();

        Manager manager1 = new Manager("Jana", "Leopold", ManagerStatus.ACTIVE, "experienced manager");
        Manager manager2 = new Manager("Bastian", "Sweinsteiger", ManagerStatus.ACTIVE, "new manager");


        managerRepo.saveAll(Arrays.asList(manager1, manager2));
        logger.info("Manager data added!!!!");

        Client client1 = new Client(ClientStatus.ACTIVE, "7777", "Bilbo", "Baggins", "bilbo@example.com", "Shire str 117", "+999666444321", Timestamp.valueOf(LocalDateTime.now()));
        client1.setManager(manager1);


        Client client2 = new Client(ClientStatus.ACTIVE, "8888", "Frodo", "Baggins", "frodo@example.com", "Shire str 117", "+111222555888", Timestamp.valueOf(LocalDateTime.now()));
        client2.setManager(manager1);


        Client client3 = new Client(ClientStatus.INACTIVE, "5555", "Thorin", "Oakenshield", "thorin@example.com", "Erebor 1", "+555777444111", Timestamp.valueOf(LocalDateTime.now()));
        client3.setManager(manager2);


        Client client4 = new Client(ClientStatus.ACTIVE, "12345", "Aragorn", "Aratorn", "aragorn@example.com", "Gondor str 10", "+44444444444", Timestamp.valueOf(LocalDateTime.now()));
        client4.setManager(manager1);


        Client client5 = new Client(ClientStatus.INACTIVE, "9999", "Fili", "Durinson", "fili@example.com", "Erebor 4", "+1112223336666", Timestamp.valueOf(LocalDateTime.now()));
        client5.setManager(manager2);


        clientRepo.saveAll(Arrays.asList(client1, client2, client3, client4, client5));

        logger.info("Client data added!!!!");

        Account account1 = new Account("BilbosAcc", AccountType.LOAN, AccountStatus.ACTIVE, new BigDecimal(5000), CurrencyCode.EUR, Timestamp.valueOf(LocalDateTime.now()));
        account1.setClient(client1);

        Account account2 = new Account("FrodosAcc", AccountType.CHECKING, AccountStatus.INACTIVE, new BigDecimal(10000), CurrencyCode.GBP, Timestamp.valueOf(LocalDateTime.now()));
        account2.setClient(client2);


        accountRepo.saveAll(Arrays.asList(account1, account2));


        logger.info("Account data added!!!!");

        Transaction transaction1 = new Transaction(TransactionType.DEPOSIT, new BigDecimal("200"), "transaction Test 1");
        transaction1.setDebit_account_id(account1);
        transaction1.setCredit_account_id(account2);

        transactionRepo.save(transaction1);

        logger.info("Transaction data added!!!!");

        Product product1 = new Product("Product1", ProductStatus.ACTIVE, CurrencyCode.EUR, new BigDecimal("3.2"), 10, Timestamp.valueOf(LocalDateTime.now()));
        Product product2 = new Product("Product2", ProductStatus.ACTIVE, CurrencyCode.EUR, new BigDecimal("1.5"), 5, Timestamp.valueOf(LocalDateTime.now()));
        Product product3 = new Product("Product3", ProductStatus.INACTIVE, CurrencyCode.EUR, new BigDecimal("0.5"), 6, Timestamp.valueOf(LocalDateTime.now()));
        Product product4 = new Product("Product4", ProductStatus.ACTIVE, CurrencyCode.EUR, new BigDecimal("4.5"), 7, Timestamp.valueOf(LocalDateTime.now()));
        Product product5 = new Product("Product5", ProductStatus.INACTIVE, CurrencyCode.EUR, new BigDecimal("5.5"), 8, Timestamp.valueOf(LocalDateTime.now()));

        product1.setManager(manager1);
        Agreement agreement1 = null;
        Agreement agreement2 = null;


        product2.setManager(manager2);


        product3.setManager(manager1);
        Agreement agreement3 = null;


        product4.setManager(manager1);


        product5.setManager(manager2);



        productRepo.saveAll(Arrays.asList(product1, product2, product3, product4, product5));

        logger.info("Product data added!!!!");


        agreement1 = new Agreement(new BigDecimal("3.0"), AgreementStatus.ACTIVE, new BigDecimal("400"), Timestamp.valueOf(LocalDateTime.now()));
        agreement1.setAccount(account1);
        agreement1.setProduct(product1);

        agreement2 = new Agreement(new BigDecimal("4.0"), AgreementStatus.CLOSED, new BigDecimal("1300"), Timestamp.valueOf(LocalDateTime.now()));
        agreement2.setAccount(account2);
        agreement2.setProduct(product2);

        agreement3 = new Agreement(new BigDecimal("5.0"), AgreementStatus.ACTIVE, new BigDecimal("6000"), Timestamp.valueOf(LocalDateTime.now()));
        agreement3.setAccount(account1);
        agreement3.setProduct(product3);

        agreementRepo.saveAll(Arrays.asList(agreement1, agreement2, agreement3));


        logger.info("Agreement data added!!!!");


    }
}
