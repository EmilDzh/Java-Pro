package com.example.BankProject.dto;

import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import com.example.BankProject.entity.Enum.CurrencyCode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDto {

    private Long id;
    private String name;
    private AccountType type;
    private AccountStatus status;
    private BigDecimal balance;
    private CurrencyCode currencyCode;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private Long clientId;

    public AccountDto(String name, AccountType type, AccountStatus status,BigDecimal balance, CurrencyCode currency_code, Timestamp updated_at){
        this.name = name;
        this.type = type;
        this.status = status;
        this.balance = balance;
        this.currencyCode = currency_code;
        this.updatedAt = updated_at;
    }


}
