package com.example.BankProject.dto;

import com.example.BankProject.entity.Agreement;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.entity.Transaction;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDto {

    private Long id;


    private String name;

    private AccountType type;

    private AccountStatus status;

    private BigDecimal balance;

    private CurrencyCode currency_code;

    private Timestamp created_at;

    private Timestamp updated_at;

    private Set<TransactionDto> debitTransactionsDto;

    private  Set<TransactionDto> creditTransactionsDto;

    //private Client client;

    @JsonIgnore
    private ClientDto clientDto;

    private Set<AgreementDto> agreementDtos;




    public AccountDto(String name, AccountType type, AccountStatus status,BigDecimal balance, CurrencyCode currency_code, Timestamp updated_at){
        this.name = name;
        this.type = type;
        this.status = status;
        this.balance = balance;
        this.currency_code = currency_code;
        this.updated_at = updated_at;
    }


}
