package com.example.BankProject.entity;



import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "Credits")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Credit {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @Column(name = "Amount", columnDefinition = "Decimal(10, 2) default '0.0'", nullable = false)
   private BigDecimal amount;

   @Column(name = "InterestsRate", columnDefinition = "Decimal(10, 2) default '0.0'", nullable = false)
   private BigDecimal interestRate;

   @Column(name = "TermMonth", nullable = false)
   private int termMonths;

   @Column(name = "Created_at", nullable = false)
   private Timestamp created_at;

   @Column(name = "Updated_at", nullable = false)
   private Timestamp updated_at;


   @PrePersist
   public void onCreate(){
      created_at = Timestamp.valueOf(LocalDateTime.now());
   }

   @PreUpdate
   public void onUpdate(){
      updated_at = Timestamp.valueOf(LocalDateTime.now());
   }

   @ManyToMany(
           mappedBy = "credits",
           cascade = {CascadeType.PERSIST, CascadeType.MERGE}
   )
   private Set<Account> accounts = new HashSet<>();


}
