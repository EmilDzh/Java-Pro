package com.example.BankProject.entity;

/*   Manager
    - id: Unique identifier for the manager.
	- first_name: Manager's first name.
	- last_name: Manager's last name.
	- status: Manager's status.
	- description: Manager's description.
	- created_at: Date and time of record creation.
	*/

import com.example.BankProject.entity.Enum.ManagerStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Managers")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Manager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name", length = 50, nullable = false, unique = false)
    private String first_name;

    @Column(name = "last_name", length = 50,nullable = false, unique = false)
    private String last_name;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status")
    private ManagerStatus status;

    @Column(name = "Description")
    private String description;

    @Column(name = "Create_at", nullable = false)
    private Timestamp created_at;

    @PrePersist
    private void onCreate() {
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    @OneToMany(
            mappedBy = "manager",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private Set<Client> clients = new HashSet<>();


    @OneToMany(
            mappedBy = "manager",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private List<Product> products = new ArrayList<>();
}
