package com.example.BankProject.entity;

/*   Manager
    - id: Unique identifier for the manager.
	- first_name: Manager's first name.
	- last_name: Manager's last name.
	- status: Manager's status.
	- description: Manager's description.
	- created_at: Date and time of record creation.
	*/

import com.example.BankProject.entity.Enum.ManagerStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Managers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Manager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name", length = 50, nullable = false, unique = false)
    private String first_name;

    @Column(name = "last_name", length = 50,nullable = false, unique = false)
    private String last_name;

    @Enumerated(EnumType.STRING)
    @Column(name = "Status")
    private ManagerStatus status;

    @Column(name = "Description")
    private String description;

    @Column(name = "Create_at", nullable = false)
    private Timestamp created_at;

    @Column(name = "Username", length = 50, unique = true)
    private String username;

    @Column(name = "Password", nullable = false)
    private String password;

    @Column(name = "Role", nullable = false)
    private String role;

    @PrePersist
    private void onCreate() {
        created_at = Timestamp.valueOf(LocalDateTime.now());
    }

    public Manager(String first_name, String last_name,ManagerStatus status, String description, String username, String password, String role){
        this.first_name = first_name;
        this.last_name = last_name;
        this.status = status;
        this.description = description;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    @OneToMany(
            mappedBy = "manager",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private Set<Client> clients = new HashSet<>();


    @OneToMany(
            mappedBy = "manager",
            orphanRemoval = true,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    private List<Product> products = new ArrayList<>();
}
