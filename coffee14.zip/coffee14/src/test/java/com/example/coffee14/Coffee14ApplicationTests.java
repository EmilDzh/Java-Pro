package com.example.coffee14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Coffee14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
