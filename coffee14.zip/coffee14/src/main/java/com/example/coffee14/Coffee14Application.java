package com.example.coffee14;

//https://start.spring.io/

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Coffee14Application {

	public static void main(String[] args) {
		SpringApplication.run(Coffee14Application.class, args);
	}

}
