package com.example.coffee14;

/*
1. Добавьте в кофе поле
private BigDecimal price

поправьте конструктор


добавьте геттеры и сеттеры
 */

import java.math.BigDecimal;
import java.util.UUID;

public class Coffee {

    private String id;
    private String name;
    private BigDecimal price;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Coffee(){
        id = UUID.randomUUID().toString();
    }

    public Coffee(String name, BigDecimal price) {
        this();
        this.name = name;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}