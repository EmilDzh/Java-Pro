package com.example.coffee14;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/*

Spring - библиотека для создания серверных приложений
@Controller @RestController - компонент который взаимодействует с клиентами
@Service @Component - компоненты приложения реализующие бизнес-логику
@Repository - компонент для взаимодействия с базой данных
    Hibernate/JPA - Object-Relational Mapping - напрямую спасать и поднимать из
    базы данных экземпляры классов
@Bean
@Configuration

Spring boot - дополнительная надостройка на Spring которая позволяет создавать
    серверные приложения еще быстрее и проще

RestController -
принимаются http-запросы из вне
ответами на них являются экземпляры каких-либо объектов
которые будут сериализованы в json

REST - Remote State Transfer

HTTP - hypertext transfer protocol
    GET - SELECT
    PUT - UPDATE
    POST - INSERT
    DELETE - DELETE
    HEAD

    SELECT
    INSERT
    UPDATE
    DELETE

 */

// @RestController - контроллер который принимает и отдает клиентам экземпляры
// каких-то внутренних классов проекта

@RestController
public class CoffeeController {
    private List<Coffee> coffees = new ArrayList<>();

    /*
    поправьте инициализатор списка с кофе в контроллере, добавив произвольные цены
     */

    public CoffeeController() {
        coffees.addAll(
                Arrays.asList(
                        new Coffee("Cappuccino",new BigDecimal("1.29")),
                        new Coffee("Latte",new BigDecimal("1.39")),
                        new Coffee("Espresso",new BigDecimal("1.19")),
                        new Coffee("Americano", new BigDecimal("1.49")),
                        new Coffee("Ristretto",new BigDecimal("1.59"))
                )
        );
    }

    // HTTP GET http://localhost:8080/coffees
    // GET запрос к этому url /coffees вызывает метод контроллера getCoffees
    @GetMapping("/coffees")
    Iterable<Coffee> getCoffees() {
        return coffees;
    }

    // http://localhost:8080/coffees/123
    @GetMapping("/coffees/{id}")
    Optional<Coffee> getCoffeeById(@PathVariable("id") String id) {
        return coffees.stream()
                .filter(
                        coffee -> coffee.getId().equals(id)
                )
                .findFirst();
    }


    // DELETE http://localhost:8080/coffees/{id}
    @DeleteMapping("/coffees/{id}")
    public ResponseEntity delete(@PathVariable String id)
    {
        if(coffees.removeIf(coffee -> coffee.getId().equals(id)))
        {
            return ResponseEntity.ok().build();
        }
        else {
            return ResponseEntity.notFound().build();
        }
    }

    // POST http://localhost:8080/coffees
    // @RequestBody - json с параметрами кофе который нужно создать будет передаваться в теле запроса
    @PutMapping("/coffees")
    public Coffee create(@RequestBody Coffee coffee)
    {
        coffees.add(coffee);
        return coffee;
    }

    // POST http://localhost:8080/coffees/{id}
    // @RequestBody - json с параметрами кофе который нужно обновить, будет передаваться в теле запроса
    @PostMapping("/coffees/{id}")
    public Coffee update(
            @PathVariable String id,
            @RequestBody Coffee coffee
    )
    {
        for(int i = 0; i < coffees.size(); i++)
        {
            if(coffees.get(i).getId().equals(id))
            {
                coffees.set(i, coffee);
                return coffee;
            }
        }
        return null;
    }

    // GET http://localhost:8080/find?text=ap
    // @RequestParam указывает на переменную из http запроса
    @GetMapping("/find")
    public Iterable<Coffee> find(@RequestParam("text") String text) {
        return coffees.stream()
                .filter(
                        coffee -> coffee.getName().contains(text)
                ).toList();
    }

    /*
    добавьте в контроллер метод, который с помощью запроса вида GET http://localhost:8080/between?from=1.2&to=3.4
    возвращает список кофе, цена которых укладывается в диапазон между from и to
    public Iterable between(BigDecimal from, BigDecimal to)
 */

    //http://localhost:8080/between?from=1.2&to=3.4
   @GetMapping("/between")
    public Iterable<Coffee> between(
            @RequestParam("from") BigDecimal from,
            @RequestParam("to") BigDecimal to)
    {

       List<Coffee> result = new ArrayList<>();

       for (Coffee coffee : coffees){
           BigDecimal price = new BigDecimal(String.valueOf(coffee.getPrice()));

           if (price.compareTo(from) >= 0 && price.compareTo(to) <=0){
               result.add(coffee);
           }

       }
       return result;
   }

}
