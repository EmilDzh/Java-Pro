package lesson3;

import lesson3.animals.Animal;
import lesson3.geometry.Figure;

abstract public class FigureAnimalHybrid extends Figure implements Animal {
}
