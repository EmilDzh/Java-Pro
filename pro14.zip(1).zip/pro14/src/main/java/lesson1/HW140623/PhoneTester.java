package lesson1.HW140623;

//1 уровень сложности: 1. Создать класс Person, который содержит:
//переменные fullName, age;
//методы move() и talk(), в которых просто вывести на консоль сообщение - "Person {такой-то} говорит" и
//"Person {такой-то} идет" (замените {такой-то} на fullName).
//Добавьте геттеры и сеттеры.
//Добавьте два конструктора  - Person() и Person(fullName, age).
//Создайте два объекта этого класса. Один объект инициализируйте конструктором Person() и сеттерами, другой - конструктором Person(fullName, age)
//
//
//Создайте класс Phone, который содержит переменные number, model и weight.
//Создайте три экземпляра этого класса.
//Выведите на консоль значения их переменных.
//Добавить в класс Phone методы: receiveCall, имеет один параметр – имя звонящего.
//Выводит на консоль сообщение "Звонит {name}"”".
//Метод getNumber – возвращает номер телефона.
//Вызвать эти методы для каждого из объектов.

public class PhoneTester {
    public static void main(String[] args) {

        Phone nokia = new Phone();
        nokia.model = "Nokia 3310";
        nokia.number = 998778201043L;
        nokia.weight = 133.5;

        Phone samsung = new Phone();
        samsung.model = "Galaxy Edge";
        samsung.number = 998772727899L;
        samsung.weight = 245.3;

        Phone Sony = new Phone();
        Sony.model = "Xperia 1";
        Sony.number = 998455562L;
        Sony.weight = 230.1;

        System.out.println("Model: " + nokia.model);
        System.out.println("number: " + nokia.number);
        System.out.println("weight: " + nokia.weight);

        System.out.println();

        System.out.println("Model: " + samsung.model);
        System.out.println("number: " + samsung.number);
        System.out.println("weight: " + samsung.weight);

        System.out.println();

        System.out.println("Model: " + Sony.model);
        System.out.println("number: " + Sony.number);
        System.out.println("weight: " + Sony.weight);

        System.out.println();


        nokia.receiveCall("Nokia");
        nokia.getNumber();

        System.out.println();

        samsung.receiveCall("Samsung");
        samsung.getNumber();

        System.out.println();

        Sony.receiveCall("Sony");
        Sony.getNumber();



    }
}
