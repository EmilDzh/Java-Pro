package lesson4.animals;

public class Dog extends  Animal{

    public Dog(String name) {
        super(name);
    }

    @Override
    public void greets() {
        System.out.println("wof");
    }
    public void greets(Dog another){//перегрузка overloading
        System.out.println(another + " Woooof");
    }
}
