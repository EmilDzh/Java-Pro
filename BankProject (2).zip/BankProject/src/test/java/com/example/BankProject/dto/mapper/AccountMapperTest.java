package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Enum.AccountStatus;
import com.example.BankProject.entity.Enum.AccountType;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AccountMapperTest {

    private AccountMapper mapper = Mappers.getMapper(AccountMapper.class);

    @Test
    public void testFromAccountToDto() {
        // Создаем тестовый объект Account
        Account account = new Account();
        account.setId(1L);
        account.setName("TestAccount");
        account.setDebitTransactions(new HashSet<>());
        account.setCreditTransactions(new HashSet<>());
        account.setClient(new Client());
        account.setAgreements(new HashSet<>());

        // Преобразуем его в объект AccountDto
        AccountDto accountDto = mapper.fromAccountToDto(account);

        // Проверяем, что AccountDto не null
        assertNotNull(accountDto);

        // Проверяем соответствие значений
        assertEquals(account.getId(), accountDto.getId());
        assertEquals(account.getName(), accountDto.getName());
        // Проверяем, что списки транзакций и соглашений пусты (так как они не маппятся)
        assertNotNull(accountDto.getDebitTransactionsDto());
        assertEquals(0, accountDto.getDebitTransactionsDto().size());
        assertNotNull(accountDto.getCreditTransactionsDto());
        assertEquals(0, accountDto.getCreditTransactionsDto().size());
        assertNotNull(accountDto.getClientDto());
        assertNotNull(accountDto.getAgreementDtos());
        assertEquals(0, accountDto.getAgreementDtos().size());
    }

    @Test
    public void testToDtoList() {
        // Создаем список тестовых объектов Account
        List<Account> accountList = new ArrayList<>();
        Account account1 = new Account();
        account1.setId(1L);
        account1.setName("TestAccount1");
        account1.setDebitTransactions(new HashSet<>());
        account1.setCreditTransactions(new HashSet<>());
        account1.setClient(new Client());
        account1.setAgreements(new HashSet<>());
        Account account2 = new Account();
        account2.setId(2L);
        account2.setName("TestAccount2");
        account2.setDebitTransactions(new HashSet<>());
        account2.setCreditTransactions(new HashSet<>());
        account2.setAgreements(new HashSet<>());
        account2.setClient(new Client());
        accountList.add(account1);
        accountList.add(account2);

        // Преобразуем список в список объектов AccountDto
        List<AccountDto> accountDtoList = mapper.toDtoList(accountList);

        // Проверяем, что список AccountDto не null и размер соответствует исходному списку Account
        assertNotNull(accountDtoList);
        assertEquals(accountList.size(), accountDtoList.size());

        // Проверяем соответствие значений в списках
        for (int i = 0; i < accountList.size(); i++) {
            Account account = accountList.get(i);
            AccountDto accountDto = accountDtoList.get(i);
            assertEquals(account.getId(), accountDto.getId());
            assertEquals(account.getName(), accountDto.getName());
            // Проверяем, что списки транзакций и соглашений пусты (так как они не маппятся)
            assertNotNull(accountDto.getDebitTransactionsDto());
            assertEquals(0, accountDto.getDebitTransactionsDto().size());
            assertNotNull(accountDto.getCreditTransactionsDto());
            assertEquals(0, accountDto.getCreditTransactionsDto().size());
            assertNotNull(accountDto.getClientDto());
            assertNotNull(accountDto.getAgreementDtos());
            assertEquals(0, accountDto.getAgreementDtos().size());
        }
    }

    @Test
    public void testFromDtoToAccount() {
        // Создаем тестовый объект AccountDto
        AccountDto accountDto = new AccountDto();
        accountDto.setId(1L);
        accountDto.setName("TestAccountDto");
        accountDto.setClientDto(new ClientDto());
        accountDto.setDebitTransactionsDto(new HashSet<>());
        accountDto.setCreditTransactionsDto(new HashSet<>());
        accountDto.setAgreementDtos(new HashSet<>());
        LocalDateTime updatedAt = LocalDateTime.now();
        accountDto.setUpdated_at(Timestamp.valueOf(updatedAt));

        // Преобразуем AccountDto в объект Account
        Account account = mapper.fromDtoToAccount(accountDto);


        // Проверяем, что объекты корректно отображаются
        assertEquals(accountDto.getId(), account.getId());
        assertEquals(accountDto.getName(), account.getName());
        assertEquals(accountDto.getDebitTransactionsDto(), account.getDebitTransactions());
        assertEquals(accountDto.getCreditTransactionsDto(), account.getCreditTransactions());
        assertEquals(accountDto.getAgreementDtos(), account.getAgreements());
        assertEquals(accountDto.getUpdated_at(), account.getUpdated_at());
        assertNotNull(accountDto.getClientDto());
        assertNotNull(account.getClient());
    }

    @Test
    public void testUpdateAccountFromDto() {
        // Создаем тестовые объекты Account и AccountDto
        Account account = new Account();
        account.setId(1L);
        account.setName("TestAccount");
        // Поле, которое не должно обновляться
        account.setType(AccountType.SAVINGS);

        AccountDto accountDto = new AccountDto();
        accountDto.setName("UpdatedTestAccount");
        // Поле, которое должно обновиться
        accountDto.setStatus(AccountStatus.BLOCKED);

        // Вызываем метод обновления
        mapper.updateAccountFromDto(accountDto, account);

        // Проверяем, что поля обновлены правильно
        assertEquals(account.getId(), 1L); // Поле id должно оставаться неизменным
        assertEquals(account.getName(), "UpdatedTestAccount"); // Поле name должно обновиться
        assertNull(account.getType()); // Поле type должно остаться null
        assertEquals(account.getStatus(), AccountStatus.BLOCKED); // Поле status должно обновиться
    }
}