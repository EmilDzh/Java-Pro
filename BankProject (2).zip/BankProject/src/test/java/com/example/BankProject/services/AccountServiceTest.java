package com.example.BankProject.services;

import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.mapper.AccountMapper;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.AccountRepo;
import com.example.BankProject.repository.TransactionRepo;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class AccountServiceTest {

    @Autowired
    private AccountService accountService;

    @MockBean
    private AccountRepo accountRepo;

    @MockBean
    private TransactionRepo transactionRepo;

    @MockBean
    private AccountMapper accountMapper;

    @MockBean
    private DatabaseInitializer databaseInitializer;

    @Test
    void getAllAccounts() {

        Iterable<AccountDto> accounts = accountService.getAllAccounts();
        assertNotNull(accounts);

    }

    @Test
    public void testGetAllAccounts_WhenNoAccountsExist() {
        // Задаем поведение мока accountRepo
        when(accountRepo.findAll()).thenReturn(Arrays.asList());

        // Задаем поведение мока accountMapper
        when(accountMapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        // Выполнение тестируемого метода
        Iterable<AccountDto> result = accountService.getAllAccounts();

        // Проверка результатов
        assertEquals(Arrays.asList(), result);
    }


    @Test
    void testGetAccountById_WhenIdExists() {

        Long accountId = 1L;
        Account account = new Account();
        account.setId(accountId);
        AccountDto accountDto = new AccountDto();
        accountDto.setId(accountId);


        when(accountRepo.findById(accountId)).thenReturn(Optional.of(account));
        when(accountMapper.fromAccountToDto(account)).thenReturn(accountDto);


        Optional<AccountDto> result = accountService.getAccountById(accountId);


        assertEquals(accountDto, result.orElse(null));
    }

    @Test
    void testGetAccountById_WhenIdDoesNotExist() {
        // Arrange
        Long accountId = 1L;

        // Mocking behavior for a non-existent ID
        when(accountRepo.findById(accountId)).thenReturn(Optional.empty());

        // Act
        Optional<AccountDto> result = accountService.getAccountById(accountId);

        // Assert
        assertEquals(Optional.empty(), result);
    }


    @Test
    public void testCreateAccount(){

        AccountDto accountDto = new AccountDto();
        accountDto.setId(1L);
        accountDto.setName("TestDto");

        Account account = new Account();
        account.setId(1L);
        account.setName("Test Acc");

        when(accountMapper.fromDtoToAccount(accountDto)).thenReturn(account);
        when(accountRepo.save(account)).thenReturn(account);
        when(accountMapper.fromAccountToDto(account)).thenReturn(accountDto);

        AccountDto createdAccDto = accountService.createAccount(accountDto);

        assertEquals(accountDto.getId(), createdAccDto.getId());
        assertEquals(accountDto.getName(), createdAccDto.getName());

        verify(accountMapper, times(1)).fromDtoToAccount(accountDto);
        verify(accountRepo, times(1)).save(account);
        verify(accountMapper, times(1)).fromAccountToDto(account);

    }

    @Test
    public void testUpdateAccount_ExistingAccount(){
        Long accountID = 1L;
        AccountDto accountDto = new AccountDto();
        accountDto.setName("TestDto");
        accountDto.setBalance(new BigDecimal("666.66"));

        Account account = new Account();

        when(accountRepo.findById(accountID)).thenReturn(Optional.of(account));
        when(accountMapper.fromAccountToDto(account)).thenReturn(accountDto);
        when(accountRepo.save(account)).thenReturn(account);

        AccountDto updatedAcc = accountService.updateAccount(accountID, accountDto);

        assertEquals(accountDto, updatedAcc);
    }

    @Test
    public void testUpdateAccount_NonExistingAccount(){

        Long accountID = 999L;

        when(accountRepo.findById(accountID)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> accountService.updateAccount(accountID, new AccountDto()));
    }

    @Test
    public void testDeleteAccount_ExistingAccount(){
        Long accountId = 1L;
        Account account = new Account();

        when(accountRepo.findById(accountId)).thenReturn(Optional.of(account));

        accountService.deleteAccount(accountId);

        verify(accountRepo, times(1)).delete(account);
    }

    @Test
    public void testDeleteAccount_NonExistingAccount(){
        Long accountID = 999L;

        when(accountRepo.findById(accountID)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> accountService.deleteAccount(accountID));
    }

    @Test
    public void testGetAccountBalance_WhenAccountExists(){
        Long accountId = 1L;

        Account account = new Account();
        account.setBalance(new BigDecimal("1000.00"));

        AccountDto accountDto = new AccountDto();
        accountDto.setBalance(new BigDecimal("1000.00"));

        when(accountRepo.findById(accountId)).thenReturn(Optional.of(account));
        when(accountMapper.fromAccountToDto(account)).thenReturn(accountDto);

        BigDecimal getAccBalance = accountService.getAccountBalance(accountId);

        assertEquals(new BigDecimal("1000.00"), getAccBalance);
    }

    @Test
    public void testGetAccountBalance_WhenDoesNotAccountExists(){

        Long accountID = 999L;

        when(accountRepo.findById(accountID)).thenReturn(Optional.empty());

        BigDecimal getBalance = accountService.getAccountBalance(accountID);

        assertEquals(BigDecimal.ZERO, getBalance);
    }

    @Test
    public void testGetTransactionHistoryById(){
        Long accountID = 1L;

        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction1 = new Transaction();
        Transaction transaction2 = new Transaction();

        transactions.add(transaction1);
        transactions.add(transaction2);

        List<Transaction> debitTransactions = new ArrayList<>();
        debitTransactions.add(transaction1);

        List<Transaction> creditTransactions = new ArrayList<>();
        creditTransactions.add(transaction2);

        when(transactionRepo.findByDebit_account_id(accountID)).thenReturn(debitTransactions);
        when(transactionRepo.findByCredit_account_id(accountID)).thenReturn(creditTransactions);

        List<Transaction> actualTransactions = accountService.getTransactionHistoryById(accountID);

        assertEquals(transactions.size(), actualTransactions.size());
        assertTrue(actualTransactions.containsAll(transactions));
    }

    @Test
    public void testUpdateBalance(){

        Long accountId = 1L;

        BigDecimal balance = new BigDecimal("500.00");

        accountService.updateBalance(accountId, balance);

        verify(accountRepo, times(1)).updateBalance(accountId,balance);
    }






}