package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.repository.ClientRepo;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = "spring.profiles.active=null")
public class IntegrationTestForClientController {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    private TestRestTemplate restTemplate;


    @Test
    public void shouldReturnAllClients() {

        ResponseEntity<ClientDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/clients",
                        ClientDto[].class
                );

        int expectedClients = 5;

        assertEquals(HttpStatus.OK, response.getStatusCode());

        ClientDto[] clientDtos = response.getBody();
        assertNotNull(clientDtos);
        assertEquals(expectedClients, clientDtos.length);
    }

    @Test
    public void shouldReturnClientById() {

        Long clientId = 1L;

        ResponseEntity<ClientDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId,
                        ClientDto.class,
                        clientId
                );

        assertEquals(HttpStatus.OK, response.getStatusCode());
        ClientDto clientDto = response.getBody();
        assertNotNull(clientDto);
    }

    @Test
    public void shouldReturnNotFoundForNotExistingClient() {

        Long clientId = 999L;

        ResponseEntity<ClientDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId,
                        ClientDto.class,
                        clientId
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldReturnCreatedClient() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        HttpEntity<String> request = new HttpEntity<>(
                "{\"status\" : \"ACTIVE\", \"tax_code\" : \"9595\", \"first_name\" : \"TestName\", " +
                        "\"last_name\" : \"TestLastName\", \"email\" : \"test@gmail.com\", \"address\" : \"TestAdress\", " +
                        "\"phone\" : \"+1112223337777\", \"updated_at\" : \"2023-12-11T19:06:36.394+00:00\", \"username\" : \"TestName\", " +
                        "\"password\" : \"password\", \"role\" : \"USER_ROLE\"}",
                headers
        );

        assertEquals(clientRepo.count(), 5);

        ResponseEntity<ClientDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + managerId,
                        request,
                        ClientDto.class,
                        managerId
                );

        assertEquals(clientRepo.count(), 6);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void checkFieldsOfCreatedClient() throws JSONException {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        HttpEntity<String> request = new HttpEntity<>(
                "{\"status\" : \"ACTIVE\", \"tax_code\" : \"9595\", \"first_name\" : \"TestName\", " +
                        "\"last_name\" : \"TestLastName\", \"email\" : \"test@gmail.com\", \"address\" : \"TestAdress\", " +
                        "\"phone\" : \"+1112223337777\", \"updated_at\" : \"2023-12-11T19:06:36.394+00:00\", \"username\" : \"TestName\", " +
                        "\"password\" : \"password\", \"role\" : \"USER_ROLE\"}",
                headers
        );

        assertEquals(clientRepo.count(), 5);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + managerId,
                        request,
                        String.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        String result = response.getBody();

        JSONObject jsonObject = new JSONObject(result);
        assertTrue(jsonObject.has("first_name"));
        assertEquals(jsonObject.get("last_name"), "TestLastName");
    }

    @Test
    public void shouldReturnErrorWhileCreatingClient(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 999L;

        HttpEntity<String> request = new HttpEntity<>(
                "{\"status\" : \"ACTIVE\", \"tax_code\" : \"9595\", \"first_name\" : \"TestName\", " +
                        "\"last_name\" : \"TestLastName\", \"email\" : \"test@gmail.com\", \"address\" : \"TestAdress\", " +
                        "\"phone\" : \"+1112223337777\", \"updated_at\" : \"2023-12-11T19:06:36.394+00:00\", \"username\" : \"TestName\", " +
                        "\"password\" : \"password\", \"role\" : \"USER_ROLE\"}",
                headers
        );


        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + managerId,
                        request,
                        String.class,
                        managerId
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldUpdateClient() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"status\" : \"ACTIVE\", \"tax_code\" : \"9595\", \"first_name\" : \"TestName\", " +
                        "\"last_name\" : \"TestLastName\", \"email\" : \"test@gmail.com\", \"address\" : \"TestAdress\", " +
                        "\"phone\" : \"+1112223337777\", \"updated_at\" : \"2023-12-11T19:06:36.394+00:00\", \"username\" : \"TestName\", " +
                        "\"password\" : \"password\", \"role\" : \"USER_ROLE\"}",
                headers
        );

        assertEquals(clientRepo.count(), 5);

        ResponseEntity<ClientDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + managerId,
                        createRequest,
                        ClientDto.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());

        ClientDto createdClient = createResponse.getBody();
        assertNotNull(createdClient);

        Long clientId = createdClient.getId();

        createdClient.setAddress("NewTestAddress");
        createdClient.setEmail("newTest@gmail.com");

        HttpEntity<ClientDto> updateRequest = new HttpEntity<>(createdClient, headers);

        ResponseEntity<ClientDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/" + managerId,
                        HttpMethod.PUT,
                        updateRequest,
                        ClientDto.class
                );

        assertEquals(HttpStatus.OK, updateResponse.getStatusCode());

        ClientDto clientDto = updateRequest.getBody();
        assertNotNull(clientDto);

        assertEquals("NewTestAddress", clientDto.getAddress());
        assertEquals("newTest@gmail.com", clientDto.getEmail());

    }

    @Test
    public void shouldReturnErrorWhileUpdatingClient(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 999L;
        Long clientId = 1L;

        ClientDto clientDto = new ClientDto();

        ResponseEntity<ClientDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/" + managerId,
                        HttpMethod.PUT,
                        new HttpEntity<>(clientDto, headers),
                        ClientDto.class
                );

        assertEquals(HttpStatus.NOT_FOUND, updateResponse.getStatusCode());

    }

    @Test
    public void ShouldReturnErrorForNotExistingClient(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;
        Long clientId = 999L;

        ClientDto clientDto = new ClientDto();

        ResponseEntity<ClientDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/clients/" + clientId + "/" + managerId,
                        HttpMethod.PUT,
                        new HttpEntity<>(clientDto, headers),
                        ClientDto.class
                );
        assertEquals(HttpStatus.NOT_FOUND, updateResponse.getStatusCode());
    }

    @Test
    public void shouldDeleteClient() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        HttpEntity<String> request = new HttpEntity<>(
                "{\"status\" : \"ACTIVE\", \"tax_code\" : \"9595\", \"first_name\" : \"TestName\", " +
                        "\"last_name\" : \"TestLastName\", \"email\" : \"test@gmail.com\", \"address\" : \"TestAdress\", " +
                        "\"phone\" : \"+1112223337777\", \"updated_at\" : \"2023-12-11T19:06:36.394+00:00\", \"username\" : \"TestName\", " +
                        "\"password\" : \"password\", \"role\" : \"USER_ROLE\"}",
                headers
        );

        assertEquals(clientRepo.count(), 5);

        ResponseEntity<ClientDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/clients/" + managerId,
                        request,
                        ClientDto.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        ClientDto createdClient = response.getBody();
        assertNotNull(createdClient);

        Long clientId = createdClient.getId();

        ResponseEntity<String> deleteResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/clients/" + clientId,
                        HttpMethod.DELETE,
                        null,
                        String.class,
                        clientId
                );

        assertEquals(HttpStatus.OK, deleteResponse.getStatusCode());

        ResponseEntity<ClientDto> checkResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/clients/" + clientId,
                        ClientDto.class,
                        clientId
                );

        assertEquals(HttpStatus.NOT_FOUND, checkResponse.getStatusCode());


    }
}
