package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Enum.ClientStatus;
import com.example.BankProject.entity.Manager;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ClientMapperTest {

    private ClientMapper mapper = Mappers.getMapper(ClientMapper.class);

    @Test
    public void testFromClientToDto() {
        // Создаем тестовый объект Client
        Client client = new Client();
        client.setId(1L);
        client.setStatus(ClientStatus.ACTIVE);
        client.setTax_code("1234567890");
        client.setFirst_name("John");
        client.setLast_name("Doe");
        client.setEmail("john.doe@example.com");
        client.setAddress("123 Main St");
        client.setPhone("123-456-7890");
        client.setUsername("johndoe");
        client.setPassword("password");
        client.setRole("ROLE_USER");


        client.setAccounts(new HashSet<>());
        client.setManager(new Manager());

        // Преобразуем объект Client в объект ClientDto
        ClientDto clientDto = mapper.fromClientToDto(client);

        // Проверяем, что объект ClientDto не null
        assertNotNull(clientDto);

        // Проверяем соответствие значений
        assertEquals(client.getId(), clientDto.getId());
        assertEquals(client.getStatus(), clientDto.getStatus());
        assertEquals(client.getTax_code(), clientDto.getTax_code());
        assertEquals(client.getFirst_name(), clientDto.getFirst_name());
        assertEquals(client.getLast_name(), clientDto.getLast_name());
        assertEquals(client.getEmail(), clientDto.getEmail());
        assertEquals(client.getAddress(), clientDto.getAddress());
        assertEquals(client.getPhone(), clientDto.getPhone());
        assertEquals(client.getUsername(), clientDto.getUsername());
        assertEquals(client.getPassword(), clientDto.getPassword());
        assertEquals(client.getRole(), clientDto.getRole());
        // Проверяем маппинг связанных сущностей
        assertEquals(client.getAccounts().size(), clientDto.getAccountDtosSet().size());
        assertNotNull(clientDto.getManagerDto());
    }


    @Test
    public void testToDtoList() {
        // Создаем список тестовых объектов Client
        List<Client> clientList = new ArrayList<>();
        Client client1 = new Client();
        client1.setId(1L);
        client1.setStatus(ClientStatus.ACTIVE);
        client1.setTax_code("1234567890");
        client1.setFirst_name("John");
        client1.setLast_name("Doe");
        client1.setEmail("john.doe@example.com");
        client1.setAddress("123 Main St");
        client1.setPhone("123-456-7890");
        client1.setUsername("johndoe");
        client1.setPassword("password");
        client1.setRole("ROLE_USER");
        client1.setAccounts(new HashSet<>());
        client1.setManager(new Manager());

        Client client2 = new Client();
        client2.setId(2L);


        clientList.add(client1);
        clientList.add(client2);

        // Преобразуем список объектов Client в список объектов ClientDto
        List<ClientDto> clientDtoList = mapper.toDtoList(clientList);

        // Проверяем, что список ClientDto не null
        assertNotNull(clientDtoList);

        // Проверяем, что количество элементов в списках совпадает
        assertEquals(clientList.size(), clientDtoList.size());

        // Можно также провести дополнительные проверки, например, сравнить значения полей в объектах Client и ClientDto
    }

    @Test
    public void testFromDtoToClient() {
        // Создаем тестовый объект ClientDto
        ClientDto clientDto = new ClientDto();
        clientDto.setId(1L);
        clientDto.setStatus(ClientStatus.ACTIVE);
        clientDto.setTax_code("1234567890");
        clientDto.setFirst_name("John");
        clientDto.setLast_name("Doe");
        clientDto.setEmail("john.doe@example.com");
        clientDto.setAddress("123 Main St");
        clientDto.setPhone("123-456-7890");
        clientDto.setUsername("johndoe");
        clientDto.setPassword("password");
        clientDto.setRole("ROLE_USER");
        clientDto.setAccountDtosSet(new HashSet<>());
        clientDto.setManagerDto(new ManagerDto());
        clientDto.setUpdated_at(Timestamp.valueOf(LocalDateTime.now()));

        // Вызываем метод преобразования
        Client client = mapper.fromDtoToClient(clientDto);

        // Проверяем, что объект не null
        assertNotNull(client);

        // Проверяем, что значения полей скопированы правильно
        assertEquals(clientDto.getId(), client.getId());
        assertEquals(clientDto.getStatus(), client.getStatus());
        assertEquals(clientDto.getTax_code(), client.getTax_code());
        assertEquals(clientDto.getFirst_name(), client.getFirst_name());
        assertEquals(clientDto.getLast_name(), client.getLast_name());
        assertEquals(clientDto.getEmail(), client.getEmail());
        assertEquals(clientDto.getAddress(), client.getAddress());
        assertEquals(clientDto.getPhone(), client.getPhone());
        assertEquals(clientDto.getUsername(), client.getUsername());
        assertEquals(clientDto.getPassword(), client.getPassword());
        assertEquals(clientDto.getRole(), client.getRole());
        assertEquals(clientDto.getAccountDtosSet(), client.getAccounts());
        //assertEquals(clientDto.getManagerDto(), client.getManager());
        assertEquals(clientDto.getUpdated_at(), client.getUpdated_at());
    }

    @Test
    public void testUpdateClientFromDto() {
        // Создаем тестовый объект Client и ClientDto
        Client client = new Client();
        client.setId(1L);
        client.setFirst_name("John");
        client.setLast_name("Doe");

        ClientDto clientDto = new ClientDto();
        clientDto.setFirst_name("Jane");
        clientDto.setLast_name("Doe");

        // Вызываем метод обновления
        mapper.updateClientFromDto(clientDto, client);

        // Проверяем, что поля обновлены правильно
        assertEquals(1L, client.getId()); // Поле id должно оставаться неизменным
        assertEquals("Jane", client.getFirst_name()); // Поле firstName должно обновиться
        assertEquals("Doe", client.getLast_name()); // Поле lastName должно обновиться
    }


}

