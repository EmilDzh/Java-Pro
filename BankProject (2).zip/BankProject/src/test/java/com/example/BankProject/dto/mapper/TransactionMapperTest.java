package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.entity.Enum.TransactionType;
import com.example.BankProject.entity.Transaction;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TransactionMapperTest {

    TransactionMapper mapper = Mappers.getMapper(TransactionMapper.class);

    @Test
    public void testFromTransactionToDto() {
        // Создаем тестовый объект Transaction
        Transaction transaction = new Transaction();
        transaction.setId(1L);
        transaction.setAmount(BigDecimal.valueOf(100.0));
        transaction.setType(TransactionType.TRANSFER);
        transaction.setDescription("Test");

        // Преобразуем Transaction в объект TransactionDto
        TransactionDto transactionDto = mapper.fromTransactionToDto(transaction);

        // Проверяем, что объект TransactionDto не null и содержит ожидаемые значения
        assertNotNull(transactionDto);
        assertEquals(1L, transactionDto.getId());
        assertEquals(BigDecimal.valueOf(100.0), transactionDto.getAmount());
        assertEquals(transaction.getType(), transactionDto.getType());
        assertEquals(transaction.getDescription(), transactionDto.getDescription());

    }

    @Test
    public void testToDtoList() {
        // Создаем список тестовых объектов Transaction
        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction1 = new Transaction();
        transaction1.setId(1L);
        transaction1.setAmount(BigDecimal.valueOf(100.0));
        transaction1.setDescription("Test");



        Transaction transaction2 = new Transaction();
        transaction2.setId(2L);
        transaction2.setAmount(BigDecimal.valueOf(200.0));
        transaction2.setDescription("Test2");

        transactions.add(transaction1);
        transactions.add(transaction2);

        // Преобразуем список Transaction в список TransactionDto
        List<TransactionDto> transactionDtos = mapper.toDtoList(transactions);

        // Проверяем, что полученный список TransactionDto не null и содержит ожидаемое количество элементов
        assertNotNull(transactionDtos);
        assertEquals(2, transactionDtos.size());

        // Проверяем, что каждый объект Transaction преобразован в соответствующий TransactionDto
        assertEquals(1L, transactionDtos.get(0).getId());
        assertEquals(BigDecimal.valueOf(100.0), transactionDtos.get(0).getAmount());
        assertEquals("Test", transactionDtos.get(0).getDescription());

        assertEquals(2L, transactionDtos.get(1).getId());
        assertEquals(BigDecimal.valueOf(200.0), transactionDtos.get(1).getAmount());
        assertEquals("Test2", transactionDtos.get(1).getDescription());
    }

    @Test
    public void testFromDtoToTransaction() {
        // Создаем тестовый объект TransactionDto
        TransactionDto transactionDto = new TransactionDto();
        transactionDto.setId(1L);
        transactionDto.setAmount(BigDecimal.valueOf(500.0));
        transactionDto.setDescription("Test");
        transactionDto.setType(TransactionType.TRANSFER);

        // Преобразуем TransactionDto в объект Transaction
        Transaction transaction = mapper.fromDtoToTransaction(transactionDto);


        assertNotNull(transaction);
        assertEquals(1L, transaction.getId());
        assertEquals(BigDecimal.valueOf(500.0), transaction.getAmount());
        assertEquals(transaction.getDescription(), transactionDto.getDescription());
        assertEquals(transaction.getType(), transactionDto.getType());
    }

}