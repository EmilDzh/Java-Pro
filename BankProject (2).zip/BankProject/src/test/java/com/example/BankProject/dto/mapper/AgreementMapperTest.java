package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Agreement;
import com.example.BankProject.entity.Enum.AgreementStatus;
import com.example.BankProject.entity.Product;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AgreementMapperTest {

    private AgreementMapper mapper = Mappers.getMapper(AgreementMapper.class);


    @Test
    public void testFromAgreementToDto() {
        // Создаем тестовый объект Agreement
        Agreement agreement = new Agreement();
        agreement.setId(1L);

        // Создаем тестовые объекты Account и Product
        Account account = new Account();
        account.setId(101L);
        Product product = new Product();
        product.setId(201L);

        agreement.setAccount(account);
        agreement.setProduct(product);

        // Преобразуем Agreement в объект AgreementDto
        AgreementDto agreementDto = mapper.fromAgreementToDto(agreement);

        // Проверяем, что поля скопировались правильно
        assertEquals(agreement.getId(), agreementDto.getId());
        assertEquals(agreement.getAccount().getId(), agreementDto.getAccountDto().getId());
        assertEquals(agreement.getProduct().getId(), agreementDto.getProductDto().getId());
    }

    @Test
    public void testToDtoList() {
        // Создаем список тестовых объектов Agreement
        List<Agreement> agreementList = new ArrayList<>();
        Agreement agreement1 = new Agreement();
        agreement1.setId(1L);
        Agreement agreement2 = new Agreement();
        agreement2.setId(2L);
        agreementList.add(agreement1);
        agreementList.add(agreement2);

        // Преобразуем список в список объектов AgreementDto
        List<AgreementDto> agreementDtoList = mapper.toDtoList(agreementList);

        // Проверяем, что список AgreementDto не null и размер соответствует исходному списку Agreement
        assertNotNull(agreementDtoList);
        assertEquals(agreementList.size(), agreementDtoList.size());

        // Проверяем соответствие значений в списках
        for (int i = 0; i < agreementList.size(); i++) {
            Agreement agreement = agreementList.get(i);
            AgreementDto agreementDto = agreementDtoList.get(i);
            assertEquals(agreement.getId(), agreementDto.getId());
            // Проверяем другие поля, если есть
        }
    }

    @Test
    public void testFromDtoToAgreement() {
        // Создаем тестовый объект AgreementDto
        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(1L);
        agreementDto.setAccountDto(new AccountDto());
        agreementDto.setProductDto(new ProductDto());
        LocalDateTime updatedAt = LocalDateTime.now();
        agreementDto.setUpdated_at(Timestamp.valueOf(updatedAt));
        agreementDto.setInterest_rate(new BigDecimal("1.00"));
        agreementDto.setStatus(AgreementStatus.ACTIVE);
        agreementDto.setSum(new BigDecimal("100.00"));

        // Преобразуем AgreementDto в объект Agreement
        Agreement agreement = mapper.fromDtoToAgreement(agreementDto);

        // Проверяем, что объекты корректно отображаются
        assertEquals(agreementDto.getId(), agreement.getId());
        //assertEquals(agreementDto.getAccountDto(), agreement.getAccount());
        //assertEquals(agreementDto.getProductDto(), agreement.getProduct());
        assertEquals(agreementDto.getUpdated_at(), agreement.getUpdated_at());
        assertEquals(agreementDto.getStatus(), agreement.getStatus());
        assertEquals(agreementDto.getSum(), agreement.getSum());
        assertEquals(agreementDto.getInterest_rate(), agreement.getInterest_rate());
    }

    @Test
    public void testUpdateAgreementFromDto() {
        // Создаем тестовые объекты Agreement и AgreementDto
        Agreement agreement = new Agreement();
        agreement.setId(1L);
        agreement.setInterest_rate(BigDecimal.valueOf(5.0)); // устанавливаем начальное значение для проверки
        // поле, которое не должно обновляться
        agreement.setStatus(AgreementStatus.ACTIVE);

        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(1L);
        agreementDto.setInterest_rate(BigDecimal.valueOf(7.0)); // новое значение для обновления
        // поле, которое должно обновиться
        agreementDto.setStatus(AgreementStatus.CLOSED);

        // Вызываем метод обновления
        mapper.updateAgreementFromDto(agreementDto, agreement);

        // Проверяем, что поля обновлены правильно
        assertEquals(1L, agreement.getId()); // Поле id должно оставаться неизменным
        assertEquals(BigDecimal.valueOf(7.0), agreement.getInterest_rate()); // Поле interest_rate не должно обновляться
        assertEquals(AgreementStatus.CLOSED, agreement.getStatus()); // Поле status должно обновиться
    }


}