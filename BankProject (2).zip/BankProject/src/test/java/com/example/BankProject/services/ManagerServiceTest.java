package com.example.BankProject.services;

import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.dto.mapper.ManagerMapper;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.repository.ManagerRepo;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class ManagerServiceTest {

    @Autowired
    private ManagerService managerService;

    @MockBean
    private ManagerRepo managerRepo;

    @MockBean
    private ManagerMapper mapper;

    @MockBean
    private DatabaseInitializer databaseInitializer;

    @Test
    public void testGetAllManagers(){

        Iterable<ManagerDto> managerDtos = managerService.getAllManagers();
        assertNotNull(managerDtos);
    }

    @Test
    public void testGetAllManagers_WhenNoManagersExist(){

        when(managerRepo.findAll()).thenReturn(Arrays.asList());

        when(mapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        Iterable<ManagerDto> managerDtos = managerService.getAllManagers();

        assertEquals(Arrays.asList(), managerDtos);
    }

    @Test
    public void testGetManagerById_WhenIdExists(){

        Long id = 1L;

        Manager manager = new Manager();
        manager.setId(id);
        ManagerDto managerDto = new ManagerDto();
        managerDto.setId(id);

        when(managerRepo.findById(id)).thenReturn(Optional.of(manager));
        when(mapper.fromManagerToDto(manager)).thenReturn(managerDto);

        Optional<ManagerDto> managerDto1 = managerService.getManagerById(id);

        assertEquals(managerDto, managerDto1.orElse(null));
    }

    @Test
    public void testGetManagerById_WhenIdDoesNotExist(){
        Long id = 999L;

        when(managerRepo.findById(id)).thenReturn(Optional.empty());

        Optional<ManagerDto> managerDto = managerService.getManagerById(id);

        assertEquals(Optional.empty(), managerDto);
    }

    @Test
    public void testCreateManager(){

        Manager manager = new Manager();
        manager.setId(1L);
        manager.setRole("TestRole");
        manager.setUsername("TestUser");

        ManagerDto managerDto = new ManagerDto();
        managerDto.setId(1L);
        managerDto.setRole("TestRole");
        managerDto.setUsername("TestUser");

        when(mapper.fromManagerToDto(manager)).thenReturn(managerDto);
        when(managerRepo.save(manager)).thenReturn(manager);
        when(mapper.fromDtoToManager(managerDto)).thenReturn(manager);

        ManagerDto createdManager = managerService.createManager(managerDto);

        assertEquals(managerDto.getId(), createdManager.getId());
        assertEquals(managerDto.getRole(), createdManager.getRole());
        assertEquals(managerDto.getUsername(), createdManager.getUsername());

        verify(mapper, times(1)).fromManagerToDto(manager);
        verify(managerRepo, times(1)).save(manager);
        verify(mapper, times(1)).fromDtoToManager(managerDto);
    }

    @Test
    public void testUpdateManager_ExistingManager(){

        Long id = 1L;

        ManagerDto managerDto = new ManagerDto();
        managerDto.setUsername("TestUser");
        managerDto.setRole("UserRole");

        Manager manager = new Manager();

        when(managerRepo.findById(id)).thenReturn(Optional.of(manager));
        when(mapper.fromManagerToDto(manager)).thenReturn(managerDto);
        when(managerRepo.save(manager)).thenReturn(manager);


        ManagerDto updatedManager = managerService.updateManager(id, managerDto);

        assertEquals(managerDto, updatedManager);
    }

    @Test
    public void testUpdateManager_NonExistingManager(){
        Long id = 999L;

        when(managerRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> managerService.updateManager(id, new ManagerDto()));
    }

    @Test
    public void testDeleteManager_ExistingManager(){
        Long id = 1L;

        Manager manager = new Manager();

        when(managerRepo.findById(id)).thenReturn(Optional.of(manager));

        managerService.deleteManagerById(id);

        verify(managerRepo, times(1)).delete(manager);
    }

    @Test
    public void testDeleteManager_NonExistingManager(){

        Long id = 999L;

        when(managerRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> managerService.deleteManagerById(id));
    }

}