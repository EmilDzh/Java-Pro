package com.example.BankProject.services;

import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.dto.mapper.ProductMapper;
import com.example.BankProject.entity.Enum.ProductStatus;
import com.example.BankProject.entity.Product;
import com.example.BankProject.repository.ProductRepo;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class ProductServiceTest {

    @Autowired
    private ProductService productService;

    @MockBean
    private ProductRepo productRepo;

    @MockBean
    private ProductMapper productMapper;

    @MockBean
    private DatabaseInitializer databaseInitializer;

    @Test
    public void testGetAllProducts() {

        Iterable<ProductDto> productDtos = productService.getAllProducts();
        assertNotNull(productDtos);
    }

    @Test
    public void testGetAllProducts_WhenNoProductsExist() {

        when(productRepo.findAll()).thenReturn(Arrays.asList());

        when(productMapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        Iterable<ProductDto> productDtos = productService.getAllProducts();

        assertEquals(Arrays.asList(), productDtos);
    }

    @Test
    public void testGetProductById_WhenIdExists() {

        Long id = 1L;

        Product product = new Product();
        product.setId(id);

        ProductDto productDto = new ProductDto();
        productDto.setId(id);

        when(productRepo.findById(id)).thenReturn(Optional.of(product));
        when(productMapper.fromProductToDto(product)).thenReturn(productDto);

        Optional<ProductDto> productDto1 = productService.getProductById(id);

        assertEquals(productDto, productDto1.orElse(null));
    }

    @Test
    public void testGetProductById_WhenIdDoesNotExist() {

        Long id = 99L;

        when(productRepo.findById(id)).thenReturn(Optional.empty());

        Optional<ProductDto> productDto = productService.getProductById(id);

        assertEquals(Optional.empty(), productDto);

    }

    @Test
    public void testCreateProduct(){

        Product product = new Product();
        product.setId(1L);
        product.setName("Test");

        ProductDto productDto = new ProductDto();
        productDto.setId(1L);
        productDto.setName("Test");

        when(productMapper.fromProductToDto(product)).thenReturn(productDto);
        when(productRepo.save(product)).thenReturn(product);
        when(productMapper.fromDtoToProduct(productDto)).thenReturn(product);

        ProductDto createdProduct = productService.createProduct(productDto);

        assertEquals(productDto.getId(), createdProduct.getId());
        assertEquals(productDto.getName(), createdProduct.getName());

        verify(productMapper, times(1)).fromProductToDto(product);
        verify(productRepo, times(1)).save(product);
        verify(productMapper, times(1)).fromDtoToProduct(productDto);
    }

    @Test
    public void testUpdateProduct_ExistingProduct(){

        Long id = 1L;

        ProductDto productDto = new ProductDto();
        productDto.setName("UpdatedName");
        productDto.setStatus(ProductStatus.ACTIVE);

        Product product = new Product();

        when(productRepo.findById(id)).thenReturn(Optional.of(product));
        when(productMapper.fromProductToDto(product)).thenReturn(productDto);
        when(productRepo.save(product)).thenReturn(product);

        ProductDto updatedProduct = productService.updateProductById(id, productDto);

        assertEquals(productDto, updatedProduct);
    }

    @Test
    public void testUpdateProduct_NonExistingProduct(){
        Long id = 99L;

        when(productRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> productService.updateProductById(id, new ProductDto()));
    }

    @Test
    public void testDeleteProduct_ExistingProduct(){

        Long id = 1L;

        Product product = new Product();

        when(productRepo.findById(id)).thenReturn(Optional.of(product));

        productService.deleteProductById(id);

        verify(productRepo, times(1)).delete(product);
    }

    @Test
    public void testDeleteProduct_NonExistingProduct(){

        Long id = 1L;

        when(productRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> productService.deleteProductById(id));
    }

}