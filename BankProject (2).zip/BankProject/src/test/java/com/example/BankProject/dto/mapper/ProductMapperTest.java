package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Agreement;
import com.example.BankProject.entity.Enum.AgreementStatus;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.entity.Product;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ProductMapperTest {

    ProductMapper mapper = Mappers.getMapper(ProductMapper.class);

    @Test
    public void testFromProductToDto() {
        // Создаем тестовый объект Product
        Product product = new Product();
        product.setId(1L);
        product.setName("TestProduct");

        // Создаем тестовый объект Manager
        Manager manager = new Manager();
        manager.setId(1L);
        manager.setFirst_name("TestManager");

        // Создаем тестовый объект Agreement
        Agreement agreement = new Agreement();
        agreement.setId(1L);
        agreement.setStatus(AgreementStatus.ACTIVE);

        product.setManager(manager);
        product.setAgreements(Collections.singleton(agreement));

        // Преобразуем Product в объект ProductDto
        ProductDto productDto = mapper.fromProductToDto(product);

        // Проверяем, что объект ProductDto не null и содержит ожидаемые значения
        assertNotNull(productDto);
        assertEquals(product.getId(), productDto.getId());
        assertEquals(product.getName(), productDto.getName());

        // Проверяем, что списки соглашений и менеджеров в ProductDto не null
        assertNotNull(productDto.getAgreementDtos());
        assertNotNull(productDto.getManagerDto());

        // Проверяем, что значения в списках соглашений и менеджеров соответствуют ожидаемым
        assertEquals(product.getAgreements().size(), productDto.getAgreementDtos().size());
        assertEquals(product.getManager().getId(), productDto.getManagerDto().getId());
        assertEquals(product.getManager().getFirst_name(), productDto.getManagerDto().getFirst_name());
    }

    @Test
    public void testToDtoList() {
        // Создаем тестовые объекты Product
        Product product1 = new Product();
        product1.setId(1L);
        product1.setName("Product 1");

        Product product2 = new Product();
        product2.setId(2L);
        product2.setName("Product 2");

        // Создаем список продуктов
        List<Product> productList = Arrays.asList(product1, product2);

        // Преобразуем список Product в список ProductDto
        List<ProductDto> productDtoList = mapper.toDtoList(productList);

        // Проверяем, что список ProductDto не null
        assertNotNull(productDtoList);
        // Проверяем, что размеры списков совпадают
        assertEquals(productList.size(), productDtoList.size());

        // Проверяем соответствие элементов в списках
        for (int i = 0; i < productList.size(); i++) {
            Product product = productList.get(i);
            ProductDto productDto = productDtoList.get(i);

            // Проверяем, что каждый Product преобразован в соответствующий ProductDto
            assertEquals(product.getId(), productDto.getId());
            assertEquals(product.getName(), productDto.getName());
            // Другие проверки полей, если необходимо
        }
    }

    @Test
    public void testFromDtoToProduct() {
        // Создаем тестовые объекты ProductDto
        ProductDto productDto = new ProductDto();
        productDto.setId(1L);
        productDto.setName("Test Product");

        // Создаем тестовый объект ManagerDto
        ManagerDto managerDto = new ManagerDto();
        managerDto.setId(1L);
        managerDto.setFirst_name("Test Manager");

        // Создаем тестовый объект AgreementDto
        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(1L);
        agreementDto.setStatus(AgreementStatus.ACTIVE);

        // Добавляем AgreementDto в список
        Set<AgreementDto> agreementDtos = new HashSet<>();
        agreementDtos.add(agreementDto);

        // Устанавливаем ManagerDto и AgreementDtos в ProductDto
        productDto.setManagerDto(managerDto);
        productDto.setAgreementDtos(agreementDtos);

        // Преобразуем ProductDto в объект Product
        Product product = mapper.fromDtoToProduct(productDto);

        // Проверяем, что объект Product не null
        assertNotNull(product);
        // Проверяем, что поля соответствуют ожидаемым значениям
        assertEquals(productDto.getId(), product.getId());
        assertEquals(productDto.getName(), product.getName());

        // Проверяем, что поля manager и agreements преобразованы корректно
        assertNotNull(product.getManager());
        assertEquals(managerDto.getId(), product.getManager().getId());
        assertEquals(managerDto.getFirst_name(), product.getManager().getFirst_name());

        assertNotNull(product.getAgreements());
        assertEquals(1, product.getAgreements().size()); // Проверяем количество соглашений
        Agreement agreement = product.getAgreements().iterator().next();
        assertEquals(agreementDto.getId(), agreement.getId());
        assertEquals(agreementDto.getStatus(), agreement.getStatus());
        // Другие проверки, если необходимо
    }

    @Test
    public void testUpdateProductFromDto() {
        // Создаем тестовый объект Product
        Product product = new Product();
        product.setId(1L);
        product.setName("Original Product");

        // Создаем тестовый объект ProductDto для обновления
        ProductDto updatedProductDto = new ProductDto();
        updatedProductDto.setName("Updated Product");
        updatedProductDto.setInterest_rate(BigDecimal.valueOf(1000.0));
        updatedProductDto.setCreated_at(new Timestamp(System.currentTimeMillis()));


        // Создаем тестовый объект AgreementDto
        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(1L);
        agreementDto.setStatus(AgreementStatus.ACTIVE);



        // Вызываем метод обновления
        mapper.updateProductFromDto(updatedProductDto, product);

        // Проверяем, что поля обновлены правильно
        assertEquals(1L, product.getId()); // Поле id должно оставаться неизменным
        assertEquals("Updated Product", product.getName()); // Поле name должно обновиться
        assertEquals(BigDecimal.valueOf(1000.0), product.getInterest_rate()); // Поле interest_rate должно обновиться
        assertNotNull(product.getCreated_at()); // Поле createdAt должно быть установлено
        // Проверяем, что поля manager и agreements преобразованы корректно


    }

}