package com.example.BankProject.services;

import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.dto.mapper.AgreementMapper;
import com.example.BankProject.entity.Agreement;
import com.example.BankProject.entity.Enum.AgreementStatus;
import com.example.BankProject.repository.AgreementRepo;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class AgreementServiceTest {

    @Autowired
    private AgreementService agreementService;

    @MockBean
    private AgreementRepo agreementRepo;

    @MockBean
    private AgreementMapper agreementMapper;

    @MockBean
    private DatabaseInitializer databaseInitializer;


    @Test
    public void getAllAgreements() {

        Iterable<AgreementDto> agreementDtos = agreementService.getAllAgreements();
        assertNotNull(agreementDtos);
    }

    @Test
    public void testGetAllAccounts_WhenNoAgreementsExist() {

        when(agreementRepo.findAll()).thenReturn(Arrays.asList());

        when(agreementMapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        Iterable<AgreementDto> result = agreementService.getAllAgreements();

        assertEquals(Arrays.asList(), result);

    }

    @Test
    public void testGetAgreementById_WhenIdExists() {
        Long agreementId = 1L;

        Agreement agreement = new Agreement();
        agreement.setId(agreementId);
        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(agreementId);

        when(agreementRepo.findById(agreementId)).thenReturn(Optional.of(agreement));
        when(agreementMapper.fromAgreementToDto(agreement)).thenReturn(agreementDto);

        Optional<AgreementDto> agreementDto1 = agreementService.getAgreementById(agreementId);

        assertEquals(agreementDto, agreementDto1.orElse(null));
    }

    @Test
    public void testGetAgreementById_WhenIdDoesNotExist() {
        Long agId = 1L;

        when(agreementService.getAgreementById(agId)).thenReturn(Optional.empty());

        Optional<AgreementDto> agreementDto = agreementService.getAgreementById(agId);

        assertEquals(Optional.empty(), agreementDto);
    }

    @Test
    public void  testCreateAgreement(){

        Agreement agreement = new Agreement();
        agreement.setId(1L);
        agreement.setStatus(AgreementStatus.PENDING);

        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setId(1L);
        agreementDto.setStatus(AgreementStatus.PENDING);

        when(agreementMapper.fromAgreementToDto(agreement)).thenReturn(agreementDto);
        when(agreementRepo.save(agreement)).thenReturn(agreement);
        when(agreementMapper.fromDtoToAgreement(agreementDto)).thenReturn(agreement);

        AgreementDto createdAgreement = agreementService.createAgreement(agreementDto);

        assertEquals(agreementDto.getId(), createdAgreement.getId());
        assertEquals(agreementDto.getStatus(), createdAgreement.getStatus());

        verify(agreementMapper, times(1)).fromAgreementToDto(agreement);
        verify(agreementRepo, times(1)).save(agreement);
        verify(agreementMapper, times(1)).fromDtoToAgreement(agreementDto);

    }

    @Test
    public void testUpdateAgreement_ExistingAgreement(){
        Long aggId = 1L;

        AgreementDto agreementDto = new AgreementDto();
        agreementDto.setStatus(AgreementStatus.ACTIVE);
        agreementDto.setInterest_rate(new BigDecimal("5.0"));

        Agreement agreement = new Agreement();

        when(agreementRepo.findById(aggId)).thenReturn(Optional.of(agreement));
        when(agreementMapper.fromAgreementToDto(agreement)).thenReturn(agreementDto);
        when(agreementRepo.save(agreement)).thenReturn(agreement);

        AgreementDto updatedAgreement = agreementService.updateAgreementById(aggId, agreementDto);

        assertEquals(agreementDto, updatedAgreement);
    }

    @Test
    public void testUpdateAgreement_NonExistingAgreement(){

        Long aggId = 999L;

        when(agreementRepo.findById(aggId)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> agreementService.updateAgreementById(aggId, new AgreementDto()));
    }

    @Test
    public void testDeleteAgreement_ExistingAgreement(){

        Long aggID = 1L;
        Agreement agreement = new Agreement();

        when(agreementRepo.findById(aggID)).thenReturn(Optional.of(agreement));

        agreementService.deleteAgreementById(aggID);

        verify(agreementRepo, times(1)).delete(agreement);
    }

    @Test
    public void testDeleteAgreement_NonExistingAgreement(){

        Long aggID = 999L;

        when(agreementRepo.findById(aggID)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> agreementService.deleteAgreementById(aggID));
    }
}