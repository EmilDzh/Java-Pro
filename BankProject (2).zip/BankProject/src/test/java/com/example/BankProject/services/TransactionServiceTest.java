package com.example.BankProject.services;

import com.example.BankProject.frankfurterService.FrankfurterService;
import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.dto.mapper.TransactionMapper;
import com.example.BankProject.entity.Enum.CurrencyCode;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.TransactionRepo;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class TransactionServiceTest {

    @Autowired
    private TransactionService transactionService;

    @MockBean
    private TransactionRepo transactionRepo;

    @MockBean
    private AccountService accountService;

    @MockBean
    private TransactionMapper transactionMapper;

    @MockBean
    private FrankfurterService frankfurterService;

    @MockBean
    private DatabaseInitializer databaseInitializer;

    @Test
    public void testGetAllTransactions() {

        Iterable<TransactionDto> transactionDtos = transactionService.getAllTransactions();

        assertNotNull(transactionDtos);
    }

    @Test
    public void testGetAllTransactions_WhenNoTransactionsExist() {

        when(transactionRepo.findAll()).thenReturn(Arrays.asList());

        when(transactionMapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        Iterable<TransactionDto> transactionDtos = transactionService.getAllTransactions();

        assertEquals(Arrays.asList(), transactionDtos);
    }

    @Test
    public void testGetTransactionById_WhenIdExists() {
        Long id = 1L;

        Transaction transaction = new Transaction();
        transaction.setId(id);

        TransactionDto transactionDto = new TransactionDto();
        transactionDto.setId(id);

        when(transactionRepo.findById(id)).thenReturn(Optional.of(transaction));
        when(transactionMapper.fromTransactionToDto(transaction)).thenReturn(transactionDto);

        Optional<TransactionDto> transactionDto1 = transactionService.getTransactionById(id);

        assertEquals(transactionDto, transactionDto1.orElse(null));
    }

    @Test
    public void testGetTransactionById_WhenIdDoesNotExist() {
        Long id = 1L;

        when(transactionRepo.findById(id)).thenReturn(Optional.empty());

        Optional<TransactionDto> transactionDto = transactionService.getTransactionById(id);

        assertEquals(Optional.empty(), transactionDto);
    }

    @Test
    public void testTransfer_Success() {
        Long fromAccountId = 1L;
        AccountDto fromAcc = new AccountDto();
        fromAcc.setId(fromAccountId);
        fromAcc.setBalance(new BigDecimal("5000.00"));
        fromAcc.setCurrency_code(CurrencyCode.EUR);

        Long toAccountId = 2L;
        AccountDto toAcc = new AccountDto();
        toAcc.setId(toAccountId);
        toAcc.setBalance(new BigDecimal("5000.00"));
        toAcc.setCurrency_code(CurrencyCode.EUR);

        BigDecimal amount = new BigDecimal("100.00");

        when(frankfurterService.getExchangeRate(anyString(), anyString())).thenReturn(1.0);
        when(accountService.getAccountById(fromAccountId)).thenReturn(Optional.of(fromAcc));
        when(accountService.getAccountById(toAccountId)).thenReturn(Optional.of(toAcc));

        // Заменяем вызов метода transfer() на try-catch блок, чтобы обработать исключение
        try {
            TransactionDto transactionDto = transactionService.transfer(fromAccountId, toAccountId, amount);
            assertNotNull(transactionDto);
            Transaction transaction = transactionMapper.fromDtoToTransaction(transactionDto);
            verify(transactionRepo, times(1)).save(transaction);
        } catch (Exception e) {
            // Должен обрабатываться здесь
            fail("Exception thrown: " + e.getMessage());
        }
    }

    @Test
    public void testTransfer_InvalidAmount() {
        Long fromAccountId = 1L;
        Long toAccountId = 2L;
        BigDecimal amount = BigDecimal.ZERO;

        // Мокируем вызовы методов, чтобы выбросить исключение при получении счетов
        when(accountService.getAccountById(fromAccountId)).thenReturn(Optional.of(new AccountDto()));
        when(accountService.getAccountById(toAccountId)).thenReturn(Optional.of(new AccountDto()));

        // Перехватываем исключение RuntimeException
        assertThrows(RuntimeException.class, () -> {
            transactionService.transfer(fromAccountId, toAccountId, amount);
        });
    }

    @Test
    public void testTransfer_FromAccountNotFound() {
        Long fromAccountId = 1L;
        Long toAccountId = 2L;
        BigDecimal amount = new BigDecimal("100.00");


        when(accountService.getAccountById(fromAccountId)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            transactionService.transfer(fromAccountId, toAccountId, amount);
        });

    }

    @Test
    public void testTransfer_ToAccountNotFound() {
        Long fromAccountId = 1L;
        Long toAccountId = 2L;
        BigDecimal amount = new BigDecimal("100.00");


        when(transactionRepo.findById(toAccountId)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            transactionService.transfer(fromAccountId, toAccountId, amount);
        });

    }

    @Test
    public void NotEnoughMoney(){

        Long fromAccountId = 1L;
        AccountDto fromAcc = new AccountDto();
        fromAcc.setId(fromAccountId);
        fromAcc.setBalance(BigDecimal.ZERO);
        fromAcc.setCurrency_code(CurrencyCode.EUR);

        Long toAccountId = 2L;
        AccountDto toAcc = new AccountDto();
        toAcc.setId(toAccountId);
        toAcc.setBalance(new BigDecimal("5000.00"));
        toAcc.setCurrency_code(CurrencyCode.EUR);

        BigDecimal amount = new BigDecimal("100.00");



        // Мокируем вызовы методов, чтобы выбросить исключение при получении счетов
        when(accountService.getAccountById(fromAccountId)).thenReturn(Optional.of(new AccountDto()));
        when(accountService.getAccountById(toAccountId)).thenReturn(Optional.of(new AccountDto()));



        assertThrows(RuntimeException.class, () -> {
            transactionService.transfer(fromAccountId, toAccountId, amount);
        });
    }

}