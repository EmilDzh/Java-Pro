package com.example.BankProject.services;

import com.example.BankProject.databaseInitializer.DatabaseInitializer;
import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.dto.mapper.ClientMapper;
import com.example.BankProject.entity.Client;
import com.example.BankProject.repository.ClientRepo;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("serviceTest")
class ClientServiceTest {

    @Autowired
    private ClientService clientService;

    @MockBean
    private ClientRepo clientRepo;

    @MockBean
    private ClientMapper clientMapper;

    @MockBean
    private DatabaseInitializer databaseInitializer;


    @Test
    public void getAllClients(){

        Iterable<ClientDto> clients = clientService.getAllClients();
        System.out.println(clients);
        assertNotNull(clients);
    }

    @Test
    public void testGetAllClients_WhenNoClientsExist(){

        when(clientRepo.findAll()).thenReturn(Arrays.asList());

        when(clientMapper.toDtoList(Arrays.asList())).thenReturn(Arrays.asList());

        Iterable<ClientDto> clientDtos = clientService.getAllClients();

        assertEquals(Arrays.asList(), clientDtos);

    }

    @Test
    public void testGetClientById_WhenIdExists(){
        Long id = 1L;

        Client client = new Client();
        client.setId(id);
        ClientDto clientDto = new ClientDto();
        clientDto.setId(id);

        when(clientRepo.findById(id)).thenReturn(Optional.of(client));
        when(clientMapper.fromClientToDto(client)).thenReturn(clientDto);

        Optional<ClientDto> clientDto1 = clientService.getClientById(id);

        assertEquals(clientDto, clientDto1.orElse(null));

    }

    @Test
    public void testGetClientById_WhenIdDoesNotExist(){

        Long id = 99L;

        when(clientRepo.findById(id)).thenReturn(Optional.empty());

        Optional<ClientDto> clientDto = clientService.getClientById(id);

        assertEquals(Optional.empty(), clientDto);
    }

    @Test
    public void testCreateClient(){

        Client client = new Client();
        client.setId(1L);
        client.setFirst_name("Test");
        client.setLast_name("LastTest");

        ClientDto clientDto = new ClientDto();
        clientDto.setId(1L);
        clientDto.setFirst_name("Test");
        clientDto.setLast_name("LastTest");

        when(clientMapper.fromClientToDto(client)).thenReturn(clientDto);
        when(clientRepo.save(client)).thenReturn(client);
        when(clientMapper.fromDtoToClient(clientDto)).thenReturn(client);

        ClientDto createdClient = clientService.createClient(clientDto);

        assertEquals(clientDto.getId(), createdClient.getId());
        assertEquals(clientDto.getFirst_name(), createdClient.getFirst_name());
        assertEquals(clientDto.getLast_name(), createdClient.getLast_name());

        verify(clientMapper, times(1)).fromClientToDto(client);
        verify(clientRepo, times(1)).save(client);
        verify(clientMapper, times(1)).fromDtoToClient(clientDto);
    }

    @Test
    public void testUpdateClient_ExistingClient(){

        Long id = 1L;

        ClientDto clientDto = new ClientDto();
        clientDto.setUsername("UserTest");
        clientDto.setRole("TestRole");

        Client client = new Client();

        when(clientRepo.findById(id)).thenReturn(Optional.of(client));
        when(clientMapper.fromClientToDto(client)).thenReturn(clientDto);
        when(clientRepo.save(client)).thenReturn(client);

        ClientDto updatedClient = clientService.updateClientById(id, clientDto);

        assertEquals(clientDto, updatedClient);


    }

    @Test
    public void  testUpdateClient_NonExistingClient(){

        Long id = 999L;

        when(clientRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> clientService.updateClientById(id, new ClientDto()));
    }

    @Test
    public void testDeleteClient_ExistingClient(){

        Long id = 1L;

        Client client = new Client();

        when(clientRepo.findById(id)).thenReturn(Optional.of(client));

        clientService.deleteClientByID(id);

        verify(clientRepo, times(1)).delete(client);
    }

    @Test
    public void testDeleteClient_NonExistingClient(){
        Long id = 999L;

        when(clientRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> clientService.deleteClientByID(id));
    }

}