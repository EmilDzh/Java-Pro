package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.repository.ProductRepo;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

import static com.example.BankProject.entity.Enum.ProductStatus.CLOSED;
import static org.junit.Assert.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = "spring.profiles.active=null")
public class IntegrationTestForProductController {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private ProductRepo productRepo;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void shouldReturnAllProducts(){

        ResponseEntity<ProductDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/products",
                        ProductDto[].class
                );

        assertEquals(HttpStatus.OK, response.getStatusCode());

        int expectedProducts = 5;

        ProductDto[] productDtos = response.getBody();
        assertNotNull(productDtos);
        assertEquals(expectedProducts, productDtos.length);

    }

    @Test
    public void shouldReturnProductById(){

        Long productId = 1L;

        ResponseEntity<ProductDto> response = restTemplate
                .withBasicAuth("bastian" , "password")
                .getForEntity(
                        "http://localhost:" + port + "/products/" + productId,
                        ProductDto.class,
                        productId
                );
        assertEquals(HttpStatus.OK, response.getStatusCode());

        ProductDto productDto = response.getBody();
        assertNotNull(productDto);

    }

    @Test
    public void shouldReturnNotFoundForNotExistingProduct(){
        Long productId = 999L;

        ResponseEntity<ProductDto> response = restTemplate
                .withBasicAuth("bastian" , "password")
                .getForEntity(
                        "http://localhost:" + port + "/products/" + productId,
                        ProductDto.class,
                        productId
                );

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldReturnCreatedProduct(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"Product6NEW\", \"status\" : \"ACTIVE\", \"currency_code\" : \"EUR\", " +
                        "\"interest_rate\" : \"5.50\", \"limit\" : \"8\", \"updated_at\" : " + timestamp + "}",
                headers
        );

        assertEquals(productRepo.count(), 5);

        ResponseEntity<ProductDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/products/" + managerId,
                        request,
                        ProductDto.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        assertEquals(productRepo.count(), 6);
    }

    @Test
    public void shouldReturnErrorForNotExistingManager(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 999L;

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"Product6NEW\", \"status\" : \"ACTIVE\", \"currency_code\" : \"EUR\", " +
                        "\"interest_rate\" : \"5.50\", \"limit\" : \"8\", \"updated_at\" : " + timestamp + "}",
                headers
        );

        ResponseEntity<ProductDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/products/" + managerId,
                        request,
                        ProductDto.class,
                        managerId
                );
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void checkFieldsOfCreatedProduct() throws JSONException {

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;
        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> request = new HttpEntity<>(
                "{\"name\" : \"Product6NEW\", \"status\" : \"ACTIVE\", \"currency_code\" : \"EUR\", " +
                        "\"interest_rate\" : \"5.50\", \"limit\" : \"8\", \"updated_at\" : " + timestamp + "}",
                headers
        );



        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/products/" + managerId,
                        request,
                        String.class,
                        managerId
                );

        String result = response.getBody();
        assertNotNull(result);

        JSONObject jsonObject = new JSONObject(result);
        assertTrue(jsonObject.has("name"));
        assertEquals(jsonObject.get("status"), "ACTIVE");
    }

    @Test
    public void shouldUpdateProduct(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"name\" : \"Product6NEW\", \"status\" : \"ACTIVE\", \"currency_code\" : \"EUR\", " +
                        "\"interest_rate\" : \"5.50\", \"limit\" : \"8\", \"updated_at\" : " + timestamp + "}",
                headers
        );

        assertEquals(productRepo.count(), 5);

        ResponseEntity<ProductDto> createrResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/products/" + managerId,
                        createRequest,
                        ProductDto.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, createrResponse.getStatusCode());

        ProductDto productDto = createrResponse.getBody();
        assertNotNull(productDto);

        Long productId = productDto.getId();

        productDto.setName("newUpdatedName");
        productDto.setStatus(CLOSED);

        HttpEntity<ProductDto> updateRequest = new HttpEntity<>(productDto, headers);

        ResponseEntity<ProductDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/products/" + productId + "/" + managerId,
                        HttpMethod.PUT,
                        updateRequest,
                        ProductDto.class,
                        productId,
                        managerId
                );

        assertEquals(HttpStatus.OK, updateResponse.getStatusCode());

        ProductDto productDto1 = updateResponse.getBody();
        assertNotNull(productDto1);
        assertEquals("newUpdatedName", productDto1.getName());
        assertEquals(CLOSED,productDto1.getStatus());

    }

    @Test
    public void shouldReturnErrorWhileUpdatingProduct(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long productId = 1L;
        Long managerId = 999L;

        ProductDto productDto = new ProductDto();

        ResponseEntity<String> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/products/" + productId + "/" + managerId,
                        HttpMethod.PUT,
                        new HttpEntity<>(productDto, headers),
                        String.class,
                        productId,
                        managerId
                );
        assertEquals(HttpStatus.NOT_FOUND, updateResponse.getStatusCode());
    }

    @Test
    public void ShouldReturnErrorForNotExistingProduct(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long productId = 999L;
        Long managerId = 1L;

        ProductDto productDto = new ProductDto();

        ResponseEntity<String> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/products/" + productId + "/" + managerId,
                        HttpMethod.PUT,
                        new HttpEntity<>(productDto, headers),
                        String.class,
                        productId,
                        managerId
                );
        assertEquals(HttpStatus.NOT_FOUND, updateResponse.getStatusCode());


    }

    @Test
    public void shouldDeleteProduct(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 1L;

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"name\" : \"Product6NEW\", \"status\" : \"ACTIVE\", \"currency_code\" : \"EUR\", " +
                        "\"interest_rate\" : \"5.50\", \"limit\" : \"8\", \"updated_at\" : " + timestamp + "}",
                headers
        );

        assertEquals(productRepo.count(), 5);

        ResponseEntity<ProductDto> createrResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/products/" + managerId,
                        createRequest,
                        ProductDto.class,
                        managerId
                );

        assertEquals(HttpStatus.CREATED, createrResponse.getStatusCode());

        ProductDto productDto = createrResponse.getBody();
        assertNotNull(productDto);

        Long createdProductId = productDto.getId();

        ResponseEntity<ProductDto> deleteResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/products/" + createdProductId,
                        HttpMethod.DELETE,
                        null,
                        ProductDto.class,
                        createdProductId
                );

        assertEquals(HttpStatus.OK, deleteResponse.getStatusCode());

        ResponseEntity<ProductDto> check = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/products/" + createdProductId,
                        ProductDto.class,
                        createdProductId
                );

        assertEquals(HttpStatus.NOT_FOUND, check.getStatusCode());
    }


}
