package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.entity.Product;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ManagerMapperTest {

    ManagerMapper mapper = Mappers.getMapper(ManagerMapper.class);

    @Test
    public void testFromManagerToDto() {
        // Создаем тестовый объект Manager
        Manager manager = new Manager();
        manager.setId(1L);
        manager.setFirst_name("John Doe");

        // Создаем тестовые объекты Client и Product
        Client client = new Client();
        client.setId(1L);
        client.setFirst_name("Client 1");

        Product product = new Product();
        product.setId(1L);
        product.setName("Product 1");

        // Добавляем объекты Client и Product в список clients и products соответственно
        Set<Client> clients = new HashSet<>();
        clients.add(client);

        List<Product> products = new ArrayList<>();
        products.add(product);

        manager.setClients(clients);
        manager.setProducts(products);

        // Преобразуем объект Manager в ManagerDto
        ManagerDto managerDto = mapper.fromManagerToDto(manager);

        // Проверяем, что поля ManagerDto отображаются корректно
        assertEquals(manager.getId(), managerDto.getId());
        assertEquals(manager.getFirst_name(), managerDto.getFirst_name());

        // Проверяем, что список clientDtos не null и содержит ожидаемое количество элементов
        assertNotNull(managerDto.getClientDtos());
        assertEquals(manager.getClients().size(), managerDto.getClientDtos().size());

        // Проверяем, что список productDtos не null и содержит ожидаемое количество элементов
        assertNotNull(managerDto.getProductDtos());
        assertEquals(manager.getProducts().size(), managerDto.getProductDtos().size());
    }

    @Test
    public void testToDtoList() {
        // Создаем список тестовых объектов Manager
        List<Manager> managers = new ArrayList<>();
        Manager manager1 = new Manager();
        manager1.setId(1L);
        manager1.setFirst_name("Manager 1");

        Manager manager2 = new Manager();
        manager2.setId(2L);
        manager2.setFirst_name("Manager 2");

        managers.add(manager1);
        managers.add(manager2);

        // Преобразуем список Manager в список ManagerDto
        List<ManagerDto> managerDtos = mapper.toDtoList(managers);

        // Проверяем, что список ManagerDto не null и содержит ожидаемое количество элементов
        assertNotNull(managerDtos);
        assertEquals(managers.size(), managerDtos.size());

        // Проверяем соответствие значений в списках
        for (int i = 0; i < managers.size(); i++) {
            Manager manager = managers.get(i);
            ManagerDto managerDto = managerDtos.get(i);
            assertEquals(manager.getId(), managerDto.getId());
            assertEquals(manager.getFirst_name(), managerDto.getFirst_name());
            // Добавьте дополнительные проверки, если есть другие поля для проверки
        }
    }

    @Test
    public void testFromDtoToManager() {
        // Создаем тестовый объект ManagerDto
        ManagerDto managerDto = new ManagerDto();
        managerDto.setId(1L);
        managerDto.setFirst_name("Manager 1");

        // Создаем список тестовых объектов ClientDto и ProductDto
        List<ClientDto> clientDtos = new ArrayList<>();
        List<ProductDto> productDtos = new ArrayList<>();

        // Преобразуем ManagerDto в объект Manager
        Manager manager = mapper.fromDtoToManager(managerDto);

        // Проверяем, что объекты корректно отображаются
        assertEquals(managerDto.getId(), manager.getId());
        assertEquals(managerDto.getFirst_name(), manager.getFirst_name());
        // Проверяем, что списки clientDtos и productDtos маппятся в clients и products соответственно
        assertNotNull(manager.getClients());
        assertNotNull(manager.getProducts());
        // Добавьте дополнительные проверки, если есть другие поля для проверки
    }

    @Test
    public void testUpdateManagerFromDto() {
        // Создаем тестовые объекты Manager и ManagerDto
        Manager manager = new Manager();
        manager.setId(1L);
        manager.setFirst_name("Manager 1");

        ManagerDto managerDto = new ManagerDto();
        managerDto.setId(1L);
        managerDto.setFirst_name("Updated Manager");

        // Вызываем метод обновления
        mapper.updateManagerFromDto(managerDto, manager);

        // Проверяем, что поля обновлены правильно
        assertEquals(1L, manager.getId()); // Поле id должно оставаться неизменным
        assertEquals("Updated Manager", manager.getFirst_name()); // Поле name должно обновиться
    }



}