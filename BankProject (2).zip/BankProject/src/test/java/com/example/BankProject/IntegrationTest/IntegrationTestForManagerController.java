package com.example.BankProject.IntegrationTest;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.repository.ManagerRepo;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

import static org.junit.Assert.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = "spring.profiles.active=null")
public class IntegrationTestForManagerController {

    @Value(value = "${local.server.port}")
    private int port;

    @Autowired
    private ManagerRepo managerRepo;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void shouldReturnAllManagers() {

        ResponseEntity<ManagerDto[]> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/managers",
                        ManagerDto[].class
                );
        assertEquals(HttpStatus.OK, response.getStatusCode());

        int expectedManagers = 2;

        ManagerDto[] managerDtos = response.getBody();
        assertNotNull(managerDtos);

        assertEquals(expectedManagers, managerDtos.length);

    }

    @Test
    public void shouldReturnManagerById() {

        Long managerId = 1L;

        ResponseEntity<ManagerDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/managers/" + managerId,
                        ManagerDto.class,
                        managerId
                );
        assertEquals(HttpStatus.OK, response.getStatusCode());

        ManagerDto managerDto = response.getBody();
        assertNotNull(managerDto);
    }

    @Test
    public void shouldReturnNotFoundForNotExistingManager() {

        Long managerId = 999L;

        ResponseEntity<ManagerDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/managers/" + managerId,
                        ManagerDto.class,
                        managerId
                );
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void shouldReturnCreatedManager() {

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> request = new HttpEntity<>(
                "{\"first_name\" : \"New\", \"last_name\" : \"Manager\", \"status\" : \"ACTIVE\", " +
                        "\"description\" : \"new manager\", \"created_at\" : " + timestamp + ", \"username\" " +
                        ": \"newManager\", \"password\" : \"newPassword\", \"role\" : \"ROLE_ADMIN\"}",
                headers
        );

        assertEquals(managerRepo.count(), 2);

        ResponseEntity<ManagerDto> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/managers/",
                        request,
                        ManagerDto.class
                );
        System.out.println(response.getBody());

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        ManagerDto managerDto = response.getBody();
        assertNotNull(managerDto);
        assertEquals(managerRepo.count(), 3);
    }

    @Test
    public void checkFieldsOfCreatedManager() throws JSONException {

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> request = new HttpEntity<>(
                "{\"first_name\" : \"New\", \"last_name\" : \"Manager\", \"status\" : \"ACTIVE\", " +
                        "\"description\" : \"new manager\", \"created_at\" : " + timestamp + ", \"username\" " +
                        ": \"newManager\", \"password\" : \"newPassword\", \"role\" : \"ROLE_ADMIN\"}",
                headers
        );

        assertEquals(managerRepo.count(), 2);

        ResponseEntity<String> response = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/managers/",
                        request,
                        String.class
                );
        System.out.println(response.getBody());

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        String result = response.getBody();


        JSONObject jsonObject = new JSONObject(result);
        assertTrue(jsonObject.has("first_name"));
        assertEquals(jsonObject.get("role"), "ROLE_ADMIN");
    }

    @Test
    public void shouldUpdateManager(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"first_name\" : \"New\", \"last_name\" : \"Manager\", \"status\" : \"ACTIVE\", " +
                        "\"description\" : \"new manager\", \"created_at\" : " + timestamp + ", \"username\" " +
                        ": \"newManager\", \"password\" : \"newPassword\", \"role\" : \"ROLE_ADMIN\"}",
                headers
        );

        assertEquals(managerRepo.count(), 2);

        ResponseEntity<ManagerDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/managers/",
                        createRequest,
                        ManagerDto.class
                );

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());

        ManagerDto managerDto = createResponse.getBody();
        assertNotNull(managerDto);

        Long managerId = managerDto.getId();

        managerDto.setDescription("UpDatedDescription");
        managerDto.setRole("UPDATE_ROLE");

        HttpEntity<ManagerDto> updateRequest = new HttpEntity<>(managerDto, headers);

        ResponseEntity<ManagerDto> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/managers/" + managerId,
                        HttpMethod.PUT,
                        updateRequest,
                        ManagerDto.class,
                        managerId
                );

        assertEquals(HttpStatus.OK, updateResponse.getStatusCode());

        ManagerDto managerDto1 = updateResponse.getBody();
        assertNotNull(managerDto1);

        assertEquals("UpDatedDescription", managerDto1.getDescription());
        assertEquals("UPDATE_ROLE", managerDto1.getRole());


    }

    @Test
    public void shouldReturnErrorWhileUpdatingManager(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long managerId = 999L;

        ManagerDto managerDto = new ManagerDto();

        ResponseEntity<String> updateResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http://localhost:" + port + "/admin/managers/" + managerId,
                        HttpMethod.PUT,
                        new HttpEntity<>(managerDto, headers),
                        String.class,
                        managerId
                );
        assertEquals(HttpStatus.NOT_FOUND, updateResponse.getStatusCode());
    }

    @Test
    public void shouldDeleteManager(){

        HttpHeaders headers = new HttpHeaders();
        headers.add("content-type", "application/json");

        Long timestamp = Instant.now().toEpochMilli();

        HttpEntity<String> createRequest = new HttpEntity<>(
                "{\"first_name\" : \"New\", \"last_name\" : \"Manager\", \"status\" : \"ACTIVE\", " +
                        "\"description\" : \"new manager\", \"created_at\" : " + timestamp + ", \"username\" " +
                        ": \"newManager\", \"password\" : \"newPassword\", \"role\" : \"ROLE_ADMIN\"}",
                headers
        );

        assertEquals(managerRepo.count(), 2);

        ResponseEntity<ManagerDto> createResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .postForEntity(
                        "http://localhost:" + port + "/admin/managers/",
                        createRequest,
                        ManagerDto.class
                );

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());

        ManagerDto managerDto = createResponse.getBody();
        assertNotNull(managerDto);

        Long managerId = managerDto.getId();

        ResponseEntity<ManagerDto> deleteResponse = restTemplate
                .withBasicAuth("bastian", "password")
                .exchange(
                        "http:localhost:" + port + "/admin/managers/" + managerId,
                        HttpMethod.DELETE,
                        null,
                        ManagerDto.class,
                        managerId
                );

        assertEquals(HttpStatus.OK, deleteResponse.getStatusCode());

        ResponseEntity<ManagerDto> check = restTemplate
                .withBasicAuth("bastian", "password")
                .getForEntity(
                        "http://localhost:" + port + "/admin/managers/" + managerId,
                        ManagerDto.class,
                        managerId
                );

        assertEquals(HttpStatus.NOT_FOUND, check.getStatusCode());
    }
}
