package com.example.BankProject.services;

import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.mapper.AccountMapper;
import com.example.BankProject.entity.Account;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.AccountRepo;
import com.example.BankProject.repository.TransactionRepo;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

@Service
public class AccountService {

    @Autowired
    public AccountRepo accountRepo;

    @Autowired
    public TransactionRepo transactionRepo;

    @Autowired
    public AccountMapper accountMapper;

    @Autowired
    public AccountService(AccountRepo accountRepo, TransactionRepo transactionRepo, AccountMapper accountMapper) {
        this.accountRepo = accountRepo;
        this.transactionRepo = transactionRepo;
        this.accountMapper = accountMapper;
    }


    public Iterable<AccountDto> getAllAccounts() {
        Iterable<Account> accounts = accountRepo.findAll();
        return accountMapper.toDtoList(accounts);
    }

    public Optional<AccountDto> getAccountById(
            Long id
    ) {
        return accountRepo.findById(id)
                .map(account -> accountMapper.fromAccountToDto(account));
    }


//    public Account createAccount(Account account) {
//
//        return accountRepo.save(account);
//    }

    public AccountDto createAccount(AccountDto accountDto) {
        Account account = accountMapper.fromDtoToAccount(accountDto);
        Account savedAccount = accountRepo.save(account);
        return accountMapper.fromAccountToDto(savedAccount);
    }

    public AccountDto updateAccount(Long id, AccountDto accountDto) {
        Optional<Account> account = accountRepo.findById(id);

        if (account.isPresent()) {
            Account account1 = account.get();

            accountMapper.updateAccountFromDto(accountDto, account1);

            Account updatedAccount = accountRepo.save(account1);

            return accountMapper.fromAccountToDto(updatedAccount);
        }

        throw new EntityNotFoundException("Account with id " + id + " not found");

    }

    public void deleteAccount(Long id) {
        Optional<Account> account = accountRepo.findById(id);

        if (account.isPresent()) {

            Account account1 = account.get();
            accountRepo.delete(account1);
        } else {
            throw new EntityNotFoundException("Account with id " + id + " not found");
        }
    }

    public BigDecimal getAccountBalance(Long id) {

        Account account = accountRepo.findById(id).orElse(null);
        AccountDto accountDto = accountMapper.fromAccountToDto(account);
        return accountDto != null ? accountDto.getBalance() : BigDecimal.ZERO;
    }

    public List<Transaction> getTransactionHistoryById(Long accountId) {

        List<Transaction> debitTransactions = transactionRepo.findByDebit_account_id(accountId);
        List<Transaction> creditTransactions = transactionRepo.findByCredit_account_id(accountId);

        // Объединить транзакции из обоих списков
        List<Transaction> allTransactions = new ArrayList<>();
        allTransactions.addAll(debitTransactions);
        allTransactions.addAll(creditTransactions);

        return allTransactions;

    }

    @Transactional
    public void updateBalance(Long accountId, BigDecimal newBalance) {

        accountRepo.updateBalance(accountId, newBalance);

    }

}
