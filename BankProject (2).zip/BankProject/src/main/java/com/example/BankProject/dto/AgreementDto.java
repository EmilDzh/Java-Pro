package com.example.BankProject.dto;

import com.example.BankProject.entity.Enum.AgreementStatus;
import com.example.BankProject.entity.Product;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgreementDto {

    private Long id;

    private BigDecimal interest_rate;

    private AgreementStatus status;

    private BigDecimal sum;

    private Timestamp created_at;

    private Timestamp updated_at;

    @JsonIgnore
    private ProductDto productDto;

    @JsonIgnore
    private AccountDto accountDto;

    public AgreementDto(Long id, BigDecimal interestRate, AgreementStatus status, BigDecimal sum, Timestamp updatedAt) {
        this.id = id;
        this.interest_rate = interestRate;
        this.status = status;
        this.sum = sum;
        this.updated_at = updatedAt;
    }
}
