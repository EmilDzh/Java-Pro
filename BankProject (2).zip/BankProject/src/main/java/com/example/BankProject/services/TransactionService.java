package com.example.BankProject.services;

import com.example.BankProject.frankfurterService.FrankfurterService;
import com.example.BankProject.dto.AccountDto;
import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.dto.mapper.TransactionMapper;
import com.example.BankProject.entity.Enum.TransactionType;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.repository.TransactionRepo;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.util.Optional;


@Service
public class TransactionService {

    @Autowired
    private TransactionRepo transactionRepo;

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionMapper transactionMapper;

    @Autowired
    private FrankfurterService frankfurterService;

    private static final Logger logger = LoggerFactory.getLogger(TransactionService.class);


    public Iterable<TransactionDto> getAllTransactions() {
        Iterable<Transaction> transactions = transactionRepo.findAll();
        return transactionMapper.toDtoList(transactions);
    }

    public Optional<TransactionDto> getTransactionById(
            Long id
    ) {
        return transactionRepo.findById(id)
                .map(t -> transactionMapper.fromTransactionToDto(t));
    }

    @Transactional
    public TransactionDto transfer(Long fromAccountId, Long toAccountId, BigDecimal amount) {
        logger.info("Transfer started");

        try {
            // Проверка наличия денег на счете
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                logger.error("Invalid transfer amount");
                throw new IllegalArgumentException("Not enough money");
            }

            // Получение счетов
            AccountDto fromAccount = accountService.getAccountById(fromAccountId)
                    .orElseThrow(() -> new EntityNotFoundException("From Account not found"));
            AccountDto toAccount = accountService.getAccountById(toAccountId)
                    .orElseThrow(() -> new EntityNotFoundException("To Account not found"));
            logger.info("Accounts found");

            // Обновление баланса
            fromAccount.setBalance(fromAccount.getBalance().subtract(amount));

            String fromCurrency = fromAccount.getCurrency_code().toString();
            String toCurrency = toAccount.getCurrency_code().toString();

            if (!fromCurrency.equals(toCurrency)) {
                double exchangeRate = frankfurterService.getExchangeRate(fromCurrency, toCurrency);
                amount = amount.multiply(BigDecimal.valueOf(exchangeRate));
            }

            // Проверка наличия достаточного баланса
            if (fromAccount.getBalance().compareTo(amount) < 0) {
                logger.error("Insufficient funds");
                throw new RuntimeException("Insufficient funds");
            }
            logger.info("Enough money");

            // Обновление баланса
            toAccount.setBalance(toAccount.getBalance().add(amount));
            logger.info("Balance updated");

            // Обновление балансов в репозитории
            accountService.updateBalance(fromAccountId, fromAccount.getBalance());
            accountService.updateBalance(toAccountId, toAccount.getBalance());
            logger.info("Balances updated in the repository");

            // Создание и сохранение транзакции
            TransactionDto transactionDto = new TransactionDto();
            transactionDto.setType(TransactionType.TRANSFER);
            transactionDto.setAmount(amount);
            transactionDto.setDescription("Verwendungszweck ist Unterstützung");
            transactionDto.setDebit_accountDto_id(fromAccount);
            transactionDto.setCredit_accountDto_id(toAccount);

            Transaction transaction = transactionMapper.fromDtoToTransaction(transactionDto);
            transactionRepo.save(transaction);
            logger.info("Transaction saved");

            return transactionDto;
        } catch (Exception e) {
            logger.error("Failed to save transaction", e);
            // Обработка ошибки при сохранении транзакции
            System.err.println(e.getMessage());
            throw new RuntimeException("Failed to save transaction", e);
        }
    }
}
