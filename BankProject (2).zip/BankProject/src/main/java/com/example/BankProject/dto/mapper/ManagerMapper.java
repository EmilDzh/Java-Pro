package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.entity.Manager;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Mapper(componentModel = "spring", uses = ManagerMapper.class)
public interface ManagerMapper {
    ManagerMapper managerMapper = Mappers.getMapper(ManagerMapper.class);

    @Mapping(source = "clients", target = "clientDtos")
    @Mapping(source = "products", target = "productDtos")
    ManagerDto fromManagerToDto(Manager manager);

    List<ManagerDto> toDtoList(Iterable<Manager> managers);

    @Mapping(source = "clientDtos", target = "clients")
    @Mapping(source = "productDtos", target = "products")
    Manager fromDtoToManager(ManagerDto managerDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }

    @Mapping(target = "id", ignore = true)
    void updateManagerFromDto(ManagerDto managerDto, @MappingTarget Manager manager);


}
