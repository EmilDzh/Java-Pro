package com.example.BankProject.services;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.dto.mapper.ManagerMapper;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.repository.ManagerRepo;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

@Service
public class ManagerService {

    @Autowired
    private ManagerRepo managerRepo;

    @Autowired
    private ManagerMapper managerMapper;

    public Iterable<ManagerDto> getAllManagers() {
        Iterable<Manager> managers = managerRepo.findAll();
        return managerMapper.toDtoList(managers);
    }

    public Optional<ManagerDto> getManagerById(Long id) {
        return managerRepo.findById(id)
                .map(manager -> managerMapper.fromManagerToDto(manager));
    }

    public ManagerDto createManager(ManagerDto managerDto) {

        Manager manager = managerMapper.fromDtoToManager(managerDto);
        Manager savedManager = managerRepo.save(manager);
        return managerMapper.fromManagerToDto(savedManager);
    }

    public ManagerDto updateManager(Long id, ManagerDto managerDto) {
        Optional<Manager> manager = managerRepo.findById(id);

        if (manager.isPresent()) {
            Manager findedManager = manager.get();

            managerMapper.updateManagerFromDto(managerDto, findedManager);

            Manager updatedManager = managerRepo.save(findedManager);

            return managerMapper.fromManagerToDto(updatedManager);
        }

        throw new EntityNotFoundException("Manager with id " + id + " not found");
    }

    public void deleteManagerById(Long id) {
        Optional<Manager> managerOptional = managerRepo.findById(id);

        if (managerOptional.isPresent()) {
            Manager manager = managerOptional.get();
            managerRepo.delete(manager);
        } else {

            throw new EntityNotFoundException("Manager with id " + id + " not found");
        }
    }


}
