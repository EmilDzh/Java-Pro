package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.entity.Transaction;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring", uses = TransactionMapper.class)
public interface TransactionMapper {

    TransactionMapper transactionMapper = Mappers.getMapper(TransactionMapper.class);


    @Mapping(source = "debit_account_id", target = "debit_accountDto_id")
    @Mapping(source = "credit_account_id", target = "credit_accountDto_id")
    TransactionDto fromTransactionToDto(Transaction transaction);

    List<TransactionDto> toDtoList(Iterable<Transaction> transactions);




    @Mapping(source = "debit_accountDto_id", target = "debit_account_id")
    @Mapping(source = "credit_accountDto_id", target = "credit_account_id")
    Transaction fromDtoToTransaction(TransactionDto transactionDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }
}
