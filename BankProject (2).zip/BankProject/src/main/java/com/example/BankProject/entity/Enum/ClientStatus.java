package com.example.BankProject.entity.Enum;

public enum ClientStatus {
    ACTIVE("Active"),
    INACTIVE("Inactive"),
    PENDING("Pending");

    private final String label;

    ClientStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
    }
