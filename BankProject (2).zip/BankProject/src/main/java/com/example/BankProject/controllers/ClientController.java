package com.example.BankProject.controllers;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.entity.Client;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ClientService;
import com.example.BankProject.services.ManagerService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
public class ClientController {

    @Autowired
    private ClientService clientService;

    @Autowired
    private ManagerService managerService;


    @GetMapping("/admin/clients")
    public Iterable<ClientDto> getAllClients() {
        return clientService.getAllClients();
    }


    @GetMapping("/admin/clients/{id}")
    public ResponseEntity<ClientDto> getClientById(
            @PathVariable Long id
    ) {
        Optional<ClientDto> clientDto = clientService.getClientById(id);
        return clientDto.map(c -> new ResponseEntity<>(c, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    @PostMapping("/admin/clients/{managerId}")
    public ResponseEntity<ClientDto> createClient(
            @PathVariable(name = "managerId") Long id,
            @RequestBody ClientDto clientDto
    ) {

        Optional<ManagerDto> managerDto = managerService.getManagerById(id);

        if (managerDto.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        clientDto.setManagerDto(managerDto.get());

        ClientDto createdClient = clientService.createClient(clientDto);
        return new ResponseEntity<>(createdClient, HttpStatus.CREATED);
    }

    @PutMapping("/admin/clients/{clientId}/{managerId}")
    public ResponseEntity<ClientDto> updateClient(
            @PathVariable(name = "clientId") Long clientId,
            @PathVariable(name = "managerId") Long managerId,
            @RequestBody ClientDto clientDto
    ) {

        Optional<ManagerDto> managerDto = managerService.getManagerById(managerId);

        if (managerDto.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        try {
            clientDto.setManagerDto(managerDto.get());


            ClientDto upgradedClient = clientService.updateClientById(clientId, clientDto);
            return new ResponseEntity<>(upgradedClient, HttpStatus.OK);
        } catch (EntityNotFoundException ex) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/admin/clients/{id}")
    public ResponseEntity<Void> deleteClient(
            @PathVariable Long id
    ) {
        clientService.deleteClientByID(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
