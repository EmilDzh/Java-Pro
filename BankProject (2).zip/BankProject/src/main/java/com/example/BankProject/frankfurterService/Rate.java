package com.example.BankProject.frankfurterService;

import java.util.HashMap;
import java.util.Map;

//https://api.frankfurter.app/latest?amount=10&from=GBP&to=USD
//{"amount":10.0,"base":"GBP","date":"2023-09-11","rates":{"USD":12.5207}}
public class Rate {
    public double amount;
    public String base;

    public String date;
    public Map<String, Double> rates = new HashMap<>();
}
