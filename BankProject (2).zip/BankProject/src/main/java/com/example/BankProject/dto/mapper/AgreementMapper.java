package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.AgreementDto;
import com.example.BankProject.entity.Agreement;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring", uses = AgreementMapper.class)
public interface AgreementMapper {

    AgreementMapper agreementMapper = Mappers.getMapper(AgreementMapper.class);


    @Mapping(source = "account", target = "accountDto")
    @Mapping(source = "product", target = "productDto")
    AgreementDto fromAgreementToDto(Agreement agreement);

    List<AgreementDto> toDtoList(Iterable<Agreement> agreements);


    @Mapping(source = "accountDto", target = "account")
    @Mapping(source = "productDto", target = "product")
    @Mapping(source = "updated_at", target = "updated_at")
    Agreement fromDtoToAgreement(AgreementDto agreementDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }

    @Mapping(target = "id", ignore = true)
    void updateAgreementFromDto(AgreementDto agreementDto, @MappingTarget Agreement agreement);
}
