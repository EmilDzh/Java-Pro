package com.example.BankProject.frankfurterService;

import com.google.gson.Gson;
import org.springframework.stereotype.Service;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;


//https://drive.google.com/drive/folders/1atE_fIrHPz-CArNlLK_RaPaL2RXGRy5b

@Service
public class FrankfurterService {

    private String apiUrl = "https://api.frankfurter.app/latest";

    public double getExchangeRate(String fromCurrency, String toCurrency) {
        String service = apiUrl + "?from=" + fromCurrency + "&to=" + toCurrency;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(service);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            try (
                    InputStream is = connection.getInputStream();
                    Reader reader = new InputStreamReader(is);
                    BufferedReader bufferedReader = new BufferedReader(reader)
            ) {
                bufferedReader.lines().forEach(line -> stringBuilder.append(line));
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        Gson gson = new Gson();
        Rate rate = gson.fromJson(stringBuilder.toString(), Rate.class);
        return rate.rates.get(toCurrency);
    }
}
