package com.example.BankProject.services;

import com.example.BankProject.dto.ClientDto;
import com.example.BankProject.dto.mapper.ClientMapper;
import com.example.BankProject.entity.Client;
import com.example.BankProject.repository.ClientRepo;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.function.Function;

@Service
public class ClientService {

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    private ClientMapper clientMapper;

    public Iterable<ClientDto> getAllClients() {
        Iterable<Client> clients = clientRepo.findAll();
        return clientMapper.toDtoList(clients);
    }

    public Optional<ClientDto> getClientById(Long id) {

        Optional<Client> c = clientRepo.findById(id);

        return c
                .map(client -> clientMapper.fromClientToDto(client));
    }

    public ClientDto createClient(
            ClientDto clientDto
    ) {
        Client client = clientMapper.fromDtoToClient(clientDto);
        Client savedClient = clientRepo.save(client);
        return clientMapper.fromClientToDto(savedClient);
    }

    public ClientDto updateClientById(
            Long id,
            ClientDto updatedClientDto
    ) {
        Optional<Client> client = clientRepo.findById(id);

        if (client.isPresent()) {
            Client client1 = client.get();

            clientMapper.updateClientFromDto(updatedClientDto, client1);

            Client updatedClient = clientRepo.save(client1);

            return clientMapper.fromClientToDto(updatedClient);
        }

        throw new EntityNotFoundException("client with id " + id + " not found");
    }

    public void deleteClientByID(Long id) {
        Optional<Client> clientOptional = clientRepo.findById(id);
        if (clientOptional.isPresent()) {
            Client clientToDelete = clientOptional.get();
            clientRepo.delete(clientToDelete);
        } else {
            throw new EntityNotFoundException("Client with id " + id + " not found");
        }
    }



}
