package com.example.BankProject.controllers;

import com.example.BankProject.dto.TransactionDto;
import com.example.BankProject.entity.Transaction;
import com.example.BankProject.services.TransactionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.function.Function;

@RestController
@Slf4j
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/transactions")
    public Iterable<TransactionDto> getAllTransactions() {
        return transactionService.getAllTransactions();
    }

    @GetMapping("/transaction/{id}")
    public ResponseEntity<TransactionDto> getTransactionById(
            @PathVariable Long id
    ) {
        Optional<TransactionDto> transaction = transactionService.getTransactionById(id);
        return transaction.map(transaction1 -> new ResponseEntity<>(transaction1, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/transfer/{fromAccountId}/{toAccountId}")
    @Transactional
    public ResponseEntity<TransactionDto> transfer(
            @PathVariable(name = "fromAccountId") Long fromAccountId,
            @PathVariable(name = "toAccountId") Long toAccountId,
            @RequestBody BigDecimal amount
    ) {

        TransactionDto transactionDto = transactionService.transfer(fromAccountId, toAccountId, amount);

        if (transactionDto != null) {
            return new ResponseEntity<>(transactionDto, HttpStatus.ACCEPTED);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

    }
}
