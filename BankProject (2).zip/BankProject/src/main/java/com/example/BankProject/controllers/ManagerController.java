package com.example.BankProject.controllers;

import com.example.BankProject.dto.ManagerDto;
import com.example.BankProject.entity.Manager;
import com.example.BankProject.services.ManagerService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class ManagerController {

    @Autowired
    public ManagerService managerService;

    @GetMapping("/admin/managers")
    public Iterable<ManagerDto> getAllManagers() {
        return managerService.getAllManagers();
    }

    @GetMapping("/admin/managers/{id}")
    public ResponseEntity<ManagerDto> getManagerById(
            @PathVariable Long id
    ) {
        Optional<ManagerDto> managerDto = managerService.getManagerById(id);
        return managerDto.map(m -> new ResponseEntity<>(m, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PostMapping("/admin/managers/")
    public ResponseEntity<ManagerDto> createManager(
            @RequestBody ManagerDto managerDto

    ) {

        ManagerDto manager1 = managerService.createManager(managerDto);
        return new ResponseEntity<>(manager1, HttpStatus.CREATED);

    }


    @PutMapping("/admin/managers/{id}")
    public ResponseEntity<ManagerDto> updateManagerById(
            @PathVariable Long id,
            @RequestBody ManagerDto managerDto
    ) {
        try {
        ManagerDto managerDto1 = managerService.updateManager(id, managerDto);


            return new ResponseEntity<>(managerDto1, HttpStatus.OK);
        } catch (EntityNotFoundException ex) {
           return  new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/admin/managers/{id}")
    public ResponseEntity<Void> deleteManagerByID(

            @PathVariable Long id
    ) {
        managerService.deleteManagerById(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }
}
