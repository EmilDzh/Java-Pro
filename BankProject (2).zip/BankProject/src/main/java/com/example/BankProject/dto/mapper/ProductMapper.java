package com.example.BankProject.dto.mapper;

import com.example.BankProject.dto.ProductDto;
import com.example.BankProject.entity.Product;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring", uses = ProductMapper.class)
public interface ProductMapper {

    ProductMapper productMapper = Mappers.getMapper(ProductMapper.class);


    @Mapping(source = "agreements", target = "agreementDtos")
    @Mapping(source = "manager", target = "managerDto")
    ProductDto fromProductToDto(Product product);

    List<ProductDto> toDtoList(Iterable<Product> products);


    @Mapping(source = "agreementDtos", target = "agreements")
    @Mapping(source = "managerDto", target = "manager")
    Product fromDtoToProduct(ProductDto productDto);

    default Timestamp map(Timestamp instant) {
        return instant == null ? new Timestamp(new Date().getTime()) : instant;
    }

    @Mapping(target = "id", ignore = true)
    void updateProductFromDto(ProductDto productDto, @MappingTarget Product product);
}
