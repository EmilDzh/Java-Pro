package lesson29;

import lesson29.hw.GenericLinkedList;
import lesson29.hw.MyGCDImpl;
import org.junit.Test;
//https://gist.github.com/andriidemus/bd3e7e74c9f89218d4bfae3d910cc36e

import static org.junit.Assert.assertEquals;

public class Hw {

    @Test
    public void addFirst() {
        MyGCDImpl myGCD = new MyGCDImpl();
        myGCD.addFirst("Hello");
        myGCD.addFirst("World");
        myGCD.addFirst("Words");
        myGCD.addLast("Sdrow");

        assertEquals(
                4,
                myGCD.size()
        );
        assertEquals(
                "Words",
                myGCD.getFirst()
        );

        assertEquals(
                "Sdrow",
                myGCD.getLast()
        );

    }

    @Test
    public void TestIncreaseCapacity() {

        MyGCDImpl myGCD = new MyGCDImpl();

        for (int i = 0; i < 4; i++) {
            myGCD.addFirst(i);
        }

        myGCD.increaseCapacity();


        assertEquals(
                8,
                ((MyGCDImpl<?>) myGCD).source.length
        );
    }

    @Test
    public void TestGetFirst() {

        MyGCDImpl myGCD = new MyGCDImpl();
        myGCD.addFirst("blabla");
        myGCD.addFirst("trululu");

        assertEquals(
                "trululu",
                myGCD.getFirst()
        );
    }

    @Test
    public void TestRemoveFirst() {

        MyGCDImpl myGCD = new MyGCDImpl();
        myGCD.addFirst("Hello");
        myGCD.addFirst("buongiorno");
        myGCD.addFirst("Servus");

        myGCD.removeFirst();

        assertEquals(
                2,
                myGCD.size()
        );
    }

    @Test
    public void TestAddLast() {
        MyGCDImpl myGCD = new MyGCDImpl();

        for (int i = 0; i < 4; i++) {
            myGCD.addLast(i);
        }

        myGCD.addLast(5);

        int lastElementIndex = (((MyGCDImpl<?>) myGCD).firstElementIndex + myGCD.size() - 1) % myGCD.source.length;

        assertEquals(
                myGCD.getLast(),
                myGCD.source[lastElementIndex]
        );
    }

    @Test
    public void testGetLast() {
        MyGCDImpl myGCD = new MyGCDImpl();

        for (int i = 0; i < 4; i++) {
            myGCD.addFirst(i);
        }

        int lastElementIndex = (myGCD.firstElementIndex + myGCD.size() - 1) % myGCD.source.length;

        assertEquals(
                myGCD.getLast(),
                myGCD.source[lastElementIndex]
        );
    }

    @Test
    public void removeLast() {
        MyGCDImpl myGCD = new MyGCDImpl();

        myGCD.addFirst(1);
        myGCD.addFirst(2);
        myGCD.addFirst(3);

        int lastElem = (int) myGCD.removeLast();

        assertEquals(
                2,
                myGCD.size()
        );

        assertEquals(
                1,
                lastElem
        );

    }

    @Test
    public void testContains(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();
        genericLinkedList.add("Hola");
        genericLinkedList.add("Aloha");
        genericLinkedList.add(3);

        assertEquals(
                true,
                genericLinkedList.contains(3)
        );
    }

    @Test
    public void testSet(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();

        genericLinkedList.add(1);
        genericLinkedList.add(2);
        genericLinkedList.add(3);

        genericLinkedList.set(1,55);

        assertEquals(
                55,
                genericLinkedList.get(1)
        );
    }

    @Test
    public void testAdd(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();

        genericLinkedList.add(1);
        genericLinkedList.add(2);

        assertEquals(
                2,
                genericLinkedList.size()
        );

        genericLinkedList.add(3);

        assertEquals(
                3,
                genericLinkedList.get(2)
        );
    }

    @Test
    public void testGetNodeByIndex(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();

        genericLinkedList.add(1);
        genericLinkedList.add(2);
        genericLinkedList.add(3);

        GenericLinkedList.Node node = ((GenericLinkedList<?>) genericLinkedList).getNodeByIndex(1);

        assertEquals(
                Integer.valueOf(2),
                node.getValue()

        );
    }

    @Test
    public void ttAdd(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();
        genericLinkedList.add(1);
        genericLinkedList.add(2);
        genericLinkedList.add(3);

        genericLinkedList.add(3,55);

        assertEquals(
                55,
                genericLinkedList.get(3)
        );
    }

    @Test
    public void testRemove(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();

        genericLinkedList.add(1);
        genericLinkedList.add(2);
        genericLinkedList.add(3);

        genericLinkedList.remove(2);

        assertEquals(2,
                genericLinkedList.size()
        );
    }

    @Test
    public void testGet(){
        GenericLinkedList genericLinkedList = new GenericLinkedList();
        genericLinkedList.add(1);
        genericLinkedList.add(2);
        genericLinkedList.add(3);

        assertEquals(
                1,
                genericLinkedList.get(0)
        );
    }




}
