package lesson19;

import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lesson19 {
    public static void main(String[] args) {

        //https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html

        List<Integer> years = Arrays.asList(2000, 2022, 2021, 2027);
        // поток не запустится пока к нему не присоединена терминальная операция
        Stream<Integer> yearsStream = years.stream()
                .filter(y -> y % 2 == 0) // промежуточная операция
                .filter(y -> y > 2010); // промежуточная операция

        yearsStream.forEach(// терминальная операция
                System.out::println
        );

        String [] names = {"Alexander", "Max", "Xenia", "Maria"};

        Arrays.stream(names)
                // отфильтруйте только те что содержат x или X - filter
                .filter(s -> s.toUpperCase().contains("X"))
                // переведите имена в верхний регистр - map
                .map(s -> s.toUpperCase())
                // распечатайте - forEach
                .forEach(System.out::println);

        // IntStream.range(1,5) // 1,2,3,4
        // IntStream.rangeClosed(1,5) // 1,2,3,4,5


        DoubleStream.generate(
                        () -> new Random().nextDouble()
                )
                .limit(10)
                .forEach(System.out::println);

        IntStream.rangeClosed(1, 10)
                .limit(5) // берет первые n элементов потока, отбрасывая остальные
                .skip(2) // отбрасывает первые n элементов потока
                .forEach(System.out::println);


        // names
        // преобразуйте "имя" -> "имя:3"
        // распечатайте
        // до 20:00
        Arrays.stream(names)
                .map(string -> string + ":" + string.length())
                .forEach(System.out::println);

        System.out.println(
                Arrays.stream(names)
                        .map(s -> s + ":" + s.length())
                        .count() // количество элементов в потоке
        );

        Arrays.stream(names)
                .map(s -> s + ":" + s.length())
                .sorted()//сортирует элементы потока
                .forEach(System.out::println);

        Stream.of(1,10, 20, 20, 0, 10)
                .distinct()// пропустит только неповторяющийся элементы
                .forEach(System.out::println);

        // peek - позволяет заглянуть в поток
        Arrays.stream(names)
                .peek(s -> System.out.println(s.length()))
                .forEach(System.out::println);

        System.out.println(Arrays.stream(names)
                .noneMatch(string -> string.contains("y")));

        System.out.println(Arrays.stream(names)
                .allMatch(string -> string.contains("a")));

        int[] numbers = {2, 4, 5, 8, 3};

        System.out.println(
                Arrays.stream(numbers)
                        .reduce(0, new IntBinaryOperator() {
                            @Override
                            public int applyAsInt(int prev, int current) {
                                return prev + current;
                            }
                        })
        );

        System.out.println(Arrays.stream(numbers)
                .reduce(1, (prev, current) -> prev * current)

        );

        // превратите
        // names в "Alexander, Max, Xenia, Maria"
        System.out.println(
                Arrays.stream(names)
                        .reduce(new BinaryOperator<String>() {
                            @Override
                            public String apply(String s1, String s2) {
                                return s1 + ", " + s2;
                            }
                        })
                        .orElse("")
        );

        // Optional<T> - может быть значение, но может и не быть значения



        System.out.println(
                years.stream()
                        .filter(y -> y > 10_000)
                        .findFirst() // возвратить первый элемент
        );

        // min / max
        System.out.println(
                Arrays.stream(names)
                        .max(Comparator.naturalOrder()) // компаратор построенный на Comparable
        );

        // верните самое длинное имя
        System.out.println(
                Arrays.stream(names)
                        .max(Comparator.comparingInt(String::length))
                        .orElse("")
        );

        // Collect
        Set<String> namesSet =
                Arrays.stream(names)
                        .collect(Collectors.toSet());

//        Arrays.stream(names)
//                .collect(
//                        Collectors.toCollection(new Supplier<Collection<String>>() {
//                            @Override
//                            public Collection<String> get() {
//                                return new ArrayList<>();
//                            }
//                        })
//                );

        Arrays.stream(names)
                .collect(
                        Collectors.toCollection(ArrayList::new)
                );

        String namesCombined =
                Arrays.stream(names)
                        .collect(
                                Collectors.joining(", ")
                        );

        System.out.println(namesCombined);

        // groupingBy - возможность сгруппировать элементы в Map
        // с помощью функции вычисления ключа
        // <T> -> Map<K, List<T>>

        // Alexander  Max  Xenia  Maria
        System.out.println(
                Arrays.stream(names)
                        .collect(
                                Collectors.groupingBy(
                                        String::length
                                )
                        )
        );

        // Collectors toMap
//        System.out.println(
//                Arrays.stream(names)
//                        .collect(
//                                Collectors.toMap(
//                                        new Function<String, String>() {
//
//                                            @Override
//                                            public String apply(String s) {
//                                                return s;
//                                            }
//                                        }, new Function<String, Integer>() {
//                                            @Override
//                                            public Integer apply(String s) {
//                                                return s.length();
//                                            }
//                                        }
//                                )
//                        )
//        );

        // Collectors toMap
        System.out.println(
                Arrays.stream(names)
                        .collect(
                                Collectors.toMap(
                                        s -> s, // Function.identity(),
                                        String::length
                                )
                        )
        );







    }
}
