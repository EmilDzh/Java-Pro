package lesson19.hw;

import lesson19.Employee;

import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Hw {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee("Max Petrov", 22, "programmer"),
                new Employee("Ivan Shapovalov", 33, "analyst"),
                new Employee("Semen Deznev", 55, "manager"),
                new Employee("Oleg Petrov", 19, "intern"),
                new Employee("Katerina Drogova", 31, "programmer"),
                new Employee("Nicolas Spivakov", 23, "analyst"),
                new Employee("Boris Moiseev", 48, "manager"),
                new Employee("Petr Sveshnikov", 37, "programmer"),
                new Employee("Alex Con", 33, "analyst"),
                new Employee("Olga Filimonova", 27, "programmer")
        );

        //1. распечатайте фамилии всех женщин - оканчивающиеся на "a" (Filimonova , Drogova)
        employees.stream()
                .filter(e -> e.getName().endsWith("a"))
                .forEach(System.out::println);

        //распечатайте только имена всех работников - имя это то, что до пробела

        employees.stream()
                .map(e -> e.getName().split(" "))
                .map(s -> s[0])
                .forEach(System.out::println);


        //найдите средний возраст
        System.out.println(
                employees.stream()
                        .mapToInt(e -> e.getAge())
                        .average()
                        .orElse(0)
        );

        //посчитайте количество программистов мужчин (name не оканчивается на "a")

        // посчитайте количество программистов мужчин (name не оканчивается на "a")
        //        System.out.println("=== number of men programmers ===");
        //        System.out.println(
        //                employees.stream()
        //                        .filter(e -> e.getPosition().equals("programmer"))
        //                        .filter(e -> !e.getName().endsWith("a"))
        //                        .count()
        //        );

        System.out.println(employees.stream()
                .filter(e -> !e.getName().endsWith("a"))
                .count()
        );

        //посчитайте сумму возрастов работников
        System.out.println(employees.stream()
                .map(e -> e.getAge())
                .reduce(0, (i1, i2) -> i1 + i2)
        );

        //разделите всех работников на 2 группы - старше 40 лет (true) и младше 40 лет (false)
        // разделите всех работников на 2 группы - старше 40 лет (true) и младше 40 лет (false)
//        System.out.println("=== age > 40 ===");
//        System.out.println(
//                employees.stream()
//                        // .collect(Collectors.partitioningBy(e -> e.getAge() > 40))//TODO может быть только 2 ключа в мапе
//                        .collect(Collectors.groupingBy(e -> e.getAge() > 40)) // TODO неограниченная количество ключов в мапе
//        );

        employees.stream()
                .filter(e -> e.getAge() > 40)
                .map(e -> e.getAge() + " true ")
                .collect(Collectors.toList())
                .forEach(System.out::println);

        employees.stream()
                .filter(e -> e.getAge() < 40)
                .map(e -> e.getAge() + " false ")
                .collect(Collectors.toList())
                .forEach(System.out::println);

      //найдите профессию самого старшего из "молодых" - тех кому <= 40 лет
//        // найдите профессию самого старшего из "молодых" - тех кому <= 40 лет
//        System.out.println("=== profession ===");
//        employees.stream()
//                .collect(Collectors.groupingBy(e -> e.getAge() > 40))
//                .entrySet().stream()
//                .filter(pair -> !pair.getKey())
//                .flatMap(pair -> pair.getValue().stream())
//                .max(Comparator.comparing(Employee::getAge))
//                .ifPresent(e -> System.out.println(e.getPosition()));
        System.out.println(employees.stream()
                .filter(e -> e.getAge() <= 40)
                .max((e1, e2) -> Integer.compare(e1.getAge(), e2.getAge()))
                .map(e -> e.getPosition())
                .orElse(null)
        );

        //сгруппируйте всех работников по профессии

        // сгруппируйте всех работников по професии
        //        System.out.println("=== profession grouping ===");
        //        System.out.println(
        //                employees.stream()
        //                        .collect(Collectors.groupingBy(e -> e.getPosition()))
        //        );

        System.out.println(
                employees.stream()
                        .collect(Collectors.groupingBy(e -> e.getPosition()))
                        .entrySet().stream()
                        .map(pair -> new AbstractMap.SimpleEntry<>(
                                pair.getKey(),
                                pair.getValue().stream()
                                        .map(e -> e.getName())
                                .collect(Collectors.toList())))
                        .collect(Collectors.toMap(
                                        pair -> pair.getKey(),
                                        pair -> pair.getValue() //String.join
                                )
                        ));

        //посчитаем количество людей в профессии

        // посчитаем количество людей в профессии
        //        System.out.println("=== number of people in position ===");
        //        System.out.println(
        //                employees.stream()
        //                        .collect(Collectors.groupingBy(e -> e.getPosition()))
        //                        .entrySet().stream()
        //                        .collect(
        //                                Collectors.toMap(
        //                                        pair -> pair.getKey(),
        //                                        pair -> pair.getValue().size()
        //                                )
        //                        )
        //        );

        //System.out.println(
        //                employees.stream()
        //                        .collect(Collectors.groupingBy(
        //                                Employee::getPosition,
        //                                Collectors.counting()
        //                        ))
        //        );

        System.out.println(
                employees.stream()
                        .collect(Collectors.groupingBy(e -> e.getPosition()))
                        .entrySet().stream()
                        .map(pair -> new AbstractMap.SimpleEntry<>(pair.getKey(), pair.getValue().stream().map(e -> e.getName())
                                .collect(Collectors.toList())))
                        .collect(Collectors.toMap(
                                        pair -> pair.getKey(),
                                        pair -> pair.getValue().size() //String.join
                                )
                        ));

        //Вернуть средний возраст мужчин и женщин - у женщин фамилия оканчивается на "a" -
        //в виде Map - ключ "true" соответствует женщинам

        employees.stream()
                .collect(Collectors.partitioningBy(
                        e -> e.getName().endsWith("a"),
                        Collectors.averagingInt(e -> e.getAge())
                ))
                .forEach(new BiConsumer<Boolean, Double>() {
                    @Override
                    public void accept(Boolean isFemale, Double averageAge) {
                        if (isFemale) {
                            System.out.println("Средний возраст женщин: " + averageAge);
                        } else {
                            System.out.println("Средний возраст мужчин: " + averageAge);
                        }
                    }
                });

        //Распечатать работников с самым часто встречающимся возрастом
        System.out.println(
                employees.stream()
                .collect(Collectors.groupingBy(e -> e.getAge()))
                .entrySet().stream()
                .max(new Comparator<Map.Entry<Integer, List<Employee>>>() {
                    @Override
                    public int compare(Map.Entry<Integer, List<Employee>> o1, Map.Entry<Integer, List<Employee>> o2) {
                        return Integer.compare(o1.getValue().size(), o2.getValue().size());
                    }
                })
                .orElse(null)

        );
        //// Распечатать работников с самым часто встречающимся возрастом
        //        System.out.println("=== most common age ===");
        //        employees.stream()
        //                .collect(Collectors.groupingBy(e -> e.getAge()))
        //                .entrySet().stream()
        //                .max((e1, e2) -> Integer.compare(e1.getValue().size(), e2.getValue().size()))
        //                .map(pair -> pair.getValue())
        //                .ifPresent(l -> System.out.println(l));


    }


}
