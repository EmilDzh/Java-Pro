package lesson19;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EmpTester {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee("Max Petrov", 22, "programmer"),
                new Employee("Ivan Shapovalov", 33, "analyst"),
                new Employee("Semen Deznev", 55, "manager"),
                new Employee("Oleg Petrov", 19, "intern"),
                new Employee("Katerina Drogova", 31, "programmer"),
                new Employee("Nicolas Spivakov", 23, "analyst"),
                new Employee("Boris Moiseev", 48, "manager"),
                new Employee("Petr Sveshnikov", 37, "programmer"),
                new Employee("Alex Con", 33, "analyst"),
                new Employee("Olga Filimonova", 27, "programmer")
        );

        System.out.println( employees.stream()
                .min(Comparator.comparingInt(Employee::getAge))
                //.orElse(null)
               // .ifPresent(System.out::println);
        );

        // посчитайте количество различных позиций
        System.out.println(
                employees.stream()
                        .map(Employee::getPosition)
                        .distinct()
                        .count()
        );

        // распечатайте фамилии всех женщин - оканчивающиеся на "a" (Filimonova , Drogova)
        // отфильтровать записи с именем на a
        // замапить в name
        // разбить по пробелу
        // вернуть вторую часть
        // до 21:48

//        employees.stream()
//                .filter(new Predicate<Employee>() {
//                    @Override
//                    public boolean test(Employee employee) {
//                        return employee.getName().endsWith("a");
//                    }
//                })
//                .map(new Function<Employee, String[]>() {
//                    @Override
//                    public String[] apply(Employee employee) {
//                        return employee.getName().split(" ");
//                    }
//                })
//                .forEach(new Consumer<String[]>() {
//                    @Override
//                    public void accept(String[] strings) {
//                        System.out.println(strings[1]);
//                    }
//                });

        // распечатайте фамилии всех женщин - оканчивающиеся на "a" (Filimonova , Drogova)
        employees.stream()
                // отфильтровать записи с именем на a
                .filter(e -> e.getName().endsWith("a"))
                // замапить в name
                .map(e -> e.getName())
                // замапить в массив разбив по пробелу
                .map(n -> n.split(" "))
                // "".split(" ")
                // замапить во "второй" элемент массива
                .map(a -> a[1])
                .forEach(System.out::println);










    }
}
