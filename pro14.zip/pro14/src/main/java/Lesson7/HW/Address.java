package Lesson7.HW;



public class Address   {
    public String street;
    public int houseN;


    public Address(String street, int houseN) {
        this.street = street;
        this.houseN = houseN;
    }

    public String getStreet() {
        return street;
    }

    public int getHouseN() {
        return houseN;
    }



}
