package Lesson7.HW;

import lesson6.list.MyArrayList;

import java.util.*;

public class Hw050723 {




    public static void main(String[] args) {


        //Есть два класса : Address с полями улица и номер дома и Persons  с полями name и address.
        //Напишите метод List
        // getAddresses(List persons)
        //то есть по списку persons возвращать список их адресов


        List<Persons> persons = new ArrayList<>();
        persons.add(new Persons("Thorin", new Address("Morii", 15)));
        persons.add(new Persons("Bilbo B", new Address("Zasumki", 2)));
        persons.add(new Persons("Frodo B", new Address("Zasumki", 2)));

        System.out.println(getAddresses(persons));

        //Есть два списка одинаковой длины с числами.
        //Напишите метод, возвращающий список с элементами Yes или No
        //где значение на і-том месте зависит от того, равны ли элементы двух списков под номером і  -
        //например, {1,2,3,4,12} и {5,2,3,3,0}->{"No", "Yes", "Yes", "No", "No"}

        List<Integer> l1 = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 12));
        List<Integer> l2 = new ArrayList<>(Arrays.asList(5, 2, 3, 3, 0));
        System.out.println(checkElements(l1, l2));

        //Напишите функцию, меняющую порядок следования элементов в списке на противоположный -
        //например, {1,2,3} -> {3,2,1}

        List<Integer> i1 = new ArrayList<>(Arrays.asList(1, 2, 3));
        reserveList(i1);
        System.out.println(i1);

        //Напишите функцию, возвращающую второй по величине элемент списка целых -
        //например, {1,3,4,2} -> 3

        List<Integer> integers = new ArrayList<>(Arrays.asList(1, 3, 4, 2));
        System.out.println(backValue(integers) );

        //Добавить в MyArrayList/MyList функцию для получения итератора,
        // обходящего список в обратном порядке - от последнего элемента к первому


        MyArrayList myList = new MyArrayList();
        myList.add(1);
        myList.add(2);
        myList.add(3);
        myList.add(4);
        myList.add(8);

        Iterator<Integer> reserve = myList.reserveIterator();
        while (reserve.hasNext()){
            System.out.println(reserve.next());
        }

        // Добавить в MyArrayList/MyList функцию для получения итератора,
        // обходящего элементы списка по возрастанию их значений, от меньшего к большему

        MyArrayList myList1 = new MyArrayList();
        myList1.add(66);
        myList1.add(199);
        myList1.add(68);
        myList1.add(1);
        myList1.add(3);
        myList1.add(5);

        Iterator<Integer> ascendingIt = myList1.ascendingIterator();
        while (ascendingIt.hasNext()){
            System.out.println(ascendingIt.next());
        }




    } //edge

    public static List<String> getAddresses(List<Persons> persons) {
        List<String> addresses = new ArrayList<>();
        for (Persons person : persons) {
            addresses.add(person.getAddress().getStreet() + " " + person.getAddress().getHouseN());

        }
        return addresses;

    }

    public static List<String> checkElements(List<Integer> i1, List<Integer> i2) {
        List<String> gg = new ArrayList<>();
        for (int i = 0; i < i1.size(); i++) {
            if (i1.get(i).equals(i2.get(i))) {
                gg.add("Yes");
            } else
                gg.add("No");
        }


        return gg;
    }


    ////     Напишите функцию, меняющую порядок следования элементов в списке на противоположный -
    //    //например, {1,2,3} -> {3,2,1}
    //    public static void reverse(List<Integer> a)
    //    {   // 0 1 2 i: a.size() - 1 - i
    //        // 1 2 3
    //        for(int i = 0; i < a.size() / 2 ; i++)
    //        {
    //            int temp = a.get(i);
    //            a.set(i, a.get(a.size() - 1 - i));
    //            a.set(a.size() - 1 - i, temp);
    //        }
    //    }

    //// List<Integer> a = new ArrayList<>(Arrays.asList(1,2,3));
    //        List<Integer> a = Arrays.asList(1,2,3); // Read-only list - нельзя менять количество элементов
    //        System.out.println("before: " + a);
    //        reverse(a);
    //        System.out.println("after: " + a);
    public static void reserveList(List<Integer> i1) {
        int start = 0;
        int end = i1.size() - 1;

        while (start < end) {
            int temp = i1.get(start);
            i1.set(start, i1.get(end));
            i1.set(end, temp);
            start++;
            end--;

        }
    }

    ////     Напишите функцию, возвращающую второй по величине элемент списка целых -
    //    //например, {1,3,4,2} -> 3
    //    public static int findSecondMax(List<Integer> a)
    //    {
    //        Collections.sort(a); // сортируем
    //        int last = a.get(a.size() - 1); // значение максимума
    //        a.removeAll(Arrays.asList(last)); // удаляем все такие элементы
    //        return a.get(a.size() - 1); // возвращаем последний
    //    }

    public static int backValue(List<Integer> list) {
        Collections.sort(list);
        return list.get(list.size() - 2);
    }

    //public static Integer findSecondLargest(List<Integer> list) {
    //
    //
    //        Integer largest = null;
    //        Integer secondLargest = null;
    //
    //        for (Integer num : list) {
    //            if (largest == null || num > largest) {
    //                secondLargest = largest;
    //                largest = num;
    //            } else if (secondLargest == null || (num > secondLargest && num < largest)) {
    //                secondLargest = num;
    //            }
    //        }
    //
    //        return secondLargest;
    //    }

}



