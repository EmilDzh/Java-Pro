package lesson32.counter;

public interface Counter extends Runnable {
    int getValue();
}
