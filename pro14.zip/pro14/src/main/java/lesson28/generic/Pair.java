package lesson28.generic;

public interface Pair <K,V> {
    K first();
    V second();
}
