package lesson28.generic;

//https://docs.oracle.com/javase/8/docs/api/java/lang/Number.html

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class GenericTester {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("Misha");
        // names.add(4);

        List something = new ArrayList(); // Object
        something.add("Misha");
        something.add(123);
        String name = (String) something.get(0);
        // String anotherName = (String) something.get(1);
        debug(name);
        debug(123);
        log(name);
        log(123);

        String[] countries = {"Cuba", "Venezuela", "Salvador, Albania"};
        System.out.println(firstElement(countries));

        System.out.println(Arrays.toString(countries));
        swap(countries, 1, 2);
        System.out.println(Arrays.toString(countries));

        Pair<String, Integer> masha = new PairImpl<>("Masha", 24);
        Pair<String, Integer> masha1 = new PairImpl<>("Masha", 24);

        System.out.println(firstAndLast(countries));
        System.out.println(fromArrayToList(countries));
        System.out.println(
                fromArrayToList(
                        countries,
                        s -> s.contains("l"),
                        s -> s.toUpperCase()
                )
        );

        System.out.println(equals(masha, masha1));
        List<String> something1 = new ArrayList<>();
        something1.add("Michael");
        something1.add("Eminem");
        something1.add("Elvis");
        something1.add("Selena");

        List<String> filteredList = filter(
                something1,
                s -> s.startsWith("E")
        );

        System.out.println(filteredList);

        Double [] numbers = {1.0, 4.33, -12.3, 34.2};
        System.out.println(
                fromNumberToList(numbers, 19.2)
        );


    }//main

    // хотелось бы чтобы в функцию можно было бы передать не все типы/классы
    // а только некоторые
    // Integer, Float, Double ... потомки Number
    public static <T extends Number & Comparable<T>> List<T> fromNumberToList(T [] array, T bound)
    {
        return Arrays.stream(array)
                .filter(n -> n.compareTo(bound) > 0)
                .peek(n -> System.out.println("number: " + n.doubleValue()))
                .collect(Collectors.toList());
    }

    // хотелось бы чтобы в функцию можно было бы передать не все типы/классы
    // а только некоторые
    // Integer, Float, Double ... потомки Number
    public static <T extends Number> List<T> fromNumberTOList(T [] array)
    {
        return Arrays.stream(array)
                .peek(n -> System.out.println("number: " + n.doubleValue()))
                .collect(Collectors.toList());
    }

    //1. Напишите в классе GenericTester функцию equals, которая сравнит две пары.
    //Пары равны если равны оба их элемента

    public static boolean equals(Pair p1, Pair p2) {
        if (p1.first().equals(p2.first()) && p1.second().equals(p2.second())) {
            return true;
        } else {
            return false;
        }

    }

    //Напишите в классе GenericTester функцию filter,
    // которая принимает список любого типа и предикат
    // и возвращает список только из тех элементов, которые предикату соответствуют.
    public static <T> List<T> filter(List<T> t, Predicate<T> p){

        return t.stream()
                .filter(p)
                .collect(Collectors.toList());

    }

    public static <T, R> List<R> fromArrayToList(
            T[] a,
            Predicate<T> predicate,
            Function<T, R> mapper
    )
    {
        return Arrays.stream(a)
                .filter(predicate)
                .map(mapper)
                .collect(Collectors.toList());
    }

    // напишите шаблоную функцию, которая преобразует массив чего угодно в
    // список
    public static <T> List<T> fromArrayToList(T[] a) {

        // до 21:47
        return Arrays.stream(a)
                .collect(Collectors.toList());
    }

    // напишите функцию которая принимает на вход массив чего угодно и возвращает
    // пару из первого и последнего элемента
    public static <T> Pair<T, T> firstAndLast(T[] a) {
        return new PairImpl<>(a[0], a[a.length - 1]);
    }

    // напишите функцию swap которая принимает на вход массив чего угодно
    // и два номера
    // внутри массива обменивает элементы по этим номерам
    public static <T> void swap(T[] s, int i, int j) {
        T temp = s[i];
        s[i] = s[j];
        s[j] = temp;
        // до 21:24
    }


    // напишите шаблонную функцию которая принимает на вход массив чего угодно
    // и возвращает первый элемент этого массива
    public static <T> T firstElement(T[] t) {
        return t[0];
        // до 21:14
    }


    // Generic == Шаблон
    // T - типовой параметр
    public static <T> void log(T t) // t - значение, T - тип
    {
        System.out.println("It's a " + t.getClass().getSimpleName() + ", value is: " + t);
    }

    public static void debug(int i) {
        System.out.println("It's a int, value is: " + i);
    }

    public static void debug(String s) {
        System.out.println("It's a String, value is: " + s);
    }
}
