package lesson28.exceptions;

public class ExceptionTester {
    public static void main(String[] args) {
        solution(0);
        solution(2);
        System.out.println("hello, world!");
    }
    public static void solution(int n)
    {
        // запустите
        // добавьте обработчик исключений
        // перехватывайте и распечатывайте все полученные исключения
        // до 20:23
        try {
            int x = 10/n;
            int [] array = new int [n];
            array[x] = 10;
        } catch (ArithmeticException  | ArrayIndexOutOfBoundsException e){
            System.err.println("Exception is: " + e.getMessage());
        }


    }
}
