package lesson35.translate;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class TranslationTest {
    public static void main(String[] args) {
        /*
        System.out.println(
                TranslateLibrary.translate("привет мир", "ru-en")
        );

         */
        // напишите вызов двух переводов
        // один с русского на английский
        // и результат переведите с английского на французский
        CompletableFuture<String> request = CompletableFuture.supplyAsync(
                        () -> TranslateLibrary.translate("привет, как дела", "ru-en")
                )
                .thenApply(
                        s -> TranslateLibrary.translate(s, "en-fr")
                );

        try {
            System.out.println(request.get());
        } catch (Exception e)
        {
            System.err.println(e.getMessage());
        }


        System.exit(0);
    }
}
