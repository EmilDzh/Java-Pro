package lesson35.translate;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class ParallelTranslate {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<String> future = CompletableFuture.supplyAsync(
                () -> TranslateLibrary.translate("привет как дела","ru-en")
        );

        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(
                () -> {
                    try {
                        return TranslateLibrary.translate(future.get(), "en-fr");
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    } catch (ExecutionException e) {
                        throw new RuntimeException(e);
                    }
                }
        );

        CompletableFuture<Void> combine = CompletableFuture.allOf(future,future2);

        combine.get();

        System.out.println(future.get() + " " + future2.get());
    }
}
/*
import java.util.concurrent.CompletableFuture;

public class ParallelTranslate {
    public static void main(String[] args) {
        // параллельно выполните перевод любой фразы
        // с русского на английский и
        // с русского на французский
        // и распечатайте результаты через тире
        // английский результат - французский результат
        CompletableFuture<String> en = CompletableFuture.supplyAsync(
                () -> TranslateLibrary.translate("привет злобный мир", "ru-en")
        );

       CompletableFuture<String> fr = CompletableFuture.supplyAsync(
                () -> TranslateLibrary.translate("hello", "en-fr")
        );

        CompletableFuture<Void> work = CompletableFuture.allOf(en,fr);

        try {
            work.get();
            System.out.println(en.get() + "-" + fr.get());
        } catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
        System.exit(0);
    }
}
* */
