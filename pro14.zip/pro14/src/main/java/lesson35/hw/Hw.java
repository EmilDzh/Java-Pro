package lesson35.hw;

import lesson14.retro.FrankfurterService;
import lesson14.retro.Rate;
import lesson2.crossword.C;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

public class Hw {
    public static void main(String[] args) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.frankfurter.app")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        FrankfurterService service = retrofit.create(FrankfurterService.class);

        Call<Rate> call = service.convert(10, "EUR", "GBP");


        CompletableFuture<Rate> future = CompletableFuture.supplyAsync(
                new Supplier<Rate>() {
                    @Override
                    public Rate get() {
                        Call<Rate> call = service.convert(10, "EUR", "GBP");
                        Response<Rate> response = null;
                        try {
                            response = call.execute();
                        } catch (IOException e) {
                            System.err.println(e.getMessage());
                        }
                        Rate rate = response.body();
                        return rate;
                    }

                    ;
                }
        );

        try {
            System.out.println(future.get().rates);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        CompletableFuture<Rate> future2 = CompletableFuture.supplyAsync(
                new Supplier<Rate>() {
                    @Override
                    public Rate get() {
                        try {
                            return service.convert(future.get().rates.get("GBP"), "GBP", "USD").execute().body();
                        } catch (Exception e) {
                            System.err.println(e.getMessage());
                        }
                        return null;
                    }
                }
        );

        try {
            System.out.println(future2.get().rates);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        System.exit(0);

        //public class Converter {
        //    public static double convert(double amount, String from, String to) {
        //        FrankfurterService service = new Retrofit.Builder()
        //                .baseUrl("https://api.frankfurter.app")
        //                .addConverterFactory(GsonConverterFactory.create())
        //                .build()
        //                .create(FrankfurterService.class);
        //        try {
        //            return service.convert(amount, from, to).execute().body().rates.get(to);
        //        } catch (Exception e) {
        //            // если функция выбрасывает CheckedException, то имеет смысл перхватить его
        //            // и выбросить занового как не CheckedException
        //            throw new RuntimeException(e);
        //        }
        //    }
        //}

        /*
       import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/*
И вызовите последовательно перевод 10 евро ("EUR") в фунты ("GBP")
и потом для полученной суммы вызовите перевод из фунтов в доллары ("USD")
воспользовавшись CompletableFuture
Распечатайте результат.

     public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<String> converter = CompletableFuture.supplyAsync(
                // суфикс Async значит что этот CF будет выполнятся
                // на пуле потоков
                // если не указать то это будет ForkJoin
                () -> Converter.convert(10.0, "EUR", "GBP")
        )
                .thenApply(
                        // все методы без Async запускаются в потоке в котором
                        // выполняется .get()
                        money -> Converter.convert(money, "GBP", "USD")
                )
                .handle(
                        (result, error) -> error != null ? error.getMessage() : "" + result
                )
                ;
        // цепочка запускается только после вызова get
        System.out.println(converter.get());
    }
         */


    }
}
