package lesson31.hw;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class HwThreads {
    public static void main(String[] args) {

        Callable callable = HwThreads::waitSomeTime;

        FutureTask<Integer> task = new FutureTask<Integer>(callable);

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        t1.start();
        t2.start();

        try {
            System.out.println(task.get() + task.get());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }

    }
    // Создайте функцию, ожидающую рандомное время от 0 до 1000 мс и возвращающую
    // это время в качестве результата

        public static int waitSomeTime() {
           Random r = new Random();
            int pause = r.nextInt(1000);
            try {
                Thread.sleep(pause);
            } catch (InterruptedException e) {
                //
           }
            return pause;
        }
}
