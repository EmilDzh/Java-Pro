package lesson31.hw;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Hw {

    private static int data = 0;
    private static int data1 = 0;
    public static void main(String[] args) {

        //Создайте LocalDateTime с какой-нибудь датой, например с днем рождения
        //Воспользуйтесь DateTimeFormatter чтобы вывести эту дату в виде
        //01 January 1970, Thursday
        //Выведите то-же самое, но по-французски
        //01 janvier 1970, jeudi

        LocalDate date = LocalDate.of(1999,6,11);
        System.out.println(
                date.format(
                        DateTimeFormatter.ofPattern("yyyy-MM-dd EEEE")
                )
        );

        LocalDateTime d1 = LocalDateTime.of(1999, Month.JUNE,11,00,00);
        System.out.println(
                d1.format(
                        DateTimeFormatter.ofPattern("dd MMMM yyyy, EEEE")
                )
        );

        LocalDateTime d2 = LocalDateTime.of(1999, Month.JUNE,11,00,00);
        System.out.println(
                d2.format(
                        DateTimeFormatter.ofPattern("dd MMMM yyyy, EEEE", Locale.FRANCE)
                )
        );

        //Создайте Instant из строки "2023-07-13T19:34:00.00Z"
        //Переведите этот момент времени во временную зону "Pacific/Honolulu" и распечатайте

        ZonedDateTime z1 = ZonedDateTime.parse("2023-07-13T19:34:00.00Z[Pacific/Honolulu]");
        System.out.println(z1);

        Thread t1 = new Thread(){
            @Override
            public void run() {
                data += waitt();
            }
        };

        Thread t2 = new Thread(){
            @Override
            public void run() {
                data1 += waitt();
            }
        };

        t1.start();
        t2.start();
        try {
            t1.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            t2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(
                "Общая сумма равна: " +
                data + data1
        );


    } // main

    //1. Напишите шаблонную функцию, которая принимает на вход список и varargs из целых.
//Нужно вернуть коллекцию из элементов, номера которых и передаются в виде varargs
//public static  Collection getElements(List list, int … elements)

    public static <T> Collection<T> getElements(List<T> list, int... elements){

        List<T> collection = new ArrayList<>();

        for (int element : elements){
            if (element >= 0 && element <= list.size()){
                collection.add(list.get(element));
            }
        }
        return collection;
    }

    // Создайте функцию, ожидающую рандомное время от 0 до 1000 мс и возвращающую это время в качестве результата public int wait()
    //
    //
    //Запустите эту функцию в двух потоках, в их методе run сохраните результат выполнения этой функции в статические переменные класса.
    //В main запустите потоки и распечатайте сумму значений этих статических переменных.

    public static int waitt(){
        Random rnd = new Random();
        int randomTime = rnd.nextInt(1001);
        try {
            Thread.sleep(randomTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e.getMessage());
        }

        return randomTime;
    }

}




