package lesson31;
import java.util.Random;
import java.util.concurrent.*;

//https://drive.google.com/drive/folders/1atE_fIrHPz-CArNlLK_RaPaL2RXGRy5b

/*
    пул потоков - набор потоков, thread pool
        набор из потоков выполнения + очередь задач для выполнения
        задания в очереди это либо Runnable либо Callable
 */
public class ThreadPoolTester {
    public static void main(String[] args) {
        ExecutorService service = Executors.newFixedThreadPool(2); // 2 потока выполнения в пуле
        Runnable r = new Work();
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);
        service.submit(r);

        // Создаем экземпляр Callable
        Job callable = new Job();

        // Future - будущий результат
        Future<String> result = service.submit(callable);

        // Future<>.get() блокирует поток в котором выполняется
//        try {
//            System.out.println(result.get());
//        } catch (Exception e) {
//            System.out.println("Exception: " + e.getMessage());
//        }
        if(result.isDone()) {
            // можем результат запросить, он готов
            System.out.println("Future result is ready");
        } else {
            System.out.println("Future result is not ready, can do something else");
        }

        service.shutdown(); // дожидается выполнения всех задач в очереди
        // service.shutdownNow(); // не дожидается выполнения всех заданий в очереди
    }

    public static class Work implements Runnable {
        @Override
        public void run() { // Runnable ничего не возвращает
            Random r = new Random();
            try {
                Thread.sleep(r.nextInt(500));
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("Thread with id: " + Thread.currentThread().getId());
        }
    }

    // Callable - задача, которая возвращает результат
    public static class Job implements Callable<String> {

        @Override
        public String call() throws Exception {
            Thread.sleep(500);
            return "" + System.currentTimeMillis();
        }
    }

}
