package lesson31;

public class Practice {
    public static void main(String[] args) {
        // создайте и запустите поток,
        // который выполнит function1 и распечатает результат
        Thread t1 = new Thread(() -> System.out.println(function1()));
        t1.start();

        Thread t2 = new MyThread("hello");
        t2.start();

        // создайте Thread который в run выполняет function1
        // и потом запускает MyThread передав в качестве параметра
        // результат function1
        // до 21:18

        Thread thread = new Thread(){
            @Override
            public void run(){
                String f1 = function1();
                MyThread myThread = new MyThread(function2(f1));
                myThread.start();

                //new MyThread(f1).start();
            }
        };
        thread.start();




    }

    // напишите статический класс который расширяет Thread и в
    // конструкторе принимает на вход строку
    // принимаемую строку использует в run для того чтобы вызвать с ней function2
    // результат вызова function2 нужно распечатать
    public static class MyThread extends Thread {
        private String text;

        public MyThread(String text) {
            this.text = text;
        }

        @Override
        public void run() {
            System.out.println(
                    function2(text)
            );
        }
    }


    public static String function1()
    {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return "" + Thread.currentThread().getId() + ":" + System.currentTimeMillis();
    }

    public static String function2(String text)
    {
        try {
            Thread.sleep(1_000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return text + "|" + Thread.currentThread().getId() + ":" + System.currentTimeMillis();
    }
}
