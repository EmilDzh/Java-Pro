package lesson20;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lesson20 {
    public static void main(String[] args) {
        // Java Streams: Flat map.
        // filter n -> 0..n
        // map n -> n
        // flatMap n -> m

        Integer [] [] twoDimensionalArray = {
                {1,2,3},
                {5,6,8,10},
                {11},
                {14,12}
        };

        Arrays.stream(twoDimensionalArray)
                .forEach(array -> System.out.println(Arrays.toString(array)));

        System.out.println("flatMap");
        Arrays.stream(twoDimensionalArray)
                .flatMap((Function<Integer[], Stream<Integer>>) integers -> Arrays.stream(integers))
                .forEach(System.out::println);

        List<List<String>> names = Arrays.asList(
                Arrays.asList("Masha", "Alexander"),
                Arrays.asList("Semen", "Vlad", "Alice", "Xenia")
        );

//        names.stream()
//                .flatMap(new Function<List<String>, Stream<String>>() {
//
//                    @Override
//                    public Stream<String> apply(List<String> strings) {
//                        return strings.stream();
//                    }
//                })
//                .collect(Collectors.toList())
//                .forEach(System.out::println);
//        // преобразуйте в поток имен и распечатайте
//        // 19:28

        System.out.println("===names===");
        names.stream()
                .flatMap(list -> list.stream())
                .forEach(System.out::println);

        // преобразовать names в поток длин имен
        // желательно за одну операцию flatMap

//        names.stream()
//                .flatMap((Function<List<String>, Stream<Integer>>) strings -> strings.stream().map(s -> s.length()))
//                .forEach(System.out::println);

        System.out.println("===names length===");
        // преобразовать names в поток длин имен
        // желательно за одну операцию flatMap
        names.stream()
                .flatMap(list -> list.stream().map(name -> name.length()))
                .forEach(System.out::println);

        System.out.println("=== names letters====");
        // преобразуйте names в поток букв
        // M a s h a A l e x ...
        names.stream()
                .flatMap(list -> list.stream())
                // .flatMap(name -> Arrays.stream(name.toCharArray()))
                .flatMap(name -> Arrays.stream(name.split("")))
                .forEach(System.out::println);



        Order grocery = new Order(
                new OrderItem("mango", 2, 1.66),
                new OrderItem("apples", 3, 0.99),
                new OrderItem("corona", 2, 1.35)
        );

        Order utility = new Order(
                new OrderItem("water", 104, 0.30),
                new OrderItem("electricity", 201, 0.38)
        );

       List<Order> orders = Arrays.asList(grocery, utility);
//
//        System.out.println(orders.stream()
//                .flatMap((Function<Order, Stream<OrderItem>>) o -> o.getItems().stream())
//                .map(orderItem -> (int) (orderItem.getQuantity()*orderItem.getUnitPrice()))
//                .reduce(0, (integer, integer2) -> integer + integer2)
//        );

        System.out.println("===orders sum===");
        // посчитайте суммарные затраты в orders
        System.out.println(
                orders.stream()
                        .flatMap(order -> order.getItems().stream())
                        .map(item -> item.getUnitPrice() * item.getQuantity())
                        .reduce(0.0, new BinaryOperator<Double>() {
                            @Override
                            public Double apply(Double d1, Double d2) {
                                return d1 + d2;
                            }
                        })
        );

        List<Book> library = Arrays.asList(
                new Book("War and Peace", "Max", "Sveta", "Dima"),
                new Book("Movable feast", "Ernest", "George"),
                new Book("Hello to Spartans", "Dima", "Alexander", "Galina")
        );

//        library.stream()
//                .flatMap(new Function<Book, Stream<String>>() {
//
//                    @Override
//                    public Stream<String> apply(Book book) {
//                        return book.getAuthors().stream();
//                    }
//                })
//                .forEach(System.out::println);

        System.out.println("===books===");
        // распечатайте всех авторов
        library.stream()
                .flatMap(book -> book.getAuthors().stream())
                .forEach(System.out::println);

        System.out.println("    sadasfasf");

//        library.stream()
//                .flatMap(book -> book.getAuthors().stream())
//                .collect(Collectors.toCollection(TreeSet::new))
//                .forEach(System.out::println);

        // распечататайте неповторяющихся авторов в порядке возрастания имен
        System.out.println("===books distinct sorted===");
        library.stream()
                .flatMap(book -> book.getAuthors().stream())
                .distinct()
                .sorted()
                .forEach(System.out::println);

        System.out.println("===primitive===");
        int [] [] ints = {
                {1,2,3},
                {4}
        };
        System.out.println(
                Arrays.toString(
                        Arrays.stream(ints).flatMapToInt(array -> Arrays.stream(array)).toArray()
                )
        );

        System.out.println("===map===");
        // создайте на базе names
        // Map<Integer, List<String>> ключом которой была бы длина имени
        // с помощью collect
        // Collectors.groupingBy()
        // распечатайте результат

        System.out.println(
                names.stream()
                        .flatMap(list -> list.stream())
                        .collect(Collectors.groupingBy(name -> name.length()))
        );
        System.out.println("===map with count===");
        System.out.println(
                names.stream()
                        .flatMap(list -> list.stream())
                        .collect(Collectors.groupingBy(name -> name.length()))
                        .entrySet().stream() // Pair<Integer, List<String>>
                        .map(pair -> new AbstractMap.SimpleEntry<Integer, Integer>(pair.getKey(), pair.getValue().size()))
                        .collect(Collectors.toMap(
                                        pair -> pair.getKey(),
                                        pair -> pair.getValue()
                                )
                        )
                // Map<Integer, List<String>> -> Map<Integer, Integer>
        );





    }
}
