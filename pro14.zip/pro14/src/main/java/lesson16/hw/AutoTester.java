package lesson16.hw;
////3.  Есть класс автомобиль с полями марка модель цена
//// Написать метод который принимает список авто и возвращает TreeMap в котором ключами являются марки автомобилей,
//// а значениями будут списки автомобилей, отсортированные относительно цены и модели (дешевые вперед)

import java.util.*;

public class AutoTester {
    public static void main(String[] args) {
        List<Auto> autos = new ArrayList<>(Arrays.asList(
                new Auto("Mercedes", 500),
                new Auto("Mercedes - AMG", 25000),
                new Auto("BMW - X5", 20000),
                new Auto("Volkswagen - Polo", 15000),
                new Auto("Audi - A6", 7000)
        ));
//        Collections.sort(autos, Auto.autoComparator.thenComparing(Auto.autoPriesComparator));
//        System.out.println(autos);

        sortAutos(autos);
        System.out.println(autos);

        TreeMap<String, List<Auto>> sortedAutos = sortAutos(autos);

        for (Map.Entry<String, List<Auto>> entry : sortedAutos.entrySet()) {
            System.out.println("Brand: " + entry.getKey());
            for (Auto auto : entry.getValue()) {
                System.out.println(auto);
            }
            System.out.println();
        }

        String words[] = {"student", "students", "dog", "god", "cat", "act", "flow", "wolf"};
        List<List<String>> groupedAnagrams = groupAnagrams(words);

        for (List<String> group : groupedAnagrams) {
            System.out.println(group);
        }


    }//main

    public static TreeMap<String, List<Auto>> sortAutos(List<Auto> autos) {

        TreeMap<String, List<Auto>> res = new TreeMap<>();

        for (Auto auto : autos) {
            String model = auto.getModel();

            List<Auto> value = res.get(model);
            if (value == null) {
                value = new ArrayList<>();
                res.put(model, value);
            }
            value.add(auto);
        }


        for (List<Auto> autoList : res.values()) {
            autoList.sort(Auto.autoComparator.thenComparing(Auto.autoPriesComparator));
        }

        return res;
    }

    //Сгруппируйте слова с одинаковым набором символов
    //Дан список слов со строчными буквами. Реализуйте функцию поиска всех слов с одинаковым уникальным набором символов.
    //вход: String words[] = {"student", "students", "dog", "god", "cat", "act", "flow", "wolf"};
    //выход:
    //[student, students],
    //[cat, act],
    //[dog, god],
    //[flow, wolf]

 // чат в помощь((
    public static List<List<String>> groupAnagrams(String[] words) {
        Map<String, List<String>> anagram = new HashMap<>();

        for (String w : words) {
            String sortedChar = sortedChars(w);

            if (!anagram.containsKey(sortedChar)){
                anagram.put(sortedChar,new ArrayList<>());
            }
            anagram.get(sortedChar).add(w);
        }

        return new ArrayList<>(anagram.values());

    }

    private static String sortedChars(String w) {

        char[] chars = w.toCharArray();
        Arrays.sort(chars);
        return new String(chars);

    }
}

