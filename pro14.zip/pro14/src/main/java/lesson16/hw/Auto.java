package lesson16.hw;

//3.  Есть класс автомобиль с полями марка модель цена
// Написать метод который принимает список авто и возвращает TreeMap в котором ключами являются марки аатомобилей,
// а значениями будут списки автомобилей, отсортированные относительно цены и модели (дешевые вперед)

import java.util.Comparator;

public class Auto {
    private String model;
    private int pries;

    public Auto(String model, int pries) {
        this.model = model;
        this.pries = pries;
    }

    public String getModel() {
        return model;
    }

    public int getPries() {
        return pries;
    }

    @Override
    public String toString() {
        return "A{" +
                "m='" + model + '\'' +
                ", p=" + pries +
                '}';
    }

    public static Comparator<Auto> autoComparator = Comparator.comparing(Auto::getModel);
    public static Comparator<Auto> autoPriesComparator = Comparator.comparingInt(Auto::getPries).reversed();

}
