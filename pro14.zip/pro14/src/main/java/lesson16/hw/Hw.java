package lesson16.hw;

import java.util.*;

public class Hw {
    //1. Напишите функцию, которая вернет самый часто встречающийся элемент в списке
    public static void main(String[] args) {

        List<Integer> elements = new ArrayList<>(Arrays.asList(1, 2, 3, 1, 2, 3, 2, 2, 5));

        System.out.println(mostCommonestElement(elements));

        List<Integer> numbs = new ArrayList<>(Arrays.asList(2,2,1,3,3,3,1));
        System.out.println(getAllOdds(numbs));

    } // main

    public static Map<Integer, Integer> mostCommonestElement(List<Integer> integers) {

        Map<Integer, Integer> res = new HashMap<>();

        for (Integer i : integers) {
            if (res.containsKey(i)) {
                res.put(i, res.get(i) + 1);
            } else {
                res.put(i, 1);
            }
        }

        Integer mostFreqeuncy = Collections.max(res.values());

        Map<Integer, Integer> mostCommonElements = new HashMap<>();

        for (Map.Entry<Integer, Integer> entry : res.entrySet()) {

            if (entry.getValue() == mostFreqeuncy) {
                mostCommonElements.put(entry.getKey(), entry.getValue());
            }

        }


        return mostCommonElements;
    }

    //Напишите функцию, которая вернет все элементы списка, которые встретились четное число раз

    public static Map<Integer, Integer> getAllOdds(List<Integer> numbers) {
        Map<Integer, Integer> numbs = new HashMap<>();

        for (Integer n : numbers) {
            if (numbs.containsKey(n)) {
                numbs.put(n, numbs.get(n) + 1);
            } else {
                numbs.put(n, 1);
            }

        }

        Map<Integer, Integer> res = new HashMap<>();

        for (Map.Entry<Integer, Integer> entry : numbs.entrySet()) {
            if (entry.getValue() % 2 == 0) {
                res.put(entry.getKey(), entry.getValue());
            }
        }
        return res;
    }

}
