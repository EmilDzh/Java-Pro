package lesson16;

import lesson16.MyBinaryTree.Vortex;

public class Lesson16 {
    // граф это совокупность ребер и вершин
    // вершина - Vortex
    // ребро - Edge - соединение между 2 вершинами
    // граф - полносвязный - можно по ребрам добраться из любой вершины в любую другую
    //      не полносвязный
    // циклический - когда из одной вершины можно добраться по ребрам в нее же
    // ациклический
    // дерево - ациклический и полносвязный граф
    // лемма - в дереве количество ребер равно
    //      количеству вершин - 1

    // Бинарное дерево - дерево у каждой из вершин которого может быть максимум
    //      две "дочерние" вершины

    public static void main(String[] args) {
       // MyBinaryTree.Vortex v5 = new MyBinaryTree.Vortex(5);

        Vortex v5 = new Vortex(5);
        Vortex v7 = new Vortex(7);
        Vortex v6 = new Vortex(6, v5, v7);
        Vortex v10 = new Vortex(10);
        Vortex v8 = new Vortex(8, v6, v10);

        MyBinaryTree tree = new MyBinaryTree(v8);
        System.out.println(tree);

    }
}
