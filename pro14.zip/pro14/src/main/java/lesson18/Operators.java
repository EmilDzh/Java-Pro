package lesson18;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;

public class Operators {
    public static void main(String[] args) {
        // Operator
        // это Function у которой одинаковы входной и возвращаемый тип
        // IntUnaryOperator - оператор принимающий и возвращающий int

        int[] numbers = new int[]{1, 3, 5, 2, 4, 11};
        int sum =
                Arrays.stream(numbers)
                        .reduce(0, new IntBinaryOperator() { // получение каждого элемента и что то сним сделать
                            @Override
                            public int applyAsInt(int total, int value) {
                                return total + value;
                            }
                        });
        System.out.println(sum);

    }
}
