package lesson18;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Functions {
    public static void main(String[] args) {
        // Function
        // принимает на вход элемент одного типа а отдает элемент другого типа
        // https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html
        // могут объединяться andThen и compose
//        Function<String, Integer> stringIntegerFunction = s -> {
//            return s.length();
//            // для строки возвращать ее длину
//            // до 20:14
//        };

        // для строки возвращать ее длину
        // до 20:14
        //     тип входа   выхода
        Function<String, Integer> stringIntegerFunction = String::length;

        List<String> names = Arrays.asList("John", "Max", "Alexander", "Vasilisa");

        System.out.println(
                names.stream()
                        .map(stringIntegerFunction)
                        .collect(Collectors.toList())
        );

        // напишите Function который добавит к строке одинарные кавычки
        // alex -> 'alex'
        Function<String, String> quote = s -> ("'" + s + "'");
        // до 20:24

        System.out.println(names.stream().map(quote).collect(Collectors.toList()));

        Function<Double, String> formatDouble = d -> "double: " + d;

        // от начала к концу
        System.out.println(
                formatDouble.andThen(quote).apply(3.14)
        );

        //наоборот

        System.out.println(
                quote.compose(formatDouble).apply(3.14)
        );

        // Identity
        Function<Long, Long> longIdentity = Function.identity();
        System.out.println(longIdentity.apply(3L));

        // BiFunction
        // функция которая принимает на вход два аргумента разных типов
        // и возвращает значение другого типа
        BiFunction<String, Double, Integer> formatter = (s, d) -> (s + " " + d).length();
        System.out.println(formatter.apply("hello", 3.14));

        Map<String, Integer> salaries = new HashMap<>();
        salaries.put("John", 15_000);
        salaries.put("Masha", 25_000);
        salaries.put("Alex", 17_000);
        salaries.put("Samuel", 33_000);

        salaries.computeIfAbsent("Max", s -> 4000 * s.length());
        System.out.println(salaries);

        // увеличьте зарплату каждого на 1200
        salaries.replaceAll(
                (name, salary) -> salary + 1200
        );
        System.out.println(salaries);

        // увеличьте зарплату Max в 2 раза
        // зарплату всех остальных остальных не меняем
        salaries.replaceAll(
                (name, salary) -> name.equals("Max") ? salary * 2 : salary
        );
        System.out.println(salaries);

    }

}
