package lesson29.hw;

public class Hw {
    public static void main(String[] args) {

        GenericLinkedList genericLinkedList = new GenericLinkedList();

        genericLinkedList.add("Hello");
        genericLinkedList.add("Hola");
        genericLinkedList.add("Servus");
        genericLinkedList.add("Moin");
        System.out.println(genericLinkedList.size());
        System.out.println(genericLinkedList);
        System.out.println(genericLinkedList.get(1));
        genericLinkedList.remove(3);
        System.out.println(genericLinkedList);

        System.out.println("==== Deque ====");

        MyGCDImpl myGCD = new MyGCDImpl();
        myGCD.addFirst("Nuernberg");
        myGCD.addFirst("Muenchen");
        myGCD.addFirst("Ingolstadt");
        myGCD.addFirst("Baden Baden");

        System.out.println(myGCD);

        System.out.println(myGCD.size());
        System.out.println(myGCD.getFirst());
        System.out.println(myGCD.getLast());

        myGCD.removeFirst();
        myGCD.removeLast();
        System.out.println(myGCD);
    }
}
