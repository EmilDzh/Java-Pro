package lesson22.hw;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

public class HW {
    public static void main(String[] args) {
        try
                (
                Reader reader = new FileReader("names.txt");
                )
        {
            Map<String, Integer> namesFrequency = frequency(reader);
            System.out.println(namesFrequency);
        }
        catch (Exception e)
        {
            System.err.println("Exception " + e.getMessage());
        }

        //Есть текстовой файл с произвольным текстом text.txt
        //Найдите самое длинное слово (слова отделяются между собой пробелами).

        try
                (
                Reader reader = new FileReader("text.txt");
                BufferedReader bufferedReader = new BufferedReader(reader);
                ) {
            String line = bufferedReader.readLine();


            String largest = null;
            while (line != null) {
                String[] words = line.split(" ");

                for (String word : words) {
                    if (largest == null || word.length() > largest.length()) {
                        largest = word;
                    }
                }
                line = bufferedReader.readLine();
            }
            System.out.println(largest);
        }
        catch (Exception e)
        {
            System.err.println("Exception " + e.getMessage());
        }



    }

    // 1. Дан файл (names.txt) со списком имен на выбор, некоторые имена повторяются.
    //
    //=== names.txt  начало ===
    //Max Alexander Lena
    //Sveta
    //Alexander Dima Lena Max
    //Sveta Pavel
    //===names.txt окончание====
    //
    //
    //Написать метод, который вернет количество вхождений каждого из имен в файл

    public static Map<String, Integer> frequency(Reader reader) {
        Map<String, Integer> result = new HashMap<>();

        try (
                BufferedReader bufferedReader = new BufferedReader(reader);
        ) {
            String line = bufferedReader.readLine();

            while (line != null) {

                String[] t = line.split(" ");

                for (String name : t) {
                    if (result.containsKey(name)) {
                        int count = result.get(name);
                        result.put(name, count + 1);
                    } else {
                        result.put(name, 1);
                    }
                }

                line = bufferedReader.readLine();

            }
        } catch (Exception e) {
            System.out.println("Exception " + e.getMessage());
        }

        return result;
    }


}
