package lesson5;

import java.util.Arrays;

public class ArrayTester {
    public static void main(String[] args) {
        int a[] = new int[]{1, 7, 5, 3, -20};// 5 элемента
        int b[] = new int[2];// массив из 2 элементов со значениями по умолчанию для типа

        String[] movies = new String[]{"Apocalypse now", "Taxi Driver", "Tango and Cache" };
        String[] groups = {"Guns and Roses", "Aerosmith", "Rolling Stones" };
        System.out.println("groups lenght: " + groups.length);// длина массива
        System.out.println(Arrays.toString(movies));
        System.out.println(movies[2]);
        movies[2] = "HAteful eight";//изменение значение элемента
        System.out.println(Arrays.toString(movies));

        //movies[3] = "Space Odyssey";
        //массив не возможно увеличить или уменьшить размер после создания;ArrayIndexOutOfBoundsException
        movies = new String[]{"Save private Ryan" };

        for (int i = 0; i < groups.length; i++) {
            System.out.println("movies: " + i + " " + groups[i]);
        }
        ;
        System.out.println(
                format(a, "<", ", ", ">")
        );


        System.out.println(multiply(a));

        // можно ли в каком-либо массиве хранить и 1.33 и 23 и "Dima" и true
        Object[] objects = {1.33, 23, "Dima", true};

        System.out.println("before");
        System.out.println(
                Arrays.toString(a)
        );
        reverse(a);
        System.out.println("after");
        System.out.println(
                Arrays.toString(a)
        );

        System.out.println(
                compare(new int[] {1,2,3}, new int[]{1,2, 3}) // true
        );

        System.out.println(
                compare(new int[] {1,2,3}, new int[]{1,2, 5}) // false
        );


    }

    public static int multiply(int[] c) {
        int res = 1;
        for (int i = 0; i < c.length; i++) {
            res *= c[i];
            System.out.println(c[i]);
        }
        return res;
    }


    //        prefix    delim   suffix
    // {1,2}, "<",      ", ",   ">"     ->     "<1, 2>"
    public static String format(int[] a, String prefix, String delimiter, String suffix) {
        String r = prefix;
        for (int i = 0; i < a.length; i++) {
            if (i != 0) {
                r += delimiter;
            }
            r += a[i];
        }
        r += suffix;
        return r;
    }

    // напишите функцию которая реверсит массив
    // поменять элементы местами именно в том массиве, который передается
    // {1,2,3,4} -> {4,3,2,1}
    public static void reverse(int[] d) //
    {
        // i = 0 <> 3 = d.length - 1 - i
        // 1 <> 2
        for (int i = 0; i < d.length / 2; i++) {
            int temp = d[i];
            d[i] = d[d.length - 1 - i];
            d[d.length - 1 - i] = temp;
        }
    }

    // напишите функцию которая сравнивает между собой два
    // массива целых и возвращает true если их элементы
    // попарно совпадают и false если нет
    public static boolean compare(int [] a, int [] b)
    {
        if(a.length != b.length)
            return false;
        for(int i = 0; i < a.length; i++)
        {
            if(a[i] != b[i])
                return false;
        }
        return true;
    }
}

