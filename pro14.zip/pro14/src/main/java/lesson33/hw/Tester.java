package lesson33.hw;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class Tester {
    public static void main(String[] args) {
        BankAccount ba = new BankAccount();

        ExecutorService service = Executors.newFixedThreadPool(3);

        for (int i = 0; i < 5; i++){
            service.submit(new BankAccount.BankAccountRunnable(ba));
        }

        service.shutdown();// main ждет окончание работы потоков

        try {
            service.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(
                ba.getBalance()
        );
    }
}
