package lesson33.hw;

import java.util.Random;
import java.util.stream.IntStream;

public class BankAccount {
    public static int balance;

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public synchronized void increaseBalance(int amount) { // нужно было изменить  метод класса synchronized??

        balance += amount;

    }

    public static class BankAccountRunnable implements Runnable {

        private BankAccount bankAccount;

        public BankAccountRunnable(BankAccount bankAccount) {
            this.bankAccount = bankAccount;
        }


        @Override
        public void run() {

            for (int i = 0; i < 10; i++){
                try {
                    Thread.sleep(new Random().nextInt(0,100));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

                bankAccount.increaseBalance(10);
            }
        }
    }
}
