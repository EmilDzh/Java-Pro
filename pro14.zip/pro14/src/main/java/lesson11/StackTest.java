package lesson11;

import java.util.Arrays;
import java.util.Stack;

public class StackTest {
    public static void main(String[] args) {
        // Stack - элементы добавляются и получаются с одной стороны
        // LIFO - Last in First Out

        // T push(T) - добавление элемента в верх стека
        // T pop() - удаление и возвращение элемента с вершины стэка
        // T peek() - возвращение элемента с вершины стэка без удаления
        // boolean empty()
        // int size()

        Stack<String> names = new Stack<>();
        names.push("Max");
        names.push("Dina");
        names.push("Dasha");
        names.push("Masha");

        while (!names.isEmpty()){
            System.out.println(names.pop());
        }

        //  возвращает на какой глубине находится элемент
        System.out.println(names.search("Max"));//-1 - такого элемента в стэке нет

        String line = "однажды в студеную зимнюю пору я из лесу вышел";
        // распечатайте эти слова в обратном порядке
        // вышел лесу из ...
        Stack<String> words = new Stack<>();
        for(String w : line.split(" "))
            words.push(w);
        while (!words.empty())
            System.out.print(words.pop() + " ");


    }
}
