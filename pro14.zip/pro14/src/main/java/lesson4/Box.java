package lesson4;

import java.util.ArrayList;

public class Box {
        public static void main(String[] args) {
            // int     boolean float byte double ...
            // Integer Boolean Float Byte Double ...
            int i = 10;
            Integer i1 = new Integer(i);

            Integer i2 = i; // boxing - упаковка

            if(i2 < 100) // unboxing - распаковка
                System.out.println("hello");

            int a = 10;
            int b = 10;
            //примитивные типы сравниваются по значению
            System.out.println(a == b); //

            Integer i3 = new Integer(10);
            Integer i4 = new Integer(10);
            System.out.println(i3 == i4); //false

            // == - эквивалентность
            // для ссылочных типов эквивалентность означает
            // совпадение адреса в памяти

            //ссылочные типы нужно сравнивать на равенство только с помошью  equals
            System.out.println(i3.equals(i4));//true

            // если мы хотим сравнивать между собой экземпляры наших
            // собственных классов, нужно переопредить в классе метод equals

            //все ссылочные типы в Джава это потомки класса Object

            String s1 = new String("Max");
            String s2 = new String("MAx");
            System.out.println(s1 == s2);//false
            String s3 = s1;
            System.out.println(s1 == s3);//true
            System.out.println(s1.equals(s3));//true сравнение по значению

            //Контейнеры стандартной библиотеки работают только с ссылочными данными
            ArrayList<Integer> list = new ArrayList<>();
            list.add(123);
            list.add(456);

            Employee e1 = new Employee(26, "Max Kotkov");
            Employee e2 = new Employee(26, "Max Kotkov");
            System.out.println(e1 == e2);//false

            // чтобы сравнивать объекты наших классов
            // нужно переопределить в классе equals
            System.out.println(e1.equals(e2)); // true

            String j1 = "JAva";// нет new
            String j2 = "JAva";// нет new
            //из-за особенностей реализации String

            System.out.println(j1 == j2);
        }
    }

