package lesson4.animals;

public class AnimalTester {
    public static void main(String[] args) {
        BigDog b1 = new BigDog("Sharik");
        b1.greets(b1);
    }
}
