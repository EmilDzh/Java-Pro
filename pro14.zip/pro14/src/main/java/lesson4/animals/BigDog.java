package lesson4.animals;

public class BigDog extends Dog{
    public BigDog(String name) {
        super(name);
    }
    @Override
    public void greets() {
        System.out.println("wow");
    }
    @Override
    public void greets(Dog another){
        System.out.println(another + " Woooow");
    }

    //перегруженный метод не получится вызвать по ссылке на базовый класс
    public void greets(BigDog another){//перегрузка overloading
        System.out.println("Wooooowwwwww");
    }
}
