package lesson4;

import lesson1.japan.JapaneseEmployee;

public class Lesson4 {
    public static void main(String[] args) {
        //примитивные типы данных - byte, short, int , long , float, double, boolean, char
        //если имя переменной начинается с маленькой буквы то это примитивный тип данных

        // примитивные типы встроены, мы не можем создать свои собственные

        // ссылочные типы это все остальные
        // в том числе и те, которые мы создаем сами

        int a = 5;

        Employee e1= new Employee(25,"Max Kotkov");
        Employee e2 = new Employee(26,"LEna Semenova");
        Employee e3 = e2;// создается новая ссылка на тот же самый обьект
        e3.setName("VAlera");
        System.out.println("lena:" + e2 + "Valera:" + e3);


        int b = a;

        b = 10;
        System.out.println("a=" + a + " b=" + b);

        System.out.println("MAx before: " + e1);
        something(e1);
        System.out.println("Max after: " + e1);

        System.out.println("Valeria befor: " + e2);
        somethingNew(e2);
        System.out.println("Valera after: " + e2);
    } //end of main

    public static void something(Employee e)
    {
        e.setAge(36);
    }

    public static void somethingNew(Employee e)
    {
        e = new Employee(21, "Sergey Smirnov");
        //мы не можем по одной ссылке изменить
        //на что ссылается другая ссылка
    }
}
