package lesson24;

import java.io.File;
import java.util.Arrays;

public class B_File {
    public static void main(String[] args) {
        File dogBin = new File("dog.bin");
        System.out.println("exists: " + dogBin.exists());
        System.out.println("length: " + dogBin.length());

        File currentDir = new File(".");
        if(currentDir.isDirectory())
        {
            System.out.println("is directory");
            String [] files = currentDir.list();
            System.out.println(
                    Arrays.asList(files)
            );

            Arrays.stream(files)
                    .forEach(
                            f -> {
                                // каждый файл распечатайте на отдельной строке
                                // с префиксом d для директории и
                                // f для не директории
                                // f names.txt
                                // ...
                                // d src
                                File file = new File(f);
                                if(file.isDirectory())
                                    System.out.print("d ");
                                else
                                    System.out.print("f ");
                                System.out.println(f);
                            }
                    );
        }
    }
}
