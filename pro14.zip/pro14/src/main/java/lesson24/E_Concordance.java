package lesson24;
/*
this is a cool climate
hate this climate
this brings relief to this pal
cool hate
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class E_Concordance {
    public static void main(String[] args) {
        // считайте строчки
        // превратите их в слова
        try (
                Reader fileReader = new FileReader("concordance.txt");
                BufferedReader bufferedReader = new BufferedReader(fileReader);
        ) {
//            bufferedReader.lines()
//                    .flatMap(line -> Arrays.stream(line.split(" ")))
//                    .forEach(
//                            System.out::println
//                    );
            List<String> lines =
                    bufferedReader.lines().toList();

            IntStream.rangeClosed(0, lines.size() -1) // 0, 1, 2, 3
                    .mapToObj(i -> new AbstractMap.SimpleEntry<>(i, lines.get(i))) // 3 -> "cool hate"
                    .flatMap(
                            p -> Arrays.stream(p.getValue().split(" "))
                                    .map( w -> new AbstractMap.SimpleEntry<>(w, p.getKey()))
                    )
                    .collect(Collectors.groupingBy(AbstractMap.SimpleEntry::getKey, Collectors.mapping(AbstractMap.SimpleEntry::getValue, Collectors.toList())))
                    .forEach((w, linesInt) -> System.out.println(w + " -> " + linesInt));// "cool" -> 3



        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        // создайте Map<String, List<Integer>>
        // List<Integer>> - номера строк в которых это слово встречалось
        // "this" -> [0, 1, 2]
        // "cool" -> [0, 3]

    }
    //System.out.println(
    //                    IntStream.range(0, lines.size()) // 0, 1, 2, 3
    //                            .mapToObj(i -> new AbstractMap.SimpleEntry<>(i, lines.get(i))) // 3 -> "cool hate"
    //                            .flatMap( // this -> 0, ..., cool -> 3, hate -> 3
    //                                    p -> Arrays.stream(p.getValue().split(" "))
    //                                            .map(w -> new AbstractMap.SimpleEntry<>(w, p.getKey()))
    //                            ).collect(
    //                                    Collectors.groupingBy(
    //                                            pair -> pair.getKey(),
    //                                            Collectors.mapping(
    //                                                    pair -> pair.getValue(),
    //                                                    Collectors.toList()
    //                                            )
    //                                    )
    //                            )
    //            );
}
