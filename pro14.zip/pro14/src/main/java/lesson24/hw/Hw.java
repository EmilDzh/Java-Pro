package lesson24.hw;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;

public class Hw {
    public static void main(String[] args) {
        try
                (
                        Reader reader = new FileReader("concordance.txt")
                ) {
            lineCount(reader);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        countLinesWithSubstring("concordance.txt", "this");

    }
    //1. Напишите функцию, которая считает количество строк в передаваемом в нее в виде параметра текстовом файле

    public static void lineCount(Reader reader) {
        try
                (
                        BufferedReader bufferedReader = new BufferedReader(reader);
                )
        {
            int count = 0;
            String lines = bufferedReader.readLine();
            while (lines != null) {
                String[] words = lines.split(" ");

                for (String word : words) {
                    if (!word.isEmpty()) {
                        count++;
                    }
                }

                lines = bufferedReader.readLine();

            }
            System.out.println(count);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    //В функцию передаются имя файла и подстрока. Посчитайте количество строк текстового файла, содержащие эту подстроку.

    public static void countLinesWithSubstring(String fileName, String substring){
        try
                (
                Reader reader = new FileReader(fileName);
                BufferedReader bufferedReader = new BufferedReader(reader);
                )
        {
            String lines = bufferedReader.readLine();
            int count = 0;
            while (lines != null){
                String [] words = lines.split(" ");
                for (String word : words){
                    if (word.equals(substring))
                        count++;
                }
                lines = bufferedReader.readLine();
            }
            System.out.println(count);
        }
        catch (Exception e){
            System.err.println(e.getMessage());
        }
    }
}
