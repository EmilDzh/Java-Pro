package lesson3.animals;

public class Cat implements Animal{
    @Override
    public void move() {
        System.out.println("Cat is Jumping");
    }

    @Override
    public void voice() {
        System.out.println("Miyauuuu");

    }
}
