package lesson3.pizza;


// перечисление
public enum PizzaSize {
    // все возможные варианты,
    // других быть не может
    SMALL, MEDIUM, BIG
}