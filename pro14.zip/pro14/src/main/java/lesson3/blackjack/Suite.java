package lesson3.blackjack;

//DIAMONDS, SPADES, HEARTS, CLUBS;
public enum Suite {
    DIAMONDS,
    SPADES,
    HEARTS,
    CLUBS;
}
