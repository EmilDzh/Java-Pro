package lesson3.weekdays;

import java.util.Arrays;

public enum WeekDays {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,// 5 порядковый номер
    SUNDAY;// 6 порядковый номер

    // напишите функцию
    public boolean isWeekDay()
    {

       return ordinal() < 5;
    }

    public static void main(String[] args) {
        System.out.println(MONDAY);
        System.out.println(SUNDAY.ordinal());//порядковый номер при объявлении
        System.out.println(
                Arrays.toString(
                        WeekDays.values() //массив значений
                ));

        WeekDays f = WeekDays.FRIDAY;
        System.out.println(f);

        WeekDays w = WeekDays.valueOf("WEDNESDAY");
        System.out.println(w);
        //такого элементе нет в Энам
        //WeekDays noSuchDay = WeekDays.valueOf("NOSUCHDAY");
        System.out.println(SUNDAY.isWeekDay());// false
    }
}
