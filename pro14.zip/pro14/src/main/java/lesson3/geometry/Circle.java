package lesson3.geometry;

public class Circle extends Figure {
    // добавить в виде поля радиус r
    private double r;
    // создать конструктор с одним параметром
    public Circle(double r) {
        this.r = r;
    }

    // отнаследовать от фигуры
    // реализовать методы perimeter и area отнаследованные от Figure
    @Override
    public double area() {
        //return Math.PI * Math.pow(r, 2);
        return Math.PI * r * r;
    }

    @Override
    public double perimeter() {
        return 2 * Math.PI * r;
    }
}
