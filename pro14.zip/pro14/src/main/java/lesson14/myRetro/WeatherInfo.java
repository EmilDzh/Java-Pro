//package lesson14.myRetro;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class WeatherInfo {
//    public String temperature;
//    public String wind;
//    public String description;
//    public List<Forecast> forecasts;
//}
