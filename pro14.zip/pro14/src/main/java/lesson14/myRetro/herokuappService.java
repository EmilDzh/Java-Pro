//package lesson14.myRetro;
//
//import retrofit2.Call;
//import retrofit2.http.Query;
//
//public interface herokuappService {
//    Call<WeatherInfo> convert(
//
//          @Query("temperature") String temperature;
//            @Override("wind") String wind;
//            String description;
//    )
//
//}
