package lesson14.hw;

//    //. Создайте класс Employee с полями int id, String name, int age, double salary
//    //Реализуйте в этом классе Comparable по полю id
//    //В виде статических полей добавьте компараторы для сортировки по возрасту, имени и по зарплате

import java.util.Comparator;

public class Employee implements Comparable<Employee> {
    int id;
    String name;
    int age;
    double salary;

    public Employee(int id, String name, int age, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public int compareTo(Employee employee) {
        return Integer.compare(getId(), employee.getId());
    }

    public static Comparator<Employee> ageComparator = new Comparator<Employee>() {
        @Override
        public int compare(Employee a1, Employee a2) {
            return Integer.compare(a1.getAge(), a2.getAge());
        }
    };

    public static Comparator<Employee> nameComparator = new Comparator<Employee>() {
        @Override
        public int compare(Employee n1, Employee n2) {
            return n1.getName().compareTo(n2.getName());
        }
    };

    public static Comparator<Employee> salaryComparator = new Comparator<Employee>() {
        @Override
        public int compare(Employee s1, Employee s2) {
            return Double.compare(s1.getSalary(), s2.getSalary());
        }
    };

    @Override
    public String toString() {
        return "E{" +
                "id=" + id +
                ", n='" + name + '\'' +
                ", a=" + age +
                ", s=" + salary +
                '}';
    }
}
