package lesson14.hw;

import java.util.*;

public class Hw {
   // Создайте коллекцию с сотрудниками и отсторируйте ее вначале по возрасту и потом по имени по убыванию

    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>(Arrays.asList(
                new Employee(12345,"Jeremiah JD",23,15.000),
                new Employee(32153456,"Jerom JD",20,10.000),
                new Employee(443,"Bruce Wayne",15,50.0000000),
                new Employee(113,"James Gordon",30,5000.00),
                new Employee(228,"Oswald Kapelput",33,30.00000)
        ));

        Collections.sort(employees,Employee.ageComparator.thenComparing(Employee.nameComparator.reversed()));
        System.out.println(employees);

       List<Comparator<Employee>> comparators = new ArrayList<>(Arrays.asList(
               Employee.ageComparator,
               Employee.nameComparator,
               Employee.salaryComparator
       ));

       sortEmployees(employees,comparators);
        System.out.println(employees);



    }
    //Напишите статическую функцию, которая принимает на вход:
    //    коллекцию для сортировки
    //    список компараторов
    //и сортирует переданную коллекцию составным компаратором из переданного списка
    //public static void sortEmployees(Collection emps, Collection> comps)

    //РЕШЕНИЕ ЧАТА, САМ НЕДОДУМАЛСЯ(((

    public static void sortEmployees(Collection emps, Collection<Comparator<Employee>> comps){

//        Comparator<Employee> employeeComparator = new Comparator<Employee>() {
//            @Override
//            public int compare(Employee e1, Employee e2) {
//               for (Comparator<Employee> copm: comps){
//                   int result = comp.compare(e1,e2);
//                   if (result != 0)
//                       return result;
//               }
//               return 0;
//            }
//        };
        Comparator<Employee> employeeComparator = (e1, e2) -> {
            for (Comparator<Employee> comp: comps){
                int result = comp.compare(e1,e2);
                if (result != 0)
                    return result;
            }
            return 0;
        };

        List<Employee> empList = new ArrayList<>(emps);
        empList.sort(employeeComparator);

        emps.clear();
        emps.addAll(empList);


    }
}
