package lesson34;

import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;


public class CC_Practice {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // напишите CompletableFuture из нескольких стадий
        // 1 стадия - создать и вернуть рандомное число от 0 до 200
        //       и потом его результат распечатать через cf.get()
        //      до 20:25
        CompletableFuture<Integer> cf = CompletableFuture.supplyAsync(
                () -> new Random().nextInt(200)
        )
                // 2 стадия - умножьте полученное число само на себя
                .thenApplyAsync(
                        integer -> integer * integer
                );


        // до 20:35

        // CompletableFuture запустится только только после того, как
        // будет вызван его get()
        System.out.println(cf.get());

        System.out.println(cf.get());

    }
}

/*
       CompletableFuture<Void> future = CompletableFuture.supplyAsync(
                        () -> new Random().nextInt(0, 200)
                )
                .thenAccept(
                        System.out::println
                );

        try {
            System.out.println(future.get());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } */
