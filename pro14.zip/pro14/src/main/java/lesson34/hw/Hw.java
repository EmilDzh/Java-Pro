package lesson34.hw;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Hw {
    public static void main(String[] args) {

        //ДЗ проф ява
        //Переделайте B_DontDoLikeThis на CompletableFuture
        //(последовательное выполнение функций в разных потоках, обработка ошибок)

        // // Создайте "первый" поток, который вызывает getName
        //        // и запускает "второй" поток, в котором выполняется getLength,
        //        //      передавая туда результат getName в качестве параметра
        //        // во "втором" потоке вызовите "третий" поток, передав туда результат
        //        //      getLength и вызовите с ним finish()

        CompletableFuture<Void> future = CompletableFuture.supplyAsync(
                new Supplier<String>() {
                    @Override
                    public String get() {
                        return getUserName();
                    }
                }
        )
                .thenApply(
                        new Function<String, Integer>() {

                            @Override
                            public Integer apply(String s) {
                                return getLength(s);
                            }
                        }
                ).thenAccept(
                        new Consumer<Integer>() {
                            @Override
                            public void accept(Integer integer) {
                                finish(integer);
                            }
                        }
                );

        try {
            future.get();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }

    }

    public static String getUserName()
    {
        long time = System.currentTimeMillis();
        if(time % 2 == 0)
            throw new RuntimeException("Something happens");
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {}
        return "Alexander";
    }

    public static Integer getLength(String s)
    {
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {}
        return s.length();
    }

    public static void finish(Integer i)
    {
        System.out.println("Result is: " + i);
    }
}

/*
CompletableFuture<Void> work = CompletableFuture.supplyAsync(
                // () -> return getUserName()
                new Supplier<String>() {
                    @Override
                    public String get() {
                        return getUserName();
                    }
                }
        )
        thenApply and thenAccept в одном флаконе
        .handle(
                        new BiFunction<Integer, Throwable, Void>() {
                            @Override
                            public Void apply(Integer integer, Throwable throwable) {
                                if(throwable != null)
                                    System.out.println("exeptionally");
                                else
                                    finish(integer);
                                return null;
                            }
                        }
                )
                .thenApply(
                        // s -> return getLength(s)
                        new Function<String, Integer>() {
                            @Override
                            public Integer apply(String s) {
                                return getLength(s);
                            }
                        }
                )
                .thenAccept(
                        // i-> finish(i)
                        new Consumer<Integer>() {
                            @Override
                            public void accept(Integer integer) {
                                finish(integer);
                            }
                        }
                )
                .exceptionally(
                        // t -> System.out.println("exceptionally")
                        new Function<Throwable, Void>() {
                            @Override
                            public Void apply(Throwable throwable) {
                                System.out.println("exceptionally");
                                return null;
                            }
                        }
                );
*/