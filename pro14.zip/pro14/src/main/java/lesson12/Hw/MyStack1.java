package lesson12.Hw;

import java.util.LinkedList;

public class MyStack1 implements MyStack {
    private LinkedList<Integer> list;

    public MyStack1(){
        list = new LinkedList<>();
    }

    @Override
    public boolean emtpy() {
        return list.isEmpty();
    }

    @Override
    public int peek() {
        if (list.isEmpty()){
            throw new IndexOutOfBoundsException();
        }
        return list.getFirst();
    }

    @Override
    public int pop() {
        if (list.isEmpty()){
            throw new IndexOutOfBoundsException();
        }
        return list.removeFirst();
    }

    @Override
    public void push(int i) {
       list.addFirst(i);
    }

    @Override
    public int size() {
        return list.size();
    }
}
