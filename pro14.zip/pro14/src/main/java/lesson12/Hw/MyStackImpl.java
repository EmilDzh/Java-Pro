package lesson12.Hw;

public class MyStackImpl implements MyStack {

    private int[] source;
    private int size;
    private static final int INITIALCAPASITY = 4;

    public MyStackImpl() {
        source = new int[INITIALCAPASITY];
    }

    @Override
    public boolean emtpy() {

        return size == 0;
    }

    @Override
    public int peek() {
        if (size == 0) {
            throw new IndexOutOfBoundsException();
        }

        return source[size - 1];
    }

    @Override
    public int pop() {
        if (size == 0) {
            throw new IndexOutOfBoundsException();
        }
        size--;
        return source[size - 1];
    }

    @Override
    public void push(int i) {
        if (size == source.length)
            increasyCapasity();

        source[size] = i;
        size++;
    }

    private void increasyCapasity() {
        int[] newSource = new int[source.length * 2];
        for (int i = 0; i < source.length; i++) {
            newSource[i] = source[i];
        }
        source = newSource;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public String toString() {
        String r = "[";
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                r += ", ";
            }
            r += source[i];
        }
        r += "]";
        return r;
    }
}
