package lesson12.Hw;

public interface MyStack {
    boolean emtpy();//
    int peek();//возвращение элемента с вершины стэка без удаления
    int pop();//удаление и возвращение элемента с вершины стэка
    void push(int i);//добавление элемента в верх стека
    int size();
}
