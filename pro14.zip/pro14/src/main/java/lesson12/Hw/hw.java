package lesson12.Hw;

import java.util.*;

public class hw {
    //1. Есть список стран countries = ["Andorra", "Belize", "Cayman", "France", "Argentina", "Cuba", "Sweden"]
    //и есть список слов words = ["Andorra", "Canada", "First", "candy", "Argentina", "wood",
    // "parrot", "cat", "Alan", "Cuba", "Finland", "Axelrod" , "Avangard", "Cuba"]
    //нужно получить список всех стран из списка слов, начинающихся на "A" - т.е., ["Argentina", "Andorra"]

    public static void main(String[] args) {

        List<String> countries = new ArrayList<>(Arrays.asList("Andorra", "Belize", "Cayman", "France", "Argentina", "Cuba", "Sweden", "Amerika"));
        List<String> words = new ArrayList<>(Arrays.asList("Andorra", "Canada", "First", "candy", "Argentina", "wood",
                "parrot", "cat", "Alan", "Cuba", "Finland", "Axelrod", "Avangard", "Cuba", "Amerika"));

        System.out.println(getCountries(countries, words));

        String words1 = "Asus Basus Masus Asus Gasus Basus ";

        System.out.println(searchUniq(words1));

        int[] nums = {8, 12, 10, 5};
        int target = 60;

        System.out.println(checkArr(nums, target));

        Set<Integer> gg = new HashSet<>(Arrays.asList(-1,-22,33,-4));
       deleteNegative(gg);
        System.out.println(gg);

        //Реализуйте стэк используя LinkedList
        //https://docs.oracle.com/javase/8/docs/api/java/util/Stack.html

        MyStack myStack = new MyStackImpl();
        myStack.push(2);
        myStack.push(3);
        myStack.push(4);
        myStack.push(5);
        myStack.push(6);
        myStack.push(7);
        myStack.push(8);
        System.out.println(myStack);
        myStack.pop();
        System.out.println(myStack);//[2, 3, 4, 5, 6, 7]
        System.out.println(myStack.peek());//7
        System.out.println(myStack);//[2, 3, 4, 5, 6, 7]
        System.out.println(myStack.emtpy());



    }// main

    public static List<String> getCountries(List<String> a, List<String> b) {

        List<String> gg = new ArrayList<>();
        for (String word : b) {
            if (word.startsWith("A") && a.contains(word))
                gg.add(word);
        }

        return gg;
    }

    //Напишите метод, который принимает на вход строку и возвращает количество уникальных символов в ней

    public static Set<String> searchUniq(String a) {
        Set<String> uniq = new HashSet<>(Arrays.asList(a.split(" ")));
        return uniq;
    }

    // Напишите функцию, принимающую на вход массив целых и целое число.
    //Функция должна возвращать true если среди чисел массива есть пара, произведение которых дает второй аргумент
    //Подумайте об оптимальном алгоритм сравнения
    //например: [8,12,10,5], 60 -> true так как 12*5=60


    public static boolean checkArr(int[] a, int b) {
        Set<Integer> set = new HashSet<>();

        for (int num : a) {
            if (b % num == 0 && set.contains(b / num)) {
                return true;
            }
            set.add(num);
        }
        return false;
    }

    //Напишите программу, которая удаляет все отрицательные числа из заданного сета

    public static void deleteNegative(Set<Integer> a) {
//        Set<Integer> gg = new HashSet<>();
//        for (int num : a) {
//            if (num > 0)
//                gg.add(num);
//        }
//        return gg;


        Iterator<Integer> iter = a.iterator();
            while (iter.hasNext()){
                if (iter.next() < 0){
                    iter.remove();
                }
            }

    }
}
