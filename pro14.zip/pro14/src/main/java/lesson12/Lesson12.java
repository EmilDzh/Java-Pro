package lesson12;

import java.util.*;


// Stack, Deque, Queue
// для моделирования оплаты покупок в магазине - Queue
// для моделирования обслуживания пассажиров разных уровней - PriorityQueue
// процедуру сдачи книг в библиотеке - Stack
// автобус - люди входят через переднюю дверь выходят через заднюю Queue

public class Lesson12 {

    public static void main(String[] args) {
        System.out.println(isPalindrome("мадам")); // true
        System.out.println(isPalindrome("шалаш")); // true
        System.out.println(isPalindrome("hello")); // false
        System.out.println(reversePolishCalculator("3 4 + 2 - 6 *")); // 30

        System.out.println(checkBrackets("{()[]{}}")); // true
        System.out.println(checkBrackets("{(]}")); // false
        System.out.println(checkBrackets("[{()}]")); // true
        System.out.println(checkBrackets("{(}")); // false
        System.out.println(checkBrackets("}")); // false
        System.out.println(convert(255, 16));//FF
        System.out.println(convert(255, 2)); // 11111111
    }
    // полиндром - слово которое читается одинаково с любой стороны
    // алла  или заказ шалаш поп мадам

    public static boolean isPalindrome(String w)
    {
        Deque<Character> d = new ArrayDeque<>();
        // нужно добавить все символы в Deque
        for(char c: w.toCharArray())
            d.add(c);
        // в цикле проверять что размер контейнера > 1
        while (d.size() > 1) {
            //      взять символы с начала и с конца и сравнить через equals
            Character f = d.removeFirst();
            Character l = d.removeLast();
            if(!f.equals(l))
                return false;
        }
        return true;
    }

    // обратно-польский калькулятор
    // обратно-польская нотация Лукасевича
    // (3 + 4 - 2) * 6
    // 3 4 + 2 - 6 *
    //     7 2 - 6 *
    //         5 6 *
    //             30

    public static int reversePolishCalculator(String s)
    {
        int r = 0;
        Queue<String> t = new LinkedList<>(Arrays.asList(s.split(" ")));
        int operand1 = 0;
        if(!t.isEmpty())
            operand1 = Integer.parseInt(t.poll());
        while (t.size() >= 2)
        {
            int operand2 = Integer.parseInt(t.poll());
            String operation = t.poll();
            switch (operation)
            {
                // + - * / - возможные значения operation
                case "+":
                    r = operand1 + operand2;
                    break;
                case "-":
                    r = operand1 - operand2;
                    break;
                case "*":
                    r = operand1 * operand2;
                    break;
                case "/":
                    r = operand1 / operand2;
                    break;
            }
            System.out.printf("%d %s %d = %d\n", operand1, operation, operand2, r);
            // присвоить значение r первому операнду
            operand1 = r;
        }
        return r;
    }

    // напишем функцию для проверки правильности расстановки скобок
    // {([
    // {()[]{}} - true
    // {(]} - false
    // [{()}] - true
    // {(} - false
    public static boolean checkBrackets(String w) {
        Stack<Character> brackets = new Stack<>();
        for (char c : w.toCharArray()) {
            // если символ это открывающая скобка, заносим ее в stack

            if ( (c == '}' || c == ']' || c == ')' ) && brackets.empty())
                return false;

            if (c == '{' || c == '[' || c == '(')
                brackets.push(c);
                // если символ это закрывающая скобка, то убираем из вершины стэка
                //      символ только в том случае если это соответсвующая открывающая скобка
            else if (
                    (c == '}' && brackets.peek() == '{') ||
                            (c == ']' && brackets.peek() == '[') ||
                            (c == ')' && brackets.peek() == '(')
            ) {
                brackets.pop();
            }
        }
        return brackets.size() == 0;
    }

    public static String convert(int number, int base)
    {
        String digits = "0123456789ABCDEF";
        Stack<String> stack = new Stack<>();
        while (number > 0)
        {
            int index = number % base; // индекс цифры
            stack.push(digits.substring(index, index + 1));
            number /= base;
        }
        String r = "";
        while (!stack.empty())
            r += stack.pop();
        return r;
    }
}
