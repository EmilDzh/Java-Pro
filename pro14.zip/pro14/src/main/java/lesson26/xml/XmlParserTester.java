package lesson26.xml;

// pare - извлечь полезную информацию

//XML  - eXtensible Markup Language

//Sax - потоковая библиотека - быстрая
//      не строит дерево документа
//      низкие требования  к памяти

//DOM - Document Object Model
//      строится полное дерево документа
//      требует больше памяти

//XML   Schema
//XML   DTD
//          позволяют автоматически проверит соответствие XML документа
//          заранее определенной структуры

//Xpath - позволяет выполнить запрос к документу
//XSLT -  используется для трансформации документов XML к другому виду и формату
//JAXB and SimpleXML - самые распространенные библиотеки для
//        ORM - чтобы можно сериализовать и десериализовать объект в XML
//ORM - Object Realition Mapping

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

public class XmlParserTester {
    public static void main(String[] args) throws Exception { // никогда не делать такого
        //DOM parsing
        DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        // Document - это дерево из элементов и атрибутов в памяти
        Document doc = builder.parse(new File("test.xml"));
        // корневой элемент документа
        Element root = doc.getDocumentElement();
        NodeList priceNodeList = root.getElementsByTagName("PRICE");

        for (int i = 0 ; i < priceNodeList.getLength(); i++){
            Node priceList = priceNodeList.item(i);
            System.out.println(
                    priceList.getFirstChild().getTextContent()
            );
        }
        //сложите все элементы Zone

        NodeList sumZ = root.getElementsByTagName("ZONE");
          int res = 0;
        for (int i = 0; i < sumZ.getLength(); i++){
          res += Integer.parseInt(sumZ.item(i).getFirstChild().getTextContent());
        }
        System.out.println(res);

        System.out.println(
                root.getAttribute("name")
        );
        System.out.println(
                root.getAttribute("size")
        );

        Element plant2 = (Element) root.getChildNodes().item(3);
        System.out.println(plant2.getAttribute("plantid"));

        System.out.println(root.getChildNodes().item(1).getNodeType());

        NodeList childNodes = root.getChildNodes();
        for (int i = 0; i < childNodes.getLength();i++){

            System.out.println(childNodes.item(i).getNodeType());
        }
    }
}
