package lesson26.xml.jaxb;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;

import java.io.File;

public class JaxbDeserializer {
    public static void main(String[] args) throws Exception{
        JAXBContext context = JAXBContext.newInstance(Catalog.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        Catalog catalog = (Catalog) unmarshaller.unmarshal(new File("test.xml"));
        System.out.println(catalog);
        System.out.println(catalog.getPlants().get(1).getPlantid());

    }
}
