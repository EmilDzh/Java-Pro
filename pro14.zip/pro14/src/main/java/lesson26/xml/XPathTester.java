package lesson26.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;

//https://en.wikipedia.org/wiki/XPath

public class XPathTester {
    public static void main(String[] args) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(new File("test.xml"));

        Element root = doc.getDocumentElement();

        /*
            /CATALOG
            //LIGHT - такой запрос даст все элементы LIGHT в любом месте документа
            /CATALOG/PLANT - все элементы PLANT дочерние для CATALOG
            //MOVIE/ACTOR - элементы ACTOR дочерние для MOVIE в любом месте документа
            //PLANT[@plantid = '456']/PRICE
         */

        XPath xPath = XPathFactory.newDefaultInstance().newXPath();
        XPathExpression expression = xPath.compile("//PLANT[@plantid = '456']/PRICE");
        NodeList price = (NodeList) expression.evaluate(doc, XPathConstants.NODESET);
        for (int i = 0; i < price.getLength(); i++){
            System.out.println("price: " + price.item(i).getFirstChild().getTextContent());
        }
    }
}
