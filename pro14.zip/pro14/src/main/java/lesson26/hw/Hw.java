package lesson26.hw;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Hw {
    public static void main(String[] args) throws Exception {
        String string = "replaceAllVowels";
        System.out.println(replaceAllVowels(string));

        String pinC = "A23456";
        System.out.println(isPinCode(pinC));

        String intToD = "прибыль 12 расходы 20 доходы 50.3";
        System.out.println(mapAllIntsToDouble(intToD));

        System.out.println(maPAllIntsToDouble(intToD));

        System.out.println(allIntsToDouble(intToD));

        //4*. Посчитайте сумму цен растений из файла test.xml  - $2.44+$9.37 должно быть 11.81

        DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(new File("test.xml"));

        Element root = doc.getDocumentElement();
        NodeList priceNodeList = root.getElementsByTagName("PRICE");
        double curr = 0;
        for (int i = 0; i < priceNodeList.getLength(); i++) {
            String priceText = priceNodeList.item(i).getTextContent();
            double price = Double.parseDouble(priceText.replaceAll("\\$", ""));

            curr += price;

        }
        System.out.println(curr);

        System.out.println("==== XPath ====");

        DocumentBuilderFactory factory1 = DocumentBuilderFactory.newDefaultInstance();
        DocumentBuilder builder1 = factory1.newDocumentBuilder();
        Document doc1 = builder1.parse(new File("test.xml"));
        Element root1 = doc1.getDocumentElement();

        XPath xPath = XPathFactory.newDefaultInstance().newXPath();
        XPathExpression expression = xPath.compile("//PLANT/PRICE");
        NodeList list = (NodeList) expression.evaluate(doc1, XPathConstants.NODESET);
        double res = 0.0;
        for (int i = 0; i < list.getLength(); i++){
            String priceT = list.item(i).getTextContent();
            double price1 = Double.parseDouble(priceT.replaceAll("\\$",""));
            res += price1;
        }
        System.out.println(res);


    }// main

    //1. Напишите функцию replaceAllVowels, удаляющую из строки все гласные в любом регистре и возвращающую измененную строку

    public static String replaceAllVowels(String s) {
        //A, E, I, O, U
        return s.replaceAll("[aAeEiIoOuU]", "");
    }

    //2. Напишите функцию isPinCode, проверяющую, что строка является пин-кодом. Пин-код состоит из 4 или 6 цифр

    public static boolean isPinCode(String s) {
        return s.matches("\\d{4}|\\d{6}");
    }

    //*. Напишите функцию mapAllIntsToDouble, которая бы добавляла к каждому целому в передаваемой строке ".0"
    //Пример: "прибыль 12 расходы 20 доходы 50.3" -> "прибыль 12.0 расходы 20.0 доходы 50.3"
    // \\b - найти границу

    public static String mapAllIntsToDouble(String s) {

        return s.replaceAll("(\\d+)", "$1.0");

    }

    public static String maPAllIntsToDouble(String s) {
        Pattern p = Pattern.compile("(\\d+)");
        Matcher m = p.matcher(s);

        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String number = m.group(1);
            double doubleN = Double.parseDouble(number);
            if (number.contains(".")) {
                m.appendReplacement(sb, number);
            } else {
                m.appendReplacement(sb, String.format("%.1f", doubleN));
            }
        }

        m.appendTail(sb);
        return sb.toString();
    }

    public static String allIntsToDouble(String s) {
        String[] words = s.split(" ");
        for (int i = 0; i < words.length; i++) {
            try {
                double number = Double.parseDouble(words[i]);
                if (number == (int) number) {
                    words[i] = String.format("%.1f", number);
                }
            } catch (NumberFormatException e) {
                // Проигнорировать слова, которые нельзя преобразовать в число
            }
        }
        return String.join(" ", words);
    }


}
