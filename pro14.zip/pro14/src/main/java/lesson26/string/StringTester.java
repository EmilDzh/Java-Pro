package lesson26.string;

import java.util.Random;

public class StringTester {
    public static void main(String[] args) {
        String max = "Max";
        String anotherMax = "Max";
        String max2 = new String("Max");
        System.out.println(anotherMax == max);// true | false
        System.out.println(max == max2);//false обьекты сравниваются по адреса памяти New // по адресу для ссылочных типов

        System.out.println(max.equals(max2));// нужно всегда (стринг) сравнивать с equals

       // String - final and immutable
        String name = "Anna";
        name +=" ";
        name += "Vasilieva";

        StringBuilder sb = new StringBuilder();
        sb.append("Anna");
        sb.append(" ");
        sb.append("Vasilieva");
        System.out.println(sb.toString());
        concatManyDoubleUsingStringBuilder();

        StringBuffer stringBuffer = new StringBuffer();// лучше использовать в многопоточных приложениях;

    } // main

    public static void concatManyDoubleUsingStringBuilder(){
        long before = System.currentTimeMillis();
        StringBuilder r = new StringBuilder();
        Random random = new Random();
       for (double i = 0; i < 10000; i++){

           r.append(random.doubles());
       }
        long after = System.currentTimeMillis();

        System.out.println("Time concatManyDoubleUsingStringBuilder(): " + (after - before)); // string 343 //StringBuilder 15))
    }
}
