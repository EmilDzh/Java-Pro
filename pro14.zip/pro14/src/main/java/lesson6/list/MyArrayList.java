package lesson6.list;
//https://ru.wikipedia.org/wiki/Design_Patterns

import java.util.Arrays;
import java.util.Iterator;

public class MyArrayList implements MyList, Iterable<Integer> {

    // количество заполненных элементов, видимый пользователю размер контейнера
    private int size = 0;
    private int[] data; // массив в которому будут храниться элементы
    // начальный размер массива
    private static final int INITIAL_CAPACITY = 4;

    public MyArrayList() {
        data = new int[INITIAL_CAPACITY];
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean contains(int value) {
        //нужно пробежаться по всем элементам массива
        for (int i = 0; i < size; i++) {
            if (data[i] == value)
                return true;
        }
        return false;
    }

    @Override
    public void set(int index, int value) {
        // проверить что index находится в диапазоне 0 <= index < size
        // если не так, выбросим исключение
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException();
        // изменим значение по индексу index в массиве data
        // до 21:20
        data[index] = value;
    }

    @Override
    public void add(int value) {
        // добавление элемента в конец
        // если size() == data.length то нужно
        if (size() == data.length) {
            //      создать массив большего размера
            //      скопировать туда все элементы из старого
            increaseCapacity();
        }
        // добавить в конец элемент value
        data[size] = value;
        // увеличить size
        size++;
        // до 21:26
    }

    private void increaseCapacity() {
        // нужно создать массив в 2 раза больше
        int[] newData = new int[data.length * 2];
        // скопировать элементы от 0 до data.length из старого массива в новый
        for (int i = 0; i < data.length; i++) {
            newData[i] = data[i];

        }
        // присвоить data ссылку на новый массив
        data = newData;
        // до 21:35
    }

    //Затем мы сдвигаем элементы справа от указанного индекса вправо,
    // чтобы освободить место для нового элемента.
    // Мы начинаем со счетчика size (последний индекс) и перемещаемся влево до
    // указанного индекса, присваивая каждому элементу значение предыдущего элемента.
    //Наконец, мы вставляем новый элемент на указанный индекс и увеличиваем счетчик size.

    @Override
    public void add(int index, int value) {

        if (index < 0 || index >= size())
            throw new IndexOutOfBoundsException();

        if (size() == data.length)
            increaseCapacity();

        // Сдвигаем элементы справа от указанного индекса вправо
        for (int i = size; i > index; i--) {
            data[i] = data[i - 1];
        }

        // Вставляем новый элемент на указанный индекс
        data[index] = value;
        size++;

    }

    @Override
    public void remove(int index) {
        if (index < 0 || index >= size())
            throw new IndexOutOfBoundsException();
        for (int i = index + 1; i < size(); i++) {
            data[i - 1] = data[i];
        }
        size--;
    }

    @Override
    public int get(int index) {
        // напишите с учетом проверки index как в set
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException();


        // до 21:50
        return data[index];
    }






    @Override
    public String toString() {
        String r = "[";
        for (int i = 0; i < size(); i++) {
            if (i != 0)
                r += ", ";
            r += data[i];
        }
        r += "]";
        return r;
    }
    //@Override
    //    public void add(int index, int value) {
    //        if(index <= 0 || index >= size())
    //            throw new IndexOutOfBoundsException();
    //        if(size() == data.length)
    //            increaseCapacity();
    //        for(int i = size() - 1; i >= index; i--)
    //        {
    //            data[i+1] = data[i];
    //        }
    //        data[index] = value;
    //        size++;
    //    }
    //https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html
    public Iterator<Integer> iterator(){
        return new Iterator<Integer>() {
            //номер текущего элемента
            private int position = -1;
            @Override
            public boolean hasNext() {
                return ++position < size;
            }

            @Override
            public Integer next() {
                return get(position);
            }

            @Override
            public void remove()
            {
              MyArrayList.this.remove(position--);
            }
        };


    }

    public Iterator<Integer> reverseIterator() {
        return new Iterator<Integer>() {
            private int position = size - 1;

            @Override
            public boolean hasNext() {
                return position >= 0;
            }

            @Override
            public Integer next() {
                return data[position--];
            }

            @Override
            public void remove()
            {
                MyArrayList.this.remove(position--);
            }
        };
    }
    @Override
    public Iterator<Integer> reserveIterator() {
        return  reverseIterator();
    }

    //private class SmallToBigIterator implements Iterator<Integer>
    //    {
    //        private int [] source = new int[size()];
    //        private int position = -1;
    //
    //        public SmallToBigIterator() {
    //            // быстрое копирование
    //            System.arraycopy(data, 0, source, 0, size());
    //            // сортировка
    //            Arrays.sort(source);
    //        }
    //
    //        @Override
    //        public boolean hasNext() {
    //            return ++position < size();
    //        }
    //
    //        @Override
    //        public Integer next() {
    //            return source[position];
    //        }
    //    }

    public Iterator<Integer> ascendingIterator(){
        int [] sortedData = new int[size];
        for (int i = 0; i < size(); i++){
           sortedData[i] = data[i];
        }
        Arrays.sort(sortedData);
        return new Iterator<Integer>() {
            int position = 0;
            @Override
            public boolean hasNext() {
                return position < size;
            }

            @Override
            public Integer next() {
                return sortedData[position++];
            }

            public void remove(){
                MyArrayList.this.remove(position++);
            }
        };
    }

    //public Iterator<Integer> backward() {
    //        return new Iterator<Integer>() {
    //            private int position = size();
    //            @Override
    //            public boolean hasNext() {
    //                return --position >= 0;
    //            }
    //
    //            @Override
    //            public Integer next() {
    //                return get(position);
    //            }
    //        };
    //    }




}


