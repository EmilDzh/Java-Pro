package lesson6.list;



public class ListTester {
    public static void main(String[] args) {
        // создайте MyArrayList
        MyArrayList list = new MyArrayList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);

        // добавьте туда элементы 1,2,3,4,5
        System.out.println(list);
        System.out.println(list.get(4));
        list.remove(1);
        System.out.println(list);
        System.out.println(list.size());
        list.add(2,222);
        System.out.println(list);
        // распечатайте его на экране
        // до 21:44
    }
}
