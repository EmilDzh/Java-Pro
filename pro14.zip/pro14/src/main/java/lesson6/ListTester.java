package lesson6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SortedMap;

public class ListTester {
    public static void main(String[] args) {
        // List - динамически расширяемый список элементов
        //      ArrayList - основан на масиве
        //      LinkedList - каждый из элементов хранит ссылку на следующий и предыдущих
        // Set - набор уникальных элементов
        // Map - хранит пары из уникального ключа и значения

        // инициализация
        List<String> capitals = new ArrayList<>(
                Arrays.asList("Vienna","Prague")
        );
        System.out.println(capitals + " size " + capitals.size());
        capitals.add("Berlin");//добавления элемента в конец
        System.out.println(capitals + " size " + capitals.size());
        capitals.addAll(Arrays.asList("London", "Paris"));
        System.out.println(capitals + " size " + capitals.size());
        System.out.println(capitals.get(3));//обращение по индексу
        //изменение по индексу
        capitals.set(0,"Bratislava");
        System.out.println(capitals);
        //удаление элемента

        // удаление элемента
        // capitals.remove() // удалите Paris
        // до 20:07
        // распечатайте результат
        capitals.remove(4);
        System.out.println(capitals);
        capitals.remove("Paris");
        System.out.println(capitals);

        // можно добавить в список коллекцию
        // capitals.addAll(Collection)
        // можно удалить из списка все элементы, входящие в другую коллекцию
        // capitals.removeAll(Collection)

        // Все контейнеры/коллеции явы могут содержать ТОЛЬКО ссылочные типы


        System.out.println(
                compare(Arrays.asList(1,2,3,4), Arrays.asList(1,2,3,4)) // true
        );
        System.out.println(
                compare(Arrays.asList(1,2,3), Arrays.asList(1,2,4)) // false
        );

        // ArrayList - основан на массиве
        // все операции доступа по индексу O(1)
        // операции добавления в начало O(N)

        System.out.println(filterOnlyOdd(Arrays.asList(1,2,6,8,15,3)));

        //https://docs.oracle.com/javase/8/docs/api/java/util/List.html


    }
    public static void doSomething(List<String> strings){

    }

    // напишите функцию которая конкатенирует два списка
    public static List<String> concat(List<String> s1, List<String> s2)
    {
        List<String> r = new ArrayList<>(s1);
        r.addAll(s2);
        return r;
    }

    // напишите функцию которая принимает на вход два списка целых
    // и возвращает true если все элементы попарно одинаковы
    public static boolean compare(List<Integer> i1, List<Integer> i2)
    {
        // {1,2,4,3}, {1,2,4,3} -> true
        // {1,2}, {2,1} - false
        for(int i = 0; i < i1.size(); i++)
        {
            if(!i1.get(i).equals(i2.get(i)))
                return false;
        }
        return true;
    }

    public static List<Integer> filterOnlyOdd(List<Integer> i1) {
        List<Integer> i2 = new ArrayList<>();

        for (int i = 0; i < i1.size(); i++) {
            if (i1.get(i) % 2 != 1) {
                i2.add(i1.get(i));
            }
        }

        return i2;
    }
}
