package lesson1.geometry;
public class Rectangle {
    // сделайте свойства
    // sw и ne типа Point
    final private Point sw; //final - значение свойство не предполагает изменение
    // если java увидеть попытки изменение этого свойства она подсветит эту как ошибку
    final private Point ne;

    // сделайте конструктор из
    // этих свойств
    public Rectangle(Point sw, Point ne) {
        this.sw = sw;
        this.ne = ne;
    }

    // сделайте геттеры
    public Point getSw() {
        return sw;
    }

    public Point getNe() {
        return ne;
    }

    // посчитайте площадь прямоугольника
    public double area()
    {

        return (ne.getY() - sw.getY())*
                (ne.getX() - sw.getX());
    }

}

