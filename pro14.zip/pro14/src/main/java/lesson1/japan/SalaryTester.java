package lesson1.japan;

public class SalaryTester {
    public static void main(String[] args) {
        JapaneseEmployee e1 = new JapaneseEmployee("Tanjiro Kamado", 150000, 10);
        JapaneseEmployee e2 = new JapaneseEmployee("Zenistu Zen", 20000, 2);


        System.out.println(e1.getName() + " salary " + e1.calculateSalary());
        System.out.println(e2.getName() + " salary " + e2.calculateSalary());
    }
}
