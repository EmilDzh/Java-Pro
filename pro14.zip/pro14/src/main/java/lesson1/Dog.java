package lesson1;
//Программа - https://docs.google.com/spreadsheets/d/1kM_CNDBZGfKG3jwd-7bPvt9I1zPQ4z2ohixcfYe0I3M/edit#gid=1906158376

// класс - объединение чего-либо по характерным признакам
// класс - это шаблон для описания его представителей
// класс - набор свойств и действий
// экземпляр класса - конкретный представитель
// инкапсуляция - защита доступа к свойствам (состояние) объекта

public class Dog {
    // private значит что свойство доступно только внутри класса
    private String breed; // порода
    private String name; // имя собаки
    private int age; // возраст
    private String color; // цвет

    // беспараметрический конструктор
    public Dog() {
    }

    public Dog(String breed, String name, int age, String color) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.color = color;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0 && age <= 50) {
            this.age = age;
        }
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;

    }

    public void bark()
    {
        // внутри класса доступ есть ко всем полям
        // независимо от уровня доступа - private, public etc
        System.out.println(name + " bark, bark!");
    }


}// конец класса
