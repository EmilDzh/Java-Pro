package lesson1.HW140623;

public class Person {

    String fullname;
    int age;

    public  void move(){
        System.out.println("Person " + fullname + " говорит");
    }

    public  void talk(){
        System.out.println("Person " + fullname + " идет");
    }


    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Person() {
    }

    public Person(String fullname, int age) {
        this.fullname = fullname;
        this.age = age;
    }


}
