package lesson10;

/*
    Set - интерфейс - служит базой для коллекций содержащих уникальные элементы
    применения
        поиск дубликатов
        поиск уникальных элементов

    реализации
        HashSet - набор хранится в виде оптимизированном для поиска
            предполагается что операции поиска O(1)
            при этом расходуется память на поддержание внутренней структуры
            порядок обхода не гарантируется
        LinkedHashSet - гарантирует что при обходе элементы возвращаются в
            порядке вставки
        TreeSet - хранит и возвращает элементы при обходе в порядке сортировки
            заданным для типа либо заданным через компаратор

 */


import java.util.*;

public class SetTester {
    public static void main(String[] args) {
        Set<String> groups = new HashSet<>(Arrays.asList("Abba", "Beatles", "Rolling Stones"));
        groups.add("Deep Purple");
        groups.add("Led Zeppelin");

        System.out.println(groups);

        System.out.println(groups.contains("Eurythmics")); // false
        System.out.println(groups.contains("Abba")); // true
        System.out.println(groups.size());// размер коллекции -5
        groups.add("Abba");
        System.out.println(groups.size());//не добавляется так как у нас Set - хранит только уникальные элементы
        System.out.println(groups);

        // обход по итератору для сета имеет смысл делать только
        // если в процессе обхода потребуется что-то удалять
        Iterator<String> groupsIterator = groups.iterator();
        while (groupsIterator.hasNext())
            System.out.println("group is: " + groupsIterator.next());

        // во всех остальных случаях
        for(String s: groups)
        {
            System.out.println("for each group " + s);
        }

        // Set не дает доступ по индексу -
        // применения - contains и обход по итератору или for-each

        groups.remove("Abba"); // удаление элемента
        System.out.println(groups);

        // Collection.addAll(Collection c) - добавление элементов из другой коллекции
        // Collection.containsAll(Collection c) - true если c содержится полностью
        // Collection.removeAll(Collection c) - удаление всех элементов содержащихся в с
        // Collection.retainAll(Collection c) - в коллекции останутся только только общие элементы


        List<String> britishGroups = Arrays.asList("Blur", "Oasis", "Rolling Stones", "Beatles");

//        groups = new HashSet<>(britishGroups); работает наоборот)))
//        System.out.println(groups);
        // удалите из groups все британские группы
        // до 20:10

        groups.removeAll(britishGroups);
        System.out.println(groups);

        // TreeSet - хранит элементы в порядке сортировки
        TreeSet<String> britishGroupsTreeSet = new TreeSet<>(britishGroups);
        System.out.println(britishGroupsTreeSet);

        // headSet - все элементы "до"
        System.out.println(britishGroupsTreeSet.headSet("Guns and Roses")); // Beatles, Blur

        // subSet - все элементы в диапазоне "от" и "до"
        System.out.println(britishGroupsTreeSet.subSet("Guns and Roses", "ZZ Top")); // Oasis, Rolling Stones

        //TailSet - все элементы "после"

        System.out.println(
                filterCollection(
                        Arrays.asList(1,2,3,4,5,6,7), 2, 6
                )
        );

        System.out.println(
                getDoubles("dima max sveta lena gena lena sveta max") // dima max sveta lena gena
        );

        System.out.println(uniqueLetters("hello lake mid"));


        List<String> months = Arrays.asList(
                "January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"
        );






    }

    // напишите функцию которая принимает на вход коллекцию и два значения - "от" и "до"
    // и возвращает Set с элементами коллекции, лежащими в этом диапазоне
    public static Set<Integer> filterCollection(Collection<Integer> c, int from, int to)
    {
        // желательно обойтись без циклов
//        TreeSet<Integer> numbers = new TreeSet<>(c);
//        return numbers.subSet(from, to);
        return new TreeSet<>(c).subSet(from, false, to, false);
    }

    // напишите функцию которая возвращает список дубликатов из строки
    public static Set<String> getDoubles(String s)
    {
        Set<String> words = new HashSet<>();
        Set<String> doubles = new HashSet<>();
        for(String w : s.split(" "))
        {
            if(words.contains(w))
                doubles.add(w);
            words.add(w);
        }
        return doubles;
    }

    // напишите функцию которая возвращает набор уникальных букв из строки
    // в порядке их следования в строке
    // "hello lake mid" -> helo akmid
    public static Set<String> uniqueLetters(String s) {
//        Set<String> let = new LinkedHashSet<>();
//        char[] arr = s.toCharArray();
//        for (char b : arr){
//            if (b == b)
//                let.add(String.valueOf(b));
//        }
//        // String [] = "".split("");
//        return let;
//    }


        {
            return new LinkedHashSet<>(
                    Arrays.asList(
                            s.split("")
                    )
            );


        }
    }

    // считается что устрицы можно есть только в месяцы в которых есть буква "r"
    // верните те месяцы когда устриц можно есть в порядке следования
    public static Set<String> filterMonth(List<String> m)
    {
        Set<String> result = new LinkedHashSet<>();
        for(String month: m)
        {
            if(month.contains("r"))
                result.add(month);
        }
        return result;
    }

}
