package lesson17;

// функциональный интерфейс - содержит ТОЛЬКО ОДИН абстрактный метод
// абстрактный метод функионального интерфейса можно заменить на лямбда выражение

@FunctionalInterface
public interface NoArgsReturnDouble {
    double produce(); // единственный абстрактный метод
    default void hello(){ }
    static void print() {}
}
