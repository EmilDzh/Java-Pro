package lesson17;

public interface IntReturnsBoolean {
    boolean check(int i);
}
