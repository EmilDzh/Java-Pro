package lesson17;

public interface TwoIntsReturnsBoolean {
    boolean check(int i, int j);
}
