package lesson17;

public interface StringReturnInt {
    int process(String s);
}
