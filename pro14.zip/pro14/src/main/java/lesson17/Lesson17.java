package lesson17;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Lesson17 {

    // https://docs.oracle.com/javase/8/docs/api/java/util/function/package-summary.html

    public static void main(String[] args) {
        NoArgsReturnDouble returns10 = new NoArgsReturnDouble() {
            @Override
            public double produce() {
                return 10;
            }
        };

        NoArgsReturnDouble lambdaReturns5 = () -> 5;
        NoArgsReturnDouble lambdaReturns15 = () -> {
            return 15;
        };

        // напишите в виде лямбды реализацию NoArgsReturnDouble которая возвращает рандомное
        // значение double
        // Random r = new Random();
        // r.nextDouble(); // от 0 до 1
        // до 21:07
        NoArgsReturnDouble randomDouble = () -> new Random().nextDouble();
//        NoArgsReturnDouble randomDouble = new NoArgsReturnDouble() {
//            @Override
//            public double produce() {
//                return new Random().nextDouble();
//            }
//        };

        System.out.println("рандомное значение: " + randomDouble.produce());
        // Supplier - безаргументный функциональный интерфейс который
        // просто возвращает значение

        // Predicate - функциональный интерфейс который принимает на вход значение

        // создайте в виде лямбды реализацию TwoIntsReurnDouble
        // которая проверяет что числа друг другу равны
        // до 21:20

        // TwoIntsReturnsBoolean twoIntsReturnsBoolean = (i, j) -> i == j ? true : false; my Code)

        // создайте в виде лямбды реализацию TwoIntsReturnDouble
        // которая проверяет что передаваемые числа друг другу равны
        TwoIntsReturnsBoolean equality = (i, j) -> i == j;
        TwoIntsReturnsBoolean isDividedBy = (i, j) -> i % j == 0;


        System.out.println(process(2,3, equality)); // false
        System.out.println(process(12,3, isDividedBy)); // true



//        List<Integer> digits = Arrays.asList(1,2,3,4,8,10,12,0,2);
//        System.out.println(
//                filter(
//                        digits,
//                        new IntReturnsBoolean() {
//                            @Override
//                            public boolean check(int i) {
//                                return false;
//                            }
//                        }
//                )
//        );

        List<Integer> digits = Arrays.asList(1,2,3,4,8,10,12,0,2);
        System.out.println(
                filter(
                        digits,
                        i -> i % 2 == 1
                )
        );

        // отфильтруйте тот-же список чтобы вывелись числа больше или равные 10
        // до 21:49

        System.out.println(filter(digits, i -> i >= 10));

        List<String> names = Arrays.asList("Max", "Masha", "Alexander", "Dima");
        // примените map к этому списку
        // в качестве логики StringReturnInt возвращайте длину строки
        // до 21:56

        System.out.println(map(names, s -> s.length()));

        System.out.println(
                names.stream()
                        .filter(s -> s.length() > 4)
                        .map(s -> s.length())
                        .collect(Collectors.toList())
        );

        // функциональный интерфейс который принимает один тип и возвращает другой
        // кроме boolean назавается Function

    }//main

    static boolean process(int i, int j, TwoIntsReturnsBoolean c)
    {
        // напишите реализацию - вызывать функцию из
        // интерфейса для i и j
        return c.check(i, j);
    }
// my Code__)
//    static List<Integer> filter(List<Integer> list, IntReturnsBoolean p)
//    {
//        List<Integer> output = new ArrayList<>();
//        // отфильтруйте список
//        for (Integer a : list){
//
//            if (p.check(a) == true)
//                output.add(a);
//        }
//        // добавляйте в выходной список только те элементы из входного
//        // которые соотвутствуют предикату IntReturnsBoolean
//        // до 21:41
//        return output;
//    }

    static List<Integer> filter(List<Integer> list, IntReturnsBoolean p)
    {
        List<Integer> output = new ArrayList<>();
        // отфильтруйте список
        // добавляйте в выходной список только те элементы из входного
        // которые соответствуют предикату IntReturnsBoolean
        for (int i : list)
        {
            if(p.check(i))
                output.add(i);
        }
        return output;
    }

    static List<Integer> map(List<String> string, StringReturnInt p)
    {
        List<Integer> result = new ArrayList<>();
        for(String s : string)
            result.add(p.process(s));
        return result;
    }
}
