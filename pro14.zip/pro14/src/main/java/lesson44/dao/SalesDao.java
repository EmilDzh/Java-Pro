package lesson44.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalesDao {
    private static String url = "jdbc:sqlite:shop.db";
    public Sales getSalesById(int id)
    {
        try (
                Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(
                        "select snum, sname, city, comm from salespeople where snum=?"
                );
        )
        {
            pstmt.setInt(1, id);
            try (
                    ResultSet rs = pstmt.executeQuery()
            )
            {
/*
create table salespeople (
    snum int primary key not null,
    sname text not null,
    city text not null,
    comm integer not null
    );
 */
                while (rs.next())
                {
                    int snum = rs.getInt("snum");
                    String sname = rs.getString("sname");
                    String city = rs.getString("city");
                    int comm = rs.getInt("comm");
                    return new Sales(snum, sname, city, comm);
                }
            }
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
        return null;
    }
    public List<Sales> getAll()
    {
        List<Sales> sales = new ArrayList<>();
        try (
                Connection connection = DriverManager.getConnection(url);
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery("select * from salespeople");
        )
        {
            while (rs.next())
            {
                int snum = rs.getInt("snum");
                String sname = rs.getString("sname");
                String city = rs.getString("city");
                int comm = rs.getInt("comm");
                sales.add(new Sales(snum, sname, city, comm));
            }
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
        return sales;
    }
    public int create(Sales sales) {
        try (
                Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(
                        "insert into salespeople (snum, sname, city, comm) values (?,?,?,?) "
                );
        ) {
            pstmt.setInt(1, sales.getSnum());
            pstmt.setString(2, sales.getSname());
            pstmt.setString(3, sales.getCity());
            pstmt.setInt(4, sales.getComm());
            return pstmt.executeUpdate();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
    public int delete(Sales sales)
    {
        try (
                Connection c = DriverManager.getConnection(url);
                PreparedStatement pstmt = c.prepareStatement(
                        "delete from salespeople where snum = ?"
                )
                )
        {
            pstmt.setInt(1,sales.getSnum());
            return pstmt.executeUpdate();

        } catch (Exception e){
            System.err.println(e.getMessage());
        }

        return 0;
    }
    public int update(Sales sales) {
        try (
                Connection connection = DriverManager.getConnection(url);
                PreparedStatement pstmt = connection.prepareStatement(
                        "update salespeople set sname=?, city=?, comm=? where snum=?"
                );
        ){
            pstmt.setString(1, sales.getSname());
            pstmt.setString(2, sales.getCity());
            pstmt.setInt(3, sales.getComm());
            pstmt.setInt(4, sales.getSnum());
            return pstmt.executeUpdate();
        }catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
        return 0;
    }

}
