package lesson44.dao;

import java.util.List;

public class DaoTester {
    public static void main(String[] args) {
        SalesDao salesDao = new SalesDao();
        Sales s1001 = salesDao.getSalesById(1001);
        System.out.println(s1001);


        Sales max = new Sales(2002, "Max Kotkov", "Prague", 8);
//        System.out.println(salesDao.create(max));

        System.err.println(salesDao.delete(max));

        Sales axel = salesDao.getSalesById(1003);
        axel.setComm(14);
        salesDao.update(axel);

        List<Sales> sales = salesDao.getAll();
        sales.forEach(
                System.out::println
        );
    }
}
