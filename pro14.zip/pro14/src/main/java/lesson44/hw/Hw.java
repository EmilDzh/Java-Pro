package lesson44.hw;

import java.sql.*;

public class Hw {
    public static void main(String[] args) {
        // 1 уровень сложности: Распечатайте все заказы определенного покупателя выше определенной суммы.
        //И покупатель и сумма должны передаваться в виде параметров в параметризованный запрос.
        String url = "jdbc:sqlite:shop.db";

        try (
                Connection conn = DriverManager.getConnection(url);
                PreparedStatement pstmt = conn.prepareStatement(
                        "SELECT customers.cname, orders.amt  " +
                                "  FROM customers  " +
                                "  INNER JOIN orders ON customers.cnum = orders.cnum  " +
                                "  WHERE customers.cname = ? AND orders.amt > ?"
                );
                )
        {
            pstmt.setString(1,"Liu");
            pstmt.setInt(2,10);
            try (
                    ResultSet customers = pstmt.executeQuery();
                    )
            {
                while (customers.next()){
                    String cname = customers.getString("cname");
                    int amt = customers.getInt("amt");

                    System.out.printf("|%s10|%5d|",cname,amt);
                }
            }

        } catch (Exception e){
            System.err.println(e.getMessage());
        }
    }
}
