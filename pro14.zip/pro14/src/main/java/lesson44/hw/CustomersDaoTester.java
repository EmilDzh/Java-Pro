package lesson44.hw;

import java.util.List;

public class CustomersDaoTester {
    public static void main(String[] args) {
        CustomersDao customersDao = new CustomersDao();
        Customers c2001 = customersDao.getCustomerById(2001);
        System.out.println(c2001);

        Customers customer1 = new Customers(5000,"Passenger","NY",500,700);
       // System.out.println(customersDao.create(customer1));

        System.err.println(customersDao.delete(customer1));

        Customers Ferguson = customersDao.getCustomerById(4001);
        Ferguson.setRating(10);
        customersDao.update(Ferguson);

        List<Customers> customers = customersDao.getAll();
        customers.forEach(
                System.out::println
        );
    }
}
