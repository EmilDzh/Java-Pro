package lesson44.hw;

/*
Добавьте DAO класс для покупателей - CustomersDao - операциями
Customer getCustomerById(int id)
List<Customer> getAll()
int create(Customer customer)
int delete(Customer customer)
int update(Customer customer)
*/

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomersDao {
    private static String url = "jdbc:sqlite:shop.db";

    public Customers getCustomerById(int id){

        try(
                Connection c = DriverManager.getConnection(url);
                PreparedStatement pstmt = c.prepareStatement(
                        "SELECT cnum, cname, city, rating, snum FROM customers WHERE cnum = ?"
                )
                )
        {
            pstmt.setInt(1,id);

            try (
                    ResultSet rs = pstmt.executeQuery();
                    )
            {
                while (rs.next()){
                    int cnum = rs.getInt("cnum");
                    String cname = rs.getString("cname");
                    String city = rs.getString("city");
                    int rating = rs.getInt("rating");
                    int snum = rs.getInt("snum");

                    return new Customers(cnum,cname,city,rating,snum);
                }
            }
        } catch (Exception e){
            System.err.println(e.getMessage());
        }

        return null;
    }

    public List<Customers> getAll(){

        List<Customers> result = new ArrayList<>();

        try(
                Connection c = DriverManager.getConnection(url);
                Statement stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM customers");
                )
        {
          while (rs.next()){

              int cnum = rs.getInt("cnum");
              String cname = rs.getString("cname");
              String city = rs.getString("city");
              int rating = rs.getInt("rating");
              int snum = rs.getInt("snum");

              result.add(new Customers(cnum,cname,city,rating,snum));
          }
        }catch (Exception e){
            System.err.println(e.getMessage());
        }

        return result;
    }

    public int create(Customers customer){

        try(
                Connection c = DriverManager.getConnection(url);
                PreparedStatement pstmt = c.prepareStatement(
                        "insert into customers (cnum, cname, city, rating, snum) values(?,?,?,?,?)"
                );
                )
        {
            pstmt.setInt(1,customer.getCnum());
            pstmt.setString(2,customer.getCname());
            pstmt.setString(3,customer.getCity());
            pstmt.setInt(4,customer.getRating());
            pstmt.setInt(5,customer.getSnum());

            return pstmt.executeUpdate();
        }catch (Exception e){
            System.err.println(e.getMessage());
        }

        return 0;
    }

    public int delete(Customers customer){

        try (
                Connection c = DriverManager.getConnection(url);
                PreparedStatement pstmt = c.prepareStatement(
                        "delete FROM customers WHERE cnum = ?"
                );
                )
        {
            pstmt.setInt(1,customer.getCnum());

            return pstmt.executeUpdate();
        }catch (Exception e){
            System.err.println(e.getMessage());
        }
        return 0;
    }

    public int update(Customers customer){

        try(
                Connection c = DriverManager.getConnection(url);
                PreparedStatement pstmt = c.prepareStatement(
                        "update customers set cname=?, city=?, rating=?, snum=? WHERE cnum=?"
                );
                )
        {

            pstmt.setString(1,customer.getCname());
            pstmt.setString(2, customer.getCity());
            pstmt.setInt(3,customer.getRating());
            pstmt.setInt(4,customer.getSnum());
            pstmt.setInt(5,customer.getCnum());

            return pstmt.executeUpdate();
        }catch (Exception e){
            System.err.println(e.getMessage());
        }

        return 0;
    }
}
