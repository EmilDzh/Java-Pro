package lesson44.hw;

/*
Добавьте DAO класс для покупателей - CustomersDao - операциями
Customer getCustomerById(int id)
List<Customer> getAll()
int create(Customer customer)
int delete(Customer customer)
int update(Customer customer)
*/
public class Customers {

    private int cnum;
    private String cname;
    private String city;
    private int rating;
    private int snum;

    public Customers() {
    }

    public Customers(int cnum, String cname, String city, int rating, int snum) {
        this.cnum = cnum;
        this.cname = cname;
        this.city = city;
        this.rating = rating;
        this.snum = snum;
    }

    public int getCnum() {
        return cnum;
    }

    public void setCnum(int cnum) {
        this.cnum = cnum;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    @Override
    public String toString() {
        return "Customers{" +
                "cnum=" + cnum +
                ", cname='" + cname + '\'' +
                ", city='" + city + '\'' +
                ", rating=" + rating +
                ", snum=" + snum +
                '}';
    }
}
