package lesson2.crossword;

public class TestABC {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        C c = new C();

        a.hello();
        a.world();
        a.secure();

        b.hello();
        b.secure();
        b.world();

        c.hello();

    }
}
