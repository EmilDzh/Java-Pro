package lesson2.crossword;

public class B extends A { // extends - расширяет класс A
    // A - суперкласс (прародитель)
    // B - дочерний

    @Override // позволяет проверить что мы самом деле
   //  переопределяем какой-то метод
    protected void world() {
        super.world(); // вызов метода world из суперкласса
        System.out.println("World from B");
    }

    // добавьте реализацию метода hello
    // чтобы печатала "Hello, Hello from B!!!"

    @Override
    public void hello() {
        System.out.println("Hello, Hello from B!!!");
    }

    // объявлен в родительском классе как final и не подлежит
    // переопределению
    //    public void secure()
    //    {
    //
    //    }
}
