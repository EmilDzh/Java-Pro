package lesson2.crossword;

public class C extends B {

    @Override
    public void hello() {
        System.out.println("Hello. I am a C");
    }
}
