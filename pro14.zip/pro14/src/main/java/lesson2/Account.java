package lesson2;

public class Account {
    private String id;
    private String owner;
    private int balance;

    public Account(String id, String owner, int balance) {
        this.id = id;
        this.owner = owner;
        this.balance = balance;
    }

    public String getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public int getBalance() {
        return balance;
    }

    // добавление денег на счет
    // и возвращение полученного баланса
    // если money меньше 0 то выводить на консоль "Отрицательная сумма"
    // если money больше 0 добавлять в баланс
    // возвращать баланс
    public int addMoney(int money)
    {
        if(money < 0)
        {
            System.out.println("Отрицательная сумма");
        }
        else {
            balance += money;
        }
        return balance;
    }

    // удаление денег со счета
    // нельзя удалить больше чем там есть
    // при попытке удалить больше чем есть нужно выводить
    // сообщение "сумма больше баланса" но не менять баланс
    // возвращать баланс счета конечный
    public int subtractMoney(int money)
    {
        if (balance < money){
            System.out.println("сумма больше баланса");
        } else {
            balance -= money;
        }
        return balance;
    }

    // перевод денег со счета на счет
    // списываем деньги с одного счета и добавляем их на другой
    // возвращается баланс счета с которого деньги списались
    // при попытке снять больше баланс нужно выводить сообщения как вверху
    // account - счет куда переводим
    // amount - сумма, которую переводим
    public int transfer(Account account, int amount)
    {
        // balance - деньги на счете до перевода
        // subtractMoney(amount) - деньги на счете после снятия (остаток)
        int amountToTransfer = (balance - subtractMoney(amount));
        account.addMoney(amountToTransfer);
        return balance;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id='" + id + '\'' +
                ", owner='" + owner + '\'' +
                ", balance=" + balance +
                '}';
    }

    public static void main(String[] args) {
        Account a1 = new Account("123", "Misha Semenov", 30);
        Account a2 = new Account("456", "Dima Petrov", 60);
        a1.transfer(a2, 15);
        System.out.println(a1);
        System.out.println(a2);

        a1.transfer(a2, 100);
        System.out.println(a1);
        System.out.println(a2);
    }
}
