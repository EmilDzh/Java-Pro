package lesson2.university;

public class Student extends Person{
    private int year;
    private String programm;

    public Student(String name, int age, int year, String programm) {
        super(name, age);// вызов конструктора суперкласса
        //мы обьязаны вызвать конструктор суперкласса если он там есть
        this.year = year;
        this.programm = programm;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getProgramm() {
        return programm;
    }

    public void setProgramm(String programm) {
        this.programm = programm;
    }

    // переопределите introduce
    // чтобы он выдавал имя, возраст, программу и год
    // до 21:46


    @Override
    public void introduce() {
        System.out.println( "I am a Student " + getName() + getProgramm() + getYear());
    }

}
